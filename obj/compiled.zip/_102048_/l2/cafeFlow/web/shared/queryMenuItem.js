/// <mls fileReference="_102048_/l2/cafeFlow/web/shared/queryMenuItem.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
/// **collab_i18n_start**
const message_pt = {
    "section.consultarItensCardapio.title": "Consultar Itens de Cardápio",
    "organism.queryMenuItem.title": "Itens de Cardápio",
    "intention.queryMenuItem.list.title": "Lista de Itens de Cardápio",
    "intention.queryMenuItem.list.empty": "Nenhum item de cardápio encontrado",
    "field.menuItemId.label": "ID do Item",
    "field.name.label": "Nome",
    "field.category.label": "Categoria",
    "field.price.label": "Preço",
    "field.stockItemId.label": "Item de Estoque",
    "field.status.label": "Status",
    "field.createdAt.label": "Criado em",
    "field.updatedAt.label": "Atualizado em",
    "action.queryMenuItem.label": "Buscar"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowQueryMenuItemBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = "";
        this.queryMenuItemState = "idle";
        this.queryMenuItemMenuItemId = "";
        this.queryMenuItemName = "";
        this.queryMenuItemCategory = "";
        this.queryMenuItemStockItemId = "";
        this.queryMenuItemStatus = "";
        this.queryMenuItemCreatedAt = "";
        this.queryMenuItemData = [];
        this.handleQueryMenuItemClick = (event) => {
            event.preventDefault();
            runBlockingUiAction(async (_signal) => {
                await this.loadQueryMenuItem();
            }, { mode: "silent" });
        };
        this.handleQueryMenuItemMenuItemIdChange = (event) => {
            const target = event.target;
            this.setQueryMenuItemMenuItemId(target.value);
        };
        this.handleQueryMenuItemNameChange = (event) => {
            const target = event.target;
            this.setQueryMenuItemName(target.value);
        };
        this.handleQueryMenuItemCategoryChange = (event) => {
            const target = event.target;
            this.setQueryMenuItemCategory(target.value);
        };
        this.handleQueryMenuItemStockItemIdChange = (event) => {
            const target = event.target;
            this.setQueryMenuItemStockItemId(target.value);
        };
        this.handleQueryMenuItemStatusChange = (event) => {
            const target = event.target;
            this.setQueryMenuItemStatus(target.value);
        };
        this.handleQueryMenuItemCreatedAtChange = (event) => {
            const target = event.target;
            this.setQueryMenuItemCreatedAt(target.value);
        };
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.queryMenuItemMenuItemId = getState("ui.queryMenuItem.input.queryMenuItem.menuItemId") ?? "";
        this.queryMenuItemName = getState("ui.queryMenuItem.input.queryMenuItem.name") ?? "";
        this.queryMenuItemCategory = getState("ui.queryMenuItem.input.queryMenuItem.category") ?? "";
        this.queryMenuItemStockItemId = getState("ui.queryMenuItem.input.queryMenuItem.stockItemId") ?? "";
        this.queryMenuItemStatus = getState("ui.queryMenuItem.input.queryMenuItem.status") ?? "";
        this.queryMenuItemCreatedAt = getState("ui.queryMenuItem.input.queryMenuItem.createdAt") ?? "";
        this.queryMenuItemData = getState("ui.queryMenuItem.data.queryMenuItem") ?? [];
        this.queryMenuItemState = getState("ui.queryMenuItem.action.queryMenuItem.status") ?? "idle";
        subscribe([
            "ui.queryMenuItem.status",
            "ui.queryMenuItem.action.queryMenuItem.status",
            "ui.queryMenuItem.input.queryMenuItem.menuItemId",
            "ui.queryMenuItem.input.queryMenuItem.name",
            "ui.queryMenuItem.input.queryMenuItem.category",
            "ui.queryMenuItem.input.queryMenuItem.stockItemId",
            "ui.queryMenuItem.input.queryMenuItem.status",
            "ui.queryMenuItem.input.queryMenuItem.createdAt",
            "ui.queryMenuItem.data.queryMenuItem",
        ], this);
        this.loadQueryMenuItem();
    }
    disconnectedCallback() {
        unsubscribe([
            "ui.queryMenuItem.status",
            "ui.queryMenuItem.action.queryMenuItem.status",
            "ui.queryMenuItem.input.queryMenuItem.menuItemId",
            "ui.queryMenuItem.input.queryMenuItem.name",
            "ui.queryMenuItem.input.queryMenuItem.category",
            "ui.queryMenuItem.input.queryMenuItem.stockItemId",
            "ui.queryMenuItem.input.queryMenuItem.status",
            "ui.queryMenuItem.input.queryMenuItem.createdAt",
            "ui.queryMenuItem.data.queryMenuItem",
        ], this);
        super.disconnectedCallback();
    }
    // --- Query action: queryMenuItem ---
    async loadQueryMenuItem() {
        this.queryMenuItemState = "loading";
        setState("ui.queryMenuItem.action.queryMenuItem.status", "loading");
        const params = {
            menuItemId: this.queryMenuItemMenuItemId || undefined,
            name: this.queryMenuItemName || undefined,
            category: this.queryMenuItemCategory || undefined,
            stockItemId: this.queryMenuItemStockItemId || undefined,
            status: this.queryMenuItemStatus || undefined,
            createdAt: this.queryMenuItemCreatedAt || undefined,
        };
        const options = { mode: "silent" };
        const response = await execBff("cafeFlow.queryMenuItem.queryMenuItem", params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.queryMenuItemData = data;
            setState("ui.queryMenuItem.data.queryMenuItem", data);
            this.queryMenuItemState = "success";
            setState("ui.queryMenuItem.action.queryMenuItem.status", "success");
        }
        else {
            this.queryMenuItemState = "error";
            setState("ui.queryMenuItem.action.queryMenuItem.status", "error");
        }
    }
    // --- State setters ---
    setQueryMenuItemMenuItemId(value) {
        this.queryMenuItemMenuItemId = value;
        setState("ui.queryMenuItem.input.queryMenuItem.menuItemId", value);
        this.requestUpdate();
    }
    setQueryMenuItemName(value) {
        this.queryMenuItemName = value;
        setState("ui.queryMenuItem.input.queryMenuItem.name", value);
        this.requestUpdate();
    }
    setQueryMenuItemCategory(value) {
        this.queryMenuItemCategory = value;
        setState("ui.queryMenuItem.input.queryMenuItem.category", value);
        this.requestUpdate();
    }
    setQueryMenuItemStockItemId(value) {
        this.queryMenuItemStockItemId = value;
        setState("ui.queryMenuItem.input.queryMenuItem.stockItemId", value);
        this.requestUpdate();
    }
    setQueryMenuItemStatus(value) {
        this.queryMenuItemStatus = value;
        setState("ui.queryMenuItem.input.queryMenuItem.status", value);
        this.requestUpdate();
    }
    setQueryMenuItemCreatedAt(value) {
        this.queryMenuItemCreatedAt = value;
        setState("ui.queryMenuItem.input.queryMenuItem.createdAt", value);
        this.requestUpdate();
    }
}
__decorate([
    property({ type: String })
], CafeFlowQueryMenuItemBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowQueryMenuItemBase.prototype, "queryMenuItemState", void 0);
__decorate([
    property({ type: String })
], CafeFlowQueryMenuItemBase.prototype, "queryMenuItemMenuItemId", void 0);
__decorate([
    property({ type: String })
], CafeFlowQueryMenuItemBase.prototype, "queryMenuItemName", void 0);
__decorate([
    property({ type: String })
], CafeFlowQueryMenuItemBase.prototype, "queryMenuItemCategory", void 0);
__decorate([
    property({ type: String })
], CafeFlowQueryMenuItemBase.prototype, "queryMenuItemStockItemId", void 0);
__decorate([
    property({ type: String })
], CafeFlowQueryMenuItemBase.prototype, "queryMenuItemStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowQueryMenuItemBase.prototype, "queryMenuItemCreatedAt", void 0);
__decorate([
    property({ type: Array })
], CafeFlowQueryMenuItemBase.prototype, "queryMenuItemData", void 0);
