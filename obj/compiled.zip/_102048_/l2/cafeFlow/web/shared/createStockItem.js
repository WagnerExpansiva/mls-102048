/// <mls fileReference="_102048_/l2/cafeFlow/web/shared/createStockItem.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "createStockItem.section.title": "Cadastrar Item de Estoque",
    "createStockItem.form.title": "Dados do Item de Estoque",
    "createStockItem.action.submit": "Salvar Item de Estoque",
    "stockItem.field.name": "Nome do item",
    "stockItem.field.unitOfMeasure": "Unidade de medida",
    "stockItem.field.minimumStockLevel": "Estoque mínimo",
    "stockItem.field.status": "Status",
    "section.createStockItem.title": "Cadastrar Item de Estoque"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowCreateStockItemBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = "";
        this.createStockItemState = "idle";
        this.createStockItemName = "";
        this.createStockItemUnitOfMeasure = "";
        this.createStockItemMinimumStockLevel = "";
        this.createStockItemStatus = "";
        this.handleCreateStockItemNameChange = (e) => {
            const target = e.target;
            this.setCreateStockItemName(target.value);
        };
        this.handleCreateStockItemUnitOfMeasureChange = (e) => {
            const target = e.target;
            this.setCreateStockItemUnitOfMeasure(target.value);
        };
        this.handleCreateStockItemMinimumStockLevelChange = (e) => {
            const target = e.target;
            this.setCreateStockItemMinimumStockLevel(target.value);
        };
        this.handleCreateStockItemStatusChange = (e) => {
            const target = e.target;
            this.setCreateStockItemStatus(target.value);
        };
        this.handleCreateStockItemClick = () => {
            runBlockingUiAction(async (_signal) => {
                await this.createStockItem();
            }, { mode: "blocking", busyLabel: this.msg["createStockItem.action.submit"] });
        };
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState("ui.createStockItem.status") ?? "";
        this.createStockItemState = getState("ui.createStockItem.action.createStockItem.status") ?? "idle";
        this.createStockItemName = getState("ui.createStockItem.input.createStockItem.name") ?? "";
        this.createStockItemUnitOfMeasure = getState("ui.createStockItem.input.createStockItem.unitOfMeasure") ?? "";
        this.createStockItemMinimumStockLevel = getState("ui.createStockItem.input.createStockItem.minimumStockLevel") ?? "";
        this.createStockItemStatus = getState("ui.createStockItem.input.createStockItem.status") ?? "";
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    // --- StateSetter Actions ---
    setCreateStockItemName(value) {
        this.createStockItemName = value;
        setState("ui.createStockItem.input.createStockItem.name", value);
        this.requestUpdate();
    }
    setCreateStockItemUnitOfMeasure(value) {
        this.createStockItemUnitOfMeasure = value;
        setState("ui.createStockItem.input.createStockItem.unitOfMeasure", value);
        this.requestUpdate();
    }
    setCreateStockItemMinimumStockLevel(value) {
        this.createStockItemMinimumStockLevel = value;
        setState("ui.createStockItem.input.createStockItem.minimumStockLevel", value);
        this.requestUpdate();
    }
    setCreateStockItemStatus(value) {
        this.createStockItemStatus = value;
        setState("ui.createStockItem.input.createStockItem.status", value);
        this.requestUpdate();
    }
    // --- Command Actions ---
    async createStockItem() {
        this.createStockItemState = "loading";
        setState("ui.createStockItem.action.createStockItem.status", "loading");
        this.requestUpdate();
        const params = {
            name: this.createStockItemName,
            unitOfMeasure: this.createStockItemUnitOfMeasure,
            minimumStockLevel: Number(this.createStockItemMinimumStockLevel),
            status: this.createStockItemStatus,
        };
        const options = { mode: "blocking" };
        const response = await execBff("cafeFlow.createStockItem.createStockItem", params, options);
        if (response.ok) {
            this.createStockItemState = "success";
            setState("ui.createStockItem.action.createStockItem.status", "success");
        }
        else {
            this.createStockItemState = "error";
            setState("ui.createStockItem.action.createStockItem.status", "error");
        }
        this.requestUpdate();
    }
}
__decorate([
    property({ type: String })
], CafeFlowCreateStockItemBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowCreateStockItemBase.prototype, "createStockItemState", void 0);
__decorate([
    property({ type: String })
], CafeFlowCreateStockItemBase.prototype, "createStockItemName", void 0);
__decorate([
    property({ type: String })
], CafeFlowCreateStockItemBase.prototype, "createStockItemUnitOfMeasure", void 0);
__decorate([
    property({ type: String })
], CafeFlowCreateStockItemBase.prototype, "createStockItemMinimumStockLevel", void 0);
__decorate([
    property({ type: String })
], CafeFlowCreateStockItemBase.prototype, "createStockItemStatus", void 0);
