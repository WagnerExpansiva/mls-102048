/// <mls fileReference="_102048_/l2/cafeFlow/web/shared/queryStockItem.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "queryStockItem.section.main.title": "Consultar Itens de Estoque",
    "queryStockItem.organism.list.title": "Consultar Itens de Estoque",
    "queryStockItem.intention.list.title": "Query List",
    "queryStockItem.field.stockItemId": "Stock Item Id",
    "queryStockItem.field.name": "Name",
    "queryStockItem.field.unitOfMeasure": "Unit Of Measure",
    "queryStockItem.field.minimumStockLevel": "Minimum Stock Level",
    "queryStockItem.field.status": "Status",
    "queryStockItem.field.createdAt": "Created At",
    "queryStockItem.field.updatedAt": "Updated At",
    "queryStockItem.filter.stockItemId": "Stock Item Id",
    "queryStockItem.filter.name": "Name",
    "queryStockItem.filter.status": "Status",
    "queryStockItem.filter.createdAt": "Created At",
    "queryStockItem.filter.updatedAt": "Updated At",
    "queryStockItem.action.query": "Query Stock Item"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowQueryStockItemBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.queryStockItemState = 'idle';
        this.queryStockItemStockItemId = '';
        this.queryStockItemName = '';
        this.queryStockItemStatus = '';
        this.queryStockItemCreatedAt = '';
        this.queryStockItemUpdatedAt = '';
        this.queryStockItemData = [];
        this.handleQueryStockItemClick = (_event) => {
            this.loadQueryStockItem();
        };
        this.handleQueryStockItemStockItemIdChange = (event) => {
            const target = event.target;
            this.setQueryStockItemStockItemId(target.value);
        };
        this.handleQueryStockItemNameChange = (event) => {
            const target = event.target;
            this.setQueryStockItemName(target.value);
        };
        this.handleQueryStockItemStatusChange = (event) => {
            const target = event.target;
            this.setQueryStockItemStatus(target.value);
        };
        this.handleQueryStockItemCreatedAtChange = (event) => {
            const target = event.target;
            this.setQueryStockItemCreatedAt(target.value);
        };
        this.handleQueryStockItemUpdatedAtChange = (event) => {
            const target = event.target;
            this.setQueryStockItemUpdatedAt(target.value);
        };
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        const savedStatus = getState('ui.queryStockItem.status');
        if (savedStatus !== undefined) {
            this.status = savedStatus;
        }
        const savedQueryState = getState('ui.queryStockItem.action.queryStockItem.status');
        if (savedQueryState !== undefined) {
            this.queryStockItemState = savedQueryState;
        }
        const savedStockItemId = getState('ui.queryStockItem.input.queryStockItem.stockItemId');
        if (savedStockItemId !== undefined) {
            this.queryStockItemStockItemId = savedStockItemId;
        }
        const savedName = getState('ui.queryStockItem.input.queryStockItem.name');
        if (savedName !== undefined) {
            this.queryStockItemName = savedName;
        }
        const savedInputStatus = getState('ui.queryStockItem.input.queryStockItem.status');
        if (savedInputStatus !== undefined) {
            this.queryStockItemStatus = savedInputStatus;
        }
        const savedCreatedAt = getState('ui.queryStockItem.input.queryStockItem.createdAt');
        if (savedCreatedAt !== undefined) {
            this.queryStockItemCreatedAt = savedCreatedAt;
        }
        const savedUpdatedAt = getState('ui.queryStockItem.input.queryStockItem.updatedAt');
        if (savedUpdatedAt !== undefined) {
            this.queryStockItemUpdatedAt = savedUpdatedAt;
        }
        const savedData = getState('ui.queryStockItem.data.queryStockItem');
        if (savedData !== undefined) {
            this.queryStockItemData = savedData;
        }
        subscribe([
            'ui.queryStockItem.status',
            'ui.queryStockItem.action.queryStockItem.status',
            'ui.queryStockItem.input.queryStockItem.stockItemId',
            'ui.queryStockItem.input.queryStockItem.name',
            'ui.queryStockItem.input.queryStockItem.status',
            'ui.queryStockItem.input.queryStockItem.createdAt',
            'ui.queryStockItem.input.queryStockItem.updatedAt',
            'ui.queryStockItem.data.queryStockItem',
        ], this);
        this.loadQueryStockItem();
    }
    disconnectedCallback() {
        unsubscribe([
            'ui.queryStockItem.status',
            'ui.queryStockItem.action.queryStockItem.status',
            'ui.queryStockItem.input.queryStockItem.stockItemId',
            'ui.queryStockItem.input.queryStockItem.name',
            'ui.queryStockItem.input.queryStockItem.status',
            'ui.queryStockItem.input.queryStockItem.createdAt',
            'ui.queryStockItem.input.queryStockItem.updatedAt',
            'ui.queryStockItem.data.queryStockItem',
        ], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.queryStockItem.status':
                this.status = value;
                break;
            case 'ui.queryStockItem.action.queryStockItem.status':
                this.queryStockItemState = value;
                break;
            case 'ui.queryStockItem.input.queryStockItem.stockItemId':
                this.queryStockItemStockItemId = value;
                break;
            case 'ui.queryStockItem.input.queryStockItem.name':
                this.queryStockItemName = value;
                break;
            case 'ui.queryStockItem.input.queryStockItem.status':
                this.queryStockItemStatus = value;
                break;
            case 'ui.queryStockItem.input.queryStockItem.createdAt':
                this.queryStockItemCreatedAt = value;
                break;
            case 'ui.queryStockItem.input.queryStockItem.updatedAt':
                this.queryStockItemUpdatedAt = value;
                break;
            case 'ui.queryStockItem.data.queryStockItem':
                this.queryStockItemData = value;
                break;
            default:
                break;
        }
    }
    // --- Query action: queryStockItem ---
    async loadQueryStockItem() {
        this.queryStockItemState = 'loading';
        setState('ui.queryStockItem.action.queryStockItem.status', 'loading');
        const params = {
            stockItemId: this.queryStockItemStockItemId || undefined,
            name: this.queryStockItemName || undefined,
            status: this.queryStockItemStatus || undefined,
            createdAt: this.queryStockItemCreatedAt || undefined,
            updatedAt: this.queryStockItemUpdatedAt || undefined,
        };
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.queryStockItem.queryStockItem', params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.queryStockItemData = data;
            setState('ui.queryStockItem.data.queryStockItem', data);
            this.queryStockItemState = 'success';
            setState('ui.queryStockItem.action.queryStockItem.status', 'success');
        }
        else {
            this.queryStockItemState = 'error';
            setState('ui.queryStockItem.action.queryStockItem.status', 'error');
        }
    }
    // --- State setters ---
    setQueryStockItemStockItemId(value) {
        this.queryStockItemStockItemId = value;
        setState('ui.queryStockItem.input.queryStockItem.stockItemId', value);
        this.requestUpdate();
    }
    setQueryStockItemName(value) {
        this.queryStockItemName = value;
        setState('ui.queryStockItem.input.queryStockItem.name', value);
        this.requestUpdate();
    }
    setQueryStockItemStatus(value) {
        this.queryStockItemStatus = value;
        setState('ui.queryStockItem.input.queryStockItem.status', value);
        this.requestUpdate();
    }
    setQueryStockItemCreatedAt(value) {
        this.queryStockItemCreatedAt = value;
        setState('ui.queryStockItem.input.queryStockItem.createdAt', value);
        this.requestUpdate();
    }
    setQueryStockItemUpdatedAt(value) {
        this.queryStockItemUpdatedAt = value;
        setState('ui.queryStockItem.input.queryStockItem.updatedAt', value);
        this.requestUpdate();
    }
}
__decorate([
    property({ type: String })
], CafeFlowQueryStockItemBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowQueryStockItemBase.prototype, "queryStockItemState", void 0);
__decorate([
    property({ type: String })
], CafeFlowQueryStockItemBase.prototype, "queryStockItemStockItemId", void 0);
__decorate([
    property({ type: String })
], CafeFlowQueryStockItemBase.prototype, "queryStockItemName", void 0);
__decorate([
    property({ type: String })
], CafeFlowQueryStockItemBase.prototype, "queryStockItemStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowQueryStockItemBase.prototype, "queryStockItemCreatedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowQueryStockItemBase.prototype, "queryStockItemUpdatedAt", void 0);
__decorate([
    property({ type: Array })
], CafeFlowQueryStockItemBase.prototype, "queryStockItemData", void 0);
