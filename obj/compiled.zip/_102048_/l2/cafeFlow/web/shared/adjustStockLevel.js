/// <mls fileReference="_102048_/l2/cafeFlow/web/shared/adjustStockLevel.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "adjustStockLevel.section.title": "Registrar Entrada/Ajuste de Estoque",
    "adjustStockLevel.organism.title": "Registrar Entrada/Ajuste de Estoque",
    "adjustStockLevel.intent.commandForm.title": "Registrar Entrada/Ajuste de Estoque",
    "adjustStockLevel.field.currentQuantity": "Quantidade atual",
    "adjustStockLevel.field.status": "Situação do estoque",
    "adjustStockLevel.action.submit": "Registrar ajuste"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowAdjustStockLevelBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = "";
        this.adjustStockLevelState = "idle";
        this.adjustStockLevelCurrentQuantity = "";
        this.adjustStockLevelStatus = "";
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState("ui.adjustStockLevel.status") ?? "";
        this.adjustStockLevelState = getState("ui.adjustStockLevel.action.adjustStockLevel.status") ?? "idle";
        this.adjustStockLevelCurrentQuantity = getState("ui.adjustStockLevel.input.adjustStockLevel.currentQuantity") ?? "";
        this.adjustStockLevelStatus = getState("ui.adjustStockLevel.input.adjustStockLevel.status") ?? "";
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    // --- StateSetter Actions ---
    setAdjustStockLevelCurrentQuantity(value) {
        this.adjustStockLevelCurrentQuantity = value;
        setState("ui.adjustStockLevel.input.adjustStockLevel.currentQuantity", value);
        this.requestUpdate();
    }
    handleAdjustStockLevelCurrentQuantityChange(e) {
        const target = e.target;
        this.setAdjustStockLevelCurrentQuantity(target.value);
    }
    setAdjustStockLevelStatus(value) {
        this.adjustStockLevelStatus = value;
        setState("ui.adjustStockLevel.input.adjustStockLevel.status", value);
        this.requestUpdate();
    }
    handleAdjustStockLevelStatusChange(e) {
        const target = e.target;
        this.setAdjustStockLevelStatus(target.value);
    }
    // --- Command Actions ---
    async adjustStockLevel() {
        this.adjustStockLevelState = "loading";
        setState("ui.adjustStockLevel.action.adjustStockLevel.status", "loading");
        const params = {
            currentQuantity: Number(this.adjustStockLevelCurrentQuantity),
            status: this.adjustStockLevelStatus,
        };
        const options = { mode: "blocking" };
        try {
            const response = await execBff("cafeFlow.adjustStockLevel.adjustStockLevel", params, options);
            if (response.ok) {
                this.adjustStockLevelState = "success";
                setState("ui.adjustStockLevel.action.adjustStockLevel.status", "success");
            }
            else {
                this.adjustStockLevelState = "error";
                setState("ui.adjustStockLevel.action.adjustStockLevel.status", "error");
            }
        }
        catch {
            this.adjustStockLevelState = "error";
            setState("ui.adjustStockLevel.action.adjustStockLevel.status", "error");
        }
    }
    async handleAdjustStockLevelClick(e) {
        e.preventDefault();
        await runBlockingUiAction(async (_signal) => {
            await this.adjustStockLevel();
        }, { mode: "blocking", busyLabel: this.msg["adjustStockLevel.action.submit"] });
    }
}
__decorate([
    property({ type: String })
], CafeFlowAdjustStockLevelBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowAdjustStockLevelBase.prototype, "adjustStockLevelState", void 0);
__decorate([
    property({ type: String })
], CafeFlowAdjustStockLevelBase.prototype, "adjustStockLevelCurrentQuantity", void 0);
__decorate([
    property({ type: String })
], CafeFlowAdjustStockLevelBase.prototype, "adjustStockLevelStatus", void 0);
