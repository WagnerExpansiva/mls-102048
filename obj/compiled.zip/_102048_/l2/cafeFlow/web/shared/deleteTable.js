/// <mls fileReference="_102048_/l2/cafeFlow/web/shared/deleteTable.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
/// **collab_i18n_start**
const message_pt = {
    "deleteTable.section.title": "Remover Mesa",
    "deleteTable.organism.title": "Remover Mesa",
    "deleteTable.intention.commandForm.title": "Command Form",
    "deleteTable.field.tableId": "Table Id",
    "deleteTable.field.tableNumber": "Table Number",
    "deleteTable.field.capacity": "Capacity",
    "deleteTable.field.status": "Status",
    "deleteTable.action.submit": "Delete Table"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowDeleteTableBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = "";
        this.deleteTableState = "idle";
        this.deleteTableTableId = "";
        this.deleteTableTableNumber = "";
        this.deleteTableCapacity = "";
        this.deleteTableStatus = "";
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState("ui.deleteTable.status") ?? "";
        this.deleteTableState = getState("ui.deleteTable.action.deleteTable.status") ?? "idle";
        this.deleteTableTableId = getState("ui.deleteTable.input.deleteTable.tableId") ?? "";
        this.deleteTableTableNumber = getState("ui.deleteTable.input.deleteTable.tableNumber") ?? "";
        this.deleteTableCapacity = getState("ui.deleteTable.input.deleteTable.capacity") ?? "";
        this.deleteTableStatus = getState("ui.deleteTable.input.deleteTable.status") ?? "";
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    // --- StateSetter actions ---
    setDeleteTableTableId(value) {
        this.deleteTableTableId = value;
        setState("ui.deleteTable.input.deleteTable.tableId", value);
        this.requestUpdate();
    }
    handleDeleteTableTableIdChange(e) {
        const target = e.target;
        this.setDeleteTableTableId(target.value);
    }
    setDeleteTableTableNumber(value) {
        this.deleteTableTableNumber = value;
        setState("ui.deleteTable.input.deleteTable.tableNumber", value);
        this.requestUpdate();
    }
    handleDeleteTableTableNumberChange(e) {
        const target = e.target;
        this.setDeleteTableTableNumber(target.value);
    }
    setDeleteTableCapacity(value) {
        this.deleteTableCapacity = value;
        setState("ui.deleteTable.input.deleteTable.capacity", value);
        this.requestUpdate();
    }
    handleDeleteTableCapacityChange(e) {
        const target = e.target;
        this.setDeleteTableCapacity(target.value);
    }
    setDeleteTableStatus(value) {
        this.deleteTableStatus = value;
        setState("ui.deleteTable.input.deleteTable.status", value);
        this.requestUpdate();
    }
    handleDeleteTableStatusChange(e) {
        const target = e.target;
        this.setDeleteTableStatus(target.value);
    }
    // --- Command action: deleteTable ---
    async deleteTable() {
        this.deleteTableState = "loading";
        setState("ui.deleteTable.action.deleteTable.status", "loading");
        this.requestUpdate();
        const params = {
            tableId: this.deleteTableTableId || undefined,
            tableNumber: this.deleteTableTableNumber,
            capacity: this.deleteTableCapacity ? Number(this.deleteTableCapacity) : undefined,
            status: this.deleteTableStatus,
        };
        const options = { mode: "blocking" };
        try {
            const response = await execBff("cafeFlow.deleteTable.deleteTable", params, options);
            if (response.ok) {
                this.deleteTableState = "success";
                setState("ui.deleteTable.action.deleteTable.status", "success");
            }
            else {
                this.deleteTableState = "error";
                setState("ui.deleteTable.action.deleteTable.status", "error");
            }
        }
        catch {
            this.deleteTableState = "error";
            setState("ui.deleteTable.action.deleteTable.status", "error");
        }
        this.requestUpdate();
    }
    handleDeleteTableClick(e) {
        e.preventDefault();
        runBlockingUiAction(async (_signal) => {
            await this.deleteTable();
        }, { mode: "blocking" });
    }
}
__decorate([
    property({ type: String })
], CafeFlowDeleteTableBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowDeleteTableBase.prototype, "deleteTableState", void 0);
__decorate([
    property({ type: String })
], CafeFlowDeleteTableBase.prototype, "deleteTableTableId", void 0);
__decorate([
    property({ type: String })
], CafeFlowDeleteTableBase.prototype, "deleteTableTableNumber", void 0);
__decorate([
    property({ type: String })
], CafeFlowDeleteTableBase.prototype, "deleteTableCapacity", void 0);
__decorate([
    property({ type: String })
], CafeFlowDeleteTableBase.prototype, "deleteTableStatus", void 0);
