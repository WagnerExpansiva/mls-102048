/// <mls fileReference="_102048_/l2/cafeFlow/web/shared/updateTable.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "updateTable.section.editTable.title": "Editar Mesa",
    "updateTable.organism.updateTableForm.title": "Editar Mesa",
    "updateTable.intention.commandForm.title": "Editar Mesa",
    "updateTable.field.tableNumber.label": "Número da Mesa",
    "updateTable.field.capacity.label": "Capacidade",
    "updateTable.field.status.label": "Status",
    "updateTable.action.updateTable.submit.label": "Salvar Alterações"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowUpdateTableBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.updateTableState = 'idle';
        this.updateTableTableNumber = '';
        this.updateTableCapacity = '';
        this.updateTableStatus = '';
        this.handleUpdateTableTableNumberChange = (event) => {
            const target = event.target;
            this.setUpdateTableTableNumber(target.value);
        };
        this.handleUpdateTableCapacityChange = (event) => {
            const target = event.target;
            this.setUpdateTableCapacity(target.value);
        };
        this.handleUpdateTableStatusChange = (event) => {
            const target = event.target;
            this.setUpdateTableStatus(target.value);
        };
        this.handleUpdateTableClick = () => {
            runBlockingUiAction(async (_signal) => {
                await this.updateTable();
            }, { mode: 'blocking' });
        };
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    /* ---- State setters ---- */
    setUpdateTableTableNumber(value) {
        this.updateTableTableNumber = value;
        setState('ui.updateTable.input.updateTable.tableNumber', value);
        this.requestUpdate();
    }
    setUpdateTableCapacity(value) {
        this.updateTableCapacity = value;
        setState('ui.updateTable.input.updateTable.capacity', value);
        this.requestUpdate();
    }
    setUpdateTableStatus(value) {
        this.updateTableStatus = value;
        setState('ui.updateTable.input.updateTable.status', value);
        this.requestUpdate();
    }
    /* ---- Command action: updateTable ---- */
    async updateTable() {
        this.updateTableState = 'loading';
        setState('ui.updateTable.action.updateTable.status', 'loading');
        this.requestUpdate();
        const params = {
            tableNumber: this.updateTableTableNumber,
            capacity: this.updateTableCapacity !== '' ? Number(this.updateTableCapacity) : undefined,
            status: this.updateTableStatus,
        };
        const options = { mode: 'blocking' };
        try {
            const response = await execBff('cafeFlow.updateTable.updateTable', params, options);
            if (response.ok) {
                this.updateTableState = 'success';
                setState('ui.updateTable.action.updateTable.status', 'success');
            }
            else {
                this.updateTableState = 'error';
                setState('ui.updateTable.action.updateTable.status', 'error');
            }
        }
        catch {
            this.updateTableState = 'error';
            setState('ui.updateTable.action.updateTable.status', 'error');
        }
        this.requestUpdate();
    }
    /* ---- Lifecycle ---- */
    connectedCallback() {
        super.connectedCallback();
        const persistedStatus = getState('ui.updateTable.status');
        if (persistedStatus !== undefined) {
            this.status = persistedStatus;
        }
        const persistedActionStatus = getState('ui.updateTable.action.updateTable.status');
        if (persistedActionStatus !== undefined) {
            this.updateTableState = persistedActionStatus;
        }
        const persistedTableNumber = getState('ui.updateTable.input.updateTable.tableNumber');
        if (persistedTableNumber !== undefined) {
            this.updateTableTableNumber = persistedTableNumber;
        }
        const persistedCapacity = getState('ui.updateTable.input.updateTable.capacity');
        if (persistedCapacity !== undefined) {
            this.updateTableCapacity = String(persistedCapacity);
        }
        const persistedTableStatus = getState('ui.updateTable.input.updateTable.status');
        if (persistedTableStatus !== undefined) {
            this.updateTableStatus = persistedTableStatus;
        }
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], CafeFlowUpdateTableBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowUpdateTableBase.prototype, "updateTableState", void 0);
__decorate([
    property({ type: String })
], CafeFlowUpdateTableBase.prototype, "updateTableTableNumber", void 0);
__decorate([
    property({ type: String })
], CafeFlowUpdateTableBase.prototype, "updateTableCapacity", void 0);
__decorate([
    property({ type: String })
], CafeFlowUpdateTableBase.prototype, "updateTableStatus", void 0);
