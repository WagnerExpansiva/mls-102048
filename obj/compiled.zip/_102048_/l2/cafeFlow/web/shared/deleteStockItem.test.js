/// <mls fileReference="_102048_/l2/cafeFlow/web/shared/deleteStockItem.test.ts" enhancement="_102020_/l2/enhancementAura"/>
export {};
