/// <mls fileReference="_102048_/l2/cafeFlow/web/shared/orderLifecycle.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "orderLifecycle.section.main.title": "Ciclo de Vida do Pedido",
    "orderLifecycle.organism.launchOrder.title": "Lançar Pedido (POS)",
    "orderLifecycle.intent.launchOrder.form.title": "Command Form",
    "orderLifecycle.field.launchOrder.type": "Type",
    "orderLifecycle.field.launchOrder.status": "Status",
    "orderLifecycle.field.launchOrder.total": "Total",
    "orderLifecycle.action.launchOrder.submit": "Launch Order",
    "orderLifecycle.organism.updateOrderStatus.title": "Atualizar Status do Pedido",
    "orderLifecycle.intent.updateOrderStatus.form.title": "Command Form",
    "orderLifecycle.field.updateOrderStatus.orderStatusEventId": "Order Status Event Id",
    "orderLifecycle.field.updateOrderStatus.orderId": "Order Id",
    "orderLifecycle.field.updateOrderStatus.previousStatus": "Previous Status",
    "orderLifecycle.field.updateOrderStatus.status": "Status",
    "orderLifecycle.action.updateOrderStatus.submit": "Update Order Status",
    "orderLifecycle.organism.processPayment.title": "Processar Pagamento e Fechar Pedido",
    "orderLifecycle.intent.processPayment.form.title": "Command Form",
    "orderLifecycle.field.processPayment.status": "Status",
    "orderLifecycle.action.processPayment.submit": "Process Payment",
    "orderLifecycle.organism.summary.title": "Revisar o contexto e o resultado das ações principais da página",
    "orderLifecycle.intent.summary.title": "Summary",
    "orderLifecycle.field.summary.status": "Status",
    "orderLifecycle.field.summary.total": "Total"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowOrderLifecycleBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.launchOrderState = "idle";
        this.launchOrderType = '';
        this.launchOrderStatus = '';
        this.launchOrderTotal = '';
        this.updateOrderStatusState = "idle";
        this.updateOrderStatusOrderStatusEventId = '';
        this.updateOrderStatusOrderId = '';
        this.updateOrderStatusPreviousStatus = '';
        this.updateOrderStatusStatus = '';
        this.processPaymentState = "idle";
        this.processPaymentStatus = '';
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.orderLifecycle.status') ?? '';
        this.launchOrderState = getState('ui.orderLifecycle.action.launchOrder.status') ?? "idle";
        this.launchOrderType = getState('ui.orderLifecycle.input.launchOrder.type') ?? '';
        this.launchOrderStatus = getState('ui.orderLifecycle.input.launchOrder.status') ?? '';
        this.launchOrderTotal = getState('ui.orderLifecycle.input.launchOrder.total') ?? '';
        this.updateOrderStatusState = getState('ui.orderLifecycle.action.updateOrderStatus.status') ?? "idle";
        this.updateOrderStatusOrderStatusEventId = getState('ui.orderLifecycle.input.updateOrderStatus.orderStatusEventId') ?? '';
        this.updateOrderStatusOrderId = getState('ui.orderLifecycle.input.updateOrderStatus.orderId') ?? '';
        this.updateOrderStatusPreviousStatus = getState('ui.orderLifecycle.input.updateOrderStatus.previousStatus') ?? '';
        this.updateOrderStatusStatus = getState('ui.orderLifecycle.input.updateOrderStatus.status') ?? '';
        this.processPaymentState = getState('ui.orderLifecycle.action.processPayment.status') ?? "idle";
        this.processPaymentStatus = getState('ui.orderLifecycle.input.processPayment.status') ?? '';
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    // --- State setters ---
    setLaunchOrderType(value) {
        this.launchOrderType = value;
        setState('ui.orderLifecycle.input.launchOrder.type', value);
        this.requestUpdate();
    }
    handleLaunchOrderTypeChange(e) {
        const target = e.target;
        this.setLaunchOrderType(target.value);
    }
    setLaunchOrderStatus(value) {
        this.launchOrderStatus = value;
        setState('ui.orderLifecycle.input.launchOrder.status', value);
        this.requestUpdate();
    }
    handleLaunchOrderStatusChange(e) {
        const target = e.target;
        this.setLaunchOrderStatus(target.value);
    }
    setLaunchOrderTotal(value) {
        this.launchOrderTotal = value;
        setState('ui.orderLifecycle.input.launchOrder.total', value);
        this.requestUpdate();
    }
    handleLaunchOrderTotalChange(e) {
        const target = e.target;
        this.setLaunchOrderTotal(target.value);
    }
    setUpdateOrderStatusOrderStatusEventId(value) {
        this.updateOrderStatusOrderStatusEventId = value;
        setState('ui.orderLifecycle.input.updateOrderStatus.orderStatusEventId', value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusOrderStatusEventIdChange(e) {
        const target = e.target;
        this.setUpdateOrderStatusOrderStatusEventId(target.value);
    }
    setUpdateOrderStatusOrderId(value) {
        this.updateOrderStatusOrderId = value;
        setState('ui.orderLifecycle.input.updateOrderStatus.orderId', value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusOrderIdChange(e) {
        const target = e.target;
        this.setUpdateOrderStatusOrderId(target.value);
    }
    setUpdateOrderStatusPreviousStatus(value) {
        this.updateOrderStatusPreviousStatus = value;
        setState('ui.orderLifecycle.input.updateOrderStatus.previousStatus', value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusPreviousStatusChange(e) {
        const target = e.target;
        this.setUpdateOrderStatusPreviousStatus(target.value);
    }
    setUpdateOrderStatusStatus(value) {
        this.updateOrderStatusStatus = value;
        setState('ui.orderLifecycle.input.updateOrderStatus.status', value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusStatusChange(e) {
        const target = e.target;
        this.setUpdateOrderStatusStatus(target.value);
    }
    setProcessPaymentStatus(value) {
        this.processPaymentStatus = value;
        setState('ui.orderLifecycle.input.processPayment.status', value);
        this.requestUpdate();
    }
    handleProcessPaymentStatusChange(e) {
        const target = e.target;
        this.setProcessPaymentStatus(target.value);
    }
    // --- Command actions ---
    async launchOrder() {
        this.launchOrderState = "loading";
        setState('ui.orderLifecycle.action.launchOrder.status', "loading");
        const params = {
            type: this.launchOrderType,
            status: this.launchOrderStatus,
            total: Number(this.launchOrderTotal) || 0,
        };
        const options = { mode: 'blocking' };
        try {
            const response = await execBff('cafeFlow.orderLifecycle.launchOrder', params, options);
            if (response.ok) {
                this.launchOrderState = "success";
                setState('ui.orderLifecycle.action.launchOrder.status', "success");
            }
            else {
                this.launchOrderState = "error";
                setState('ui.orderLifecycle.action.launchOrder.status', "error");
            }
        }
        catch {
            this.launchOrderState = "error";
            setState('ui.orderLifecycle.action.launchOrder.status', "error");
        }
    }
    handleLaunchOrderClick(e) {
        e.preventDefault();
        void runBlockingUiAction(async (_signal) => {
            await this.launchOrder();
        }, { mode: 'blocking' });
    }
    async updateOrderStatus() {
        this.updateOrderStatusState = "loading";
        setState('ui.orderLifecycle.action.updateOrderStatus.status', "loading");
        const params = {
            orderStatusEventId: this.updateOrderStatusOrderStatusEventId || undefined,
            orderId: this.updateOrderStatusOrderId || undefined,
            previousStatus: this.updateOrderStatusPreviousStatus || undefined,
            status: this.updateOrderStatusStatus,
        };
        const options = { mode: 'blocking' };
        try {
            const response = await execBff('cafeFlow.orderLifecycle.updateOrderStatus', params, options);
            if (response.ok) {
                this.updateOrderStatusState = "success";
                setState('ui.orderLifecycle.action.updateOrderStatus.status', "success");
            }
            else {
                this.updateOrderStatusState = "error";
                setState('ui.orderLifecycle.action.updateOrderStatus.status', "error");
            }
        }
        catch {
            this.updateOrderStatusState = "error";
            setState('ui.orderLifecycle.action.updateOrderStatus.status', "error");
        }
    }
    handleUpdateOrderStatusClick(e) {
        e.preventDefault();
        void runBlockingUiAction(async (_signal) => {
            await this.updateOrderStatus();
        }, { mode: 'blocking' });
    }
    async processPayment() {
        this.processPaymentState = "loading";
        setState('ui.orderLifecycle.action.processPayment.status', "loading");
        const params = {
            status: this.processPaymentStatus,
        };
        const options = { mode: 'blocking' };
        try {
            const response = await execBff('cafeFlow.orderLifecycle.processPayment', params, options);
            if (response.ok) {
                this.processPaymentState = "success";
                setState('ui.orderLifecycle.action.processPayment.status', "success");
            }
            else {
                this.processPaymentState = "error";
                setState('ui.orderLifecycle.action.processPayment.status', "error");
            }
        }
        catch {
            this.processPaymentState = "error";
            setState('ui.orderLifecycle.action.processPayment.status', "error");
        }
    }
    handleProcessPaymentClick(e) {
        e.preventDefault();
        void runBlockingUiAction(async (_signal) => {
            await this.processPayment();
        }, { mode: 'blocking' });
    }
}
__decorate([
    property({ type: String })
], CafeFlowOrderLifecycleBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowOrderLifecycleBase.prototype, "launchOrderState", void 0);
__decorate([
    property({ type: String })
], CafeFlowOrderLifecycleBase.prototype, "launchOrderType", void 0);
__decorate([
    property({ type: String })
], CafeFlowOrderLifecycleBase.prototype, "launchOrderStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowOrderLifecycleBase.prototype, "launchOrderTotal", void 0);
__decorate([
    property({ type: String })
], CafeFlowOrderLifecycleBase.prototype, "updateOrderStatusState", void 0);
__decorate([
    property({ type: String })
], CafeFlowOrderLifecycleBase.prototype, "updateOrderStatusOrderStatusEventId", void 0);
__decorate([
    property({ type: String })
], CafeFlowOrderLifecycleBase.prototype, "updateOrderStatusOrderId", void 0);
__decorate([
    property({ type: String })
], CafeFlowOrderLifecycleBase.prototype, "updateOrderStatusPreviousStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowOrderLifecycleBase.prototype, "updateOrderStatusStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowOrderLifecycleBase.prototype, "processPaymentState", void 0);
__decorate([
    property({ type: String })
], CafeFlowOrderLifecycleBase.prototype, "processPaymentStatus", void 0);
