/// <mls fileReference="_102048_/l2/cafeFlow/web/shared/updateStockItem.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "section.editStockItem.title": "Editar Item de Estoque",
    "organism.updateStockItem.title": "Editar Item de Estoque",
    "intention.updateStockItemForm.title": "Dados do item de estoque",
    "field.name.label": "Nome",
    "field.unitOfMeasure.label": "Unidade de medida",
    "field.minimumStockLevel.label": "Estoque mínimo",
    "field.status.label": "Status",
    "action.updateStockItem.label": "Salvar alterações"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowUpdateStockItemBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.updateStockItemState = "idle";
        this.updateStockItemName = '';
        this.updateStockItemUnitOfMeasure = '';
        this.updateStockItemMinimumStockLevel = '';
        this.updateStockItemStatus = '';
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.updateStockItem.status') ?? '';
        this.updateStockItemState = getState('ui.updateStockItem.action.updateStockItem.status') ?? "idle";
        this.updateStockItemName = getState('ui.updateStockItem.input.updateStockItem.name') ?? '';
        this.updateStockItemUnitOfMeasure = getState('ui.updateStockItem.input.updateStockItem.unitOfMeasure') ?? '';
        this.updateStockItemMinimumStockLevel = getState('ui.updateStockItem.input.updateStockItem.minimumStockLevel') ?? '';
        this.updateStockItemStatus = getState('ui.updateStockItem.input.updateStockItem.status') ?? '';
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    // --- StateSetter actions ---
    setUpdateStockItemName(value) {
        this.updateStockItemName = value;
        setState('ui.updateStockItem.input.updateStockItem.name', value);
        this.requestUpdate();
    }
    handleUpdateStockItemNameChange(e) {
        const target = e.target;
        this.setUpdateStockItemName(target.value);
    }
    setUpdateStockItemUnitOfMeasure(value) {
        this.updateStockItemUnitOfMeasure = value;
        setState('ui.updateStockItem.input.updateStockItem.unitOfMeasure', value);
        this.requestUpdate();
    }
    handleUpdateStockItemUnitOfMeasureChange(e) {
        const target = e.target;
        this.setUpdateStockItemUnitOfMeasure(target.value);
    }
    setUpdateStockItemMinimumStockLevel(value) {
        this.updateStockItemMinimumStockLevel = value;
        setState('ui.updateStockItem.input.updateStockItem.minimumStockLevel', value);
        this.requestUpdate();
    }
    handleUpdateStockItemMinimumStockLevelChange(e) {
        const target = e.target;
        this.setUpdateStockItemMinimumStockLevel(target.value);
    }
    setUpdateStockItemStatus(value) {
        this.updateStockItemStatus = value;
        setState('ui.updateStockItem.input.updateStockItem.status', value);
        this.requestUpdate();
    }
    handleUpdateStockItemStatusChange(e) {
        const target = e.target;
        this.setUpdateStockItemStatus(target.value);
    }
    // --- Command actions ---
    async updateStockItem() {
        this.updateStockItemState = "loading";
        setState('ui.updateStockItem.action.updateStockItem.status', "loading");
        const params = {
            name: this.updateStockItemName,
            unitOfMeasure: this.updateStockItemUnitOfMeasure,
            minimumStockLevel: Number(this.updateStockItemMinimumStockLevel),
            status: this.updateStockItemStatus
        };
        const options = { mode: 'blocking' };
        try {
            const response = await execBff('cafeFlow.updateStockItem.updateStockItem', params, options);
            if (response.ok) {
                this.updateStockItemState = "success";
                setState('ui.updateStockItem.action.updateStockItem.status', "success");
            }
            else {
                this.updateStockItemState = "error";
                setState('ui.updateStockItem.action.updateStockItem.status', "error");
            }
        }
        catch {
            this.updateStockItemState = "error";
            setState('ui.updateStockItem.action.updateStockItem.status', "error");
        }
    }
    handleUpdateStockItemClick(e) {
        e.preventDefault();
        runBlockingUiAction(async (_signal) => {
            await this.updateStockItem();
        }, { mode: 'blocking' });
    }
}
__decorate([
    property({ type: String })
], CafeFlowUpdateStockItemBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowUpdateStockItemBase.prototype, "updateStockItemState", void 0);
__decorate([
    property({ type: String })
], CafeFlowUpdateStockItemBase.prototype, "updateStockItemName", void 0);
__decorate([
    property({ type: String })
], CafeFlowUpdateStockItemBase.prototype, "updateStockItemUnitOfMeasure", void 0);
__decorate([
    property({ type: String })
], CafeFlowUpdateStockItemBase.prototype, "updateStockItemMinimumStockLevel", void 0);
__decorate([
    property({ type: String })
], CafeFlowUpdateStockItemBase.prototype, "updateStockItemStatus", void 0);
