/// <mls fileReference="_102048_/l2/cafeFlow/web/shared/queryTable.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "queryTable.section.title": "Consultar Mesas",
    "queryTable.organism.title": "Consultar Mesas",
    "queryTable.intent.list.title": "Lista de mesas",
    "queryTable.field.tableId": "ID da mesa",
    "queryTable.field.tableNumber": "Número da mesa",
    "queryTable.field.capacity": "Capacidade",
    "queryTable.field.status": "Status",
    "queryTable.field.createdAt": "Criada em",
    "queryTable.field.updatedAt": "Atualizada em",
    "queryTable.filter.tableId": "ID da mesa",
    "queryTable.filter.status": "Status",
    "queryTable.filter.createdAt": "Criada em",
    "queryTable.filter.updatedAt": "Atualizada em",
    "queryTable.action.query": "Consultar"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowQueryTableBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.queryTableState = 'idle';
        this.queryTableTableId = '';
        this.queryTableStatus = '';
        this.queryTableCreatedAt = '';
        this.queryTableUpdatedAt = '';
        this.queryTableData = [];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        const existingStatus = getState('ui.queryTable.status');
        if (typeof existingStatus === 'string') {
            this.status = existingStatus;
        }
        const existingQueryTableState = getState('ui.queryTable.action.queryTable.status');
        if (typeof existingQueryTableState === 'string') {
            this.queryTableState = existingQueryTableState;
        }
        const existingTableId = getState('ui.queryTable.input.queryTable.tableId');
        if (typeof existingTableId === 'string') {
            this.queryTableTableId = existingTableId;
        }
        const existingQueryStatus = getState('ui.queryTable.input.queryTable.status');
        if (typeof existingQueryStatus === 'string') {
            this.queryTableStatus = existingQueryStatus;
        }
        const existingCreatedAt = getState('ui.queryTable.input.queryTable.createdAt');
        if (typeof existingCreatedAt === 'string') {
            this.queryTableCreatedAt = existingCreatedAt;
        }
        const existingUpdatedAt = getState('ui.queryTable.input.queryTable.updatedAt');
        if (typeof existingUpdatedAt === 'string') {
            this.queryTableUpdatedAt = existingUpdatedAt;
        }
        const existingData = getState('ui.queryTable.data.queryTable');
        if (Array.isArray(existingData)) {
            this.queryTableData = existingData;
        }
        subscribe([
            'ui.queryTable.status',
            'ui.queryTable.action.queryTable.status',
            'ui.queryTable.input.queryTable.tableId',
            'ui.queryTable.input.queryTable.status',
            'ui.queryTable.input.queryTable.createdAt',
            'ui.queryTable.input.queryTable.updatedAt',
            'ui.queryTable.data.queryTable',
        ], this);
        this.loadQueryTable();
    }
    disconnectedCallback() {
        unsubscribe([
            'ui.queryTable.status',
            'ui.queryTable.action.queryTable.status',
            'ui.queryTable.input.queryTable.tableId',
            'ui.queryTable.input.queryTable.status',
            'ui.queryTable.input.queryTable.createdAt',
            'ui.queryTable.input.queryTable.updatedAt',
            'ui.queryTable.data.queryTable',
        ], this);
        super.disconnectedCallback();
    }
    async loadQueryTable() {
        this.queryTableState = 'loading';
        setState('ui.queryTable.action.queryTable.status', 'loading');
        this.requestUpdate();
        const params = {
            tableId: this.queryTableTableId || undefined,
            status: this.queryTableStatus || undefined,
            createdAt: this.queryTableCreatedAt || undefined,
            updatedAt: this.queryTableUpdatedAt || undefined,
        };
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.queryTable.queryTable', params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.queryTableData = data;
            setState('ui.queryTable.data.queryTable', data);
            this.queryTableState = 'success';
            setState('ui.queryTable.action.queryTable.status', 'success');
        }
        else {
            this.queryTableData = [];
            setState('ui.queryTable.data.queryTable', []);
            this.queryTableState = 'error';
            setState('ui.queryTable.action.queryTable.status', 'error');
        }
        this.requestUpdate();
    }
    handleQueryTableClick(_event) {
        this.loadQueryTable();
    }
    setQueryTableTableId(value) {
        this.queryTableTableId = value;
        setState('ui.queryTable.input.queryTable.tableId', value);
        this.requestUpdate();
    }
    handleQueryTableTableIdChange(event) {
        const target = event.target;
        this.setQueryTableTableId(target.value);
    }
    setQueryTableStatus(value) {
        this.queryTableStatus = value;
        setState('ui.queryTable.input.queryTable.status', value);
        this.requestUpdate();
    }
    handleQueryTableStatusChange(event) {
        const target = event.target;
        this.setQueryTableStatus(target.value);
    }
    setQueryTableCreatedAt(value) {
        this.queryTableCreatedAt = value;
        setState('ui.queryTable.input.queryTable.createdAt', value);
        this.requestUpdate();
    }
    handleQueryTableCreatedAtChange(event) {
        const target = event.target;
        this.setQueryTableCreatedAt(target.value);
    }
    setQueryTableUpdatedAt(value) {
        this.queryTableUpdatedAt = value;
        setState('ui.queryTable.input.queryTable.updatedAt', value);
        this.requestUpdate();
    }
    handleQueryTableUpdatedAtChange(event) {
        const target = event.target;
        this.setQueryTableUpdatedAt(target.value);
    }
}
__decorate([
    property({ type: String })
], CafeFlowQueryTableBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowQueryTableBase.prototype, "queryTableState", void 0);
__decorate([
    property({ type: String })
], CafeFlowQueryTableBase.prototype, "queryTableTableId", void 0);
__decorate([
    property({ type: String })
], CafeFlowQueryTableBase.prototype, "queryTableStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowQueryTableBase.prototype, "queryTableCreatedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowQueryTableBase.prototype, "queryTableUpdatedAt", void 0);
__decorate([
    property({ type: Array })
], CafeFlowQueryTableBase.prototype, "queryTableData", void 0);
