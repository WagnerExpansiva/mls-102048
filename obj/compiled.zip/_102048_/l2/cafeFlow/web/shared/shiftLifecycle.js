/// <mls fileReference="_102048_/l2/cafeFlow/web/shared/shiftLifecycle.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "shiftLifecycle.section.main.title": "Ciclo de Vida do Turno Diário",
    "shiftLifecycle.organism.viewDashboard.title": "Visualizar Dashboard",
    "shiftLifecycle.intention.viewDashboard.query.title": "Query List",
    "shiftLifecycle.field.dailyShiftId": "Daily Shift Id",
    "shiftLifecycle.field.date": "Date",
    "shiftLifecycle.field.openTime": "Open Time",
    "shiftLifecycle.field.closeTime": "Close Time",
    "shiftLifecycle.field.status": "Status",
    "shiftLifecycle.field.totalSales": "Total Sales",
    "shiftLifecycle.field.createdAt": "Created At",
    "shiftLifecycle.field.updatedAt": "Updated At",
    "shiftLifecycle.action.viewDashboard": "View Dashboard",
    "shiftLifecycle.organism.viewShiftReport.title": "Visualizar Relatório de Fechamento de Turno",
    "shiftLifecycle.intention.viewShiftReport.query.title": "Query List",
    "shiftLifecycle.field.shiftCloseReportId": "Shift Close Report Id",
    "shiftLifecycle.field.totalOrders": "Total Orders",
    "shiftLifecycle.field.bestSellingItems": "Best Selling Items",
    "shiftLifecycle.field.stockConsumptionSummary": "Stock Consumption Summary",
    "shiftLifecycle.field.operationalMetrics": "Operational Metrics",
    "shiftLifecycle.action.viewShiftReport": "View Shift Report",
    "shiftLifecycle.intention.summary.title": "Summary"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowShiftLifecycleBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.viewDashboardState = 'idle';
        this.viewDashboardDailyShiftId = '';
        this.viewDashboardDate = '';
        this.viewDashboardStatus = '';
        this.viewDashboardCreatedAt = '';
        this.viewDashboardUpdatedAt = '';
        this.viewDashboardData = [];
        this.viewShiftReportState = 'idle';
        this.viewShiftReportShiftCloseReportId = '';
        this.viewShiftReportDailyShiftId = '';
        this.viewShiftReportCreatedAt = '';
        this.viewShiftReportUpdatedAt = '';
        this.viewShiftReportData = [];
        // ---- State key mapping ----
        this.stateKeyMap = {
            'ui.shiftLifecycle.status': 'status',
            'ui.shiftLifecycle.action.viewDashboard.status': 'viewDashboardState',
            'ui.shiftLifecycle.input.viewDashboard.dailyShiftId': 'viewDashboardDailyShiftId',
            'ui.shiftLifecycle.input.viewDashboard.date': 'viewDashboardDate',
            'ui.shiftLifecycle.input.viewDashboard.status': 'viewDashboardStatus',
            'ui.shiftLifecycle.input.viewDashboard.createdAt': 'viewDashboardCreatedAt',
            'ui.shiftLifecycle.input.viewDashboard.updatedAt': 'viewDashboardUpdatedAt',
            'ui.shiftLifecycle.data.viewDashboard': 'viewDashboardData',
            'ui.shiftLifecycle.action.viewShiftReport.status': 'viewShiftReportState',
            'ui.shiftLifecycle.input.viewShiftReport.shiftCloseReportId': 'viewShiftReportShiftCloseReportId',
            'ui.shiftLifecycle.input.viewShiftReport.dailyShiftId': 'viewShiftReportDailyShiftId',
            'ui.shiftLifecycle.input.viewShiftReport.createdAt': 'viewShiftReportCreatedAt',
            'ui.shiftLifecycle.input.viewShiftReport.updatedAt': 'viewShiftReportUpdatedAt',
            'ui.shiftLifecycle.data.viewShiftReport': 'viewShiftReportData',
        };
        this.subscribedKeys = [];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    // ---- Query: viewDashboard ----
    async loadViewDashboard() {
        this.viewDashboardState = 'loading';
        setState('ui.shiftLifecycle.action.viewDashboard.status', 'loading');
        const params = {
            dailyShiftId: this.viewDashboardDailyShiftId || undefined,
            date: this.viewDashboardDate || undefined,
            status: this.viewDashboardStatus || undefined,
            createdAt: this.viewDashboardCreatedAt || undefined,
            updatedAt: this.viewDashboardUpdatedAt || undefined,
        };
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.shiftLifecycle.viewDashboard', params, options);
        if (response.ok) {
            this.viewDashboardData = response.data ?? [];
            setState('ui.shiftLifecycle.data.viewDashboard', this.viewDashboardData);
            this.viewDashboardState = 'success';
            setState('ui.shiftLifecycle.action.viewDashboard.status', 'success');
        }
        else {
            this.viewDashboardData = [];
            setState('ui.shiftLifecycle.data.viewDashboard', []);
            this.viewDashboardState = 'error';
            setState('ui.shiftLifecycle.action.viewDashboard.status', 'error');
        }
        this.requestUpdate();
    }
    handleViewDashboardClick(_e) {
        void this.loadViewDashboard();
    }
    // ---- Query: viewShiftReport ----
    async loadViewShiftReport() {
        this.viewShiftReportState = 'loading';
        setState('ui.shiftLifecycle.action.viewShiftReport.status', 'loading');
        const params = {
            shiftCloseReportId: this.viewShiftReportShiftCloseReportId || undefined,
            dailyShiftId: this.viewShiftReportDailyShiftId || undefined,
            createdAt: this.viewShiftReportCreatedAt || undefined,
            updatedAt: this.viewShiftReportUpdatedAt || undefined,
        };
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.shiftLifecycle.viewShiftReport', params, options);
        if (response.ok) {
            this.viewShiftReportData = response.data ?? [];
            setState('ui.shiftLifecycle.data.viewShiftReport', this.viewShiftReportData);
            this.viewShiftReportState = 'success';
            setState('ui.shiftLifecycle.action.viewShiftReport.status', 'success');
        }
        else {
            this.viewShiftReportData = [];
            setState('ui.shiftLifecycle.data.viewShiftReport', []);
            this.viewShiftReportState = 'error';
            setState('ui.shiftLifecycle.action.viewShiftReport.status', 'error');
        }
        this.requestUpdate();
    }
    handleViewShiftReportClick(_e) {
        void this.loadViewShiftReport();
    }
    // ---- StateSetters: viewDashboard inputs ----
    setViewDashboardDailyShiftId(value) {
        this.viewDashboardDailyShiftId = value;
        setState('ui.shiftLifecycle.input.viewDashboard.dailyShiftId', value);
        this.requestUpdate();
    }
    handleViewDashboardDailyShiftIdChange(e) {
        const target = e.target;
        this.setViewDashboardDailyShiftId(target.value);
    }
    setViewDashboardDate(value) {
        this.viewDashboardDate = value;
        setState('ui.shiftLifecycle.input.viewDashboard.date', value);
        this.requestUpdate();
    }
    handleViewDashboardDateChange(e) {
        const target = e.target;
        this.setViewDashboardDate(target.value);
    }
    setViewDashboardStatus(value) {
        this.viewDashboardStatus = value;
        setState('ui.shiftLifecycle.input.viewDashboard.status', value);
        this.requestUpdate();
    }
    handleViewDashboardStatusChange(e) {
        const target = e.target;
        this.setViewDashboardStatus(target.value);
    }
    setViewDashboardCreatedAt(value) {
        this.viewDashboardCreatedAt = value;
        setState('ui.shiftLifecycle.input.viewDashboard.createdAt', value);
        this.requestUpdate();
    }
    handleViewDashboardCreatedAtChange(e) {
        const target = e.target;
        this.setViewDashboardCreatedAt(target.value);
    }
    setViewDashboardUpdatedAt(value) {
        this.viewDashboardUpdatedAt = value;
        setState('ui.shiftLifecycle.input.viewDashboard.updatedAt', value);
        this.requestUpdate();
    }
    handleViewDashboardUpdatedAtChange(e) {
        const target = e.target;
        this.setViewDashboardUpdatedAt(target.value);
    }
    // ---- StateSetters: viewShiftReport inputs ----
    setViewShiftReportShiftCloseReportId(value) {
        this.viewShiftReportShiftCloseReportId = value;
        setState('ui.shiftLifecycle.input.viewShiftReport.shiftCloseReportId', value);
        this.requestUpdate();
    }
    handleViewShiftReportShiftCloseReportIdChange(e) {
        const target = e.target;
        this.setViewShiftReportShiftCloseReportId(target.value);
    }
    setViewShiftReportDailyShiftId(value) {
        this.viewShiftReportDailyShiftId = value;
        setState('ui.shiftLifecycle.input.viewShiftReport.dailyShiftId', value);
        this.requestUpdate();
    }
    handleViewShiftReportDailyShiftIdChange(e) {
        const target = e.target;
        this.setViewShiftReportDailyShiftId(target.value);
    }
    setViewShiftReportCreatedAt(value) {
        this.viewShiftReportCreatedAt = value;
        setState('ui.shiftLifecycle.input.viewShiftReport.createdAt', value);
        this.requestUpdate();
    }
    handleViewShiftReportCreatedAtChange(e) {
        const target = e.target;
        this.setViewShiftReportCreatedAt(target.value);
    }
    setViewShiftReportUpdatedAt(value) {
        this.viewShiftReportUpdatedAt = value;
        setState('ui.shiftLifecycle.input.viewShiftReport.updatedAt', value);
        this.requestUpdate();
    }
    handleViewShiftReportUpdatedAtChange(e) {
        const target = e.target;
        this.setViewShiftReportUpdatedAt(target.value);
    }
    // ---- Lifecycle ----
    connectedCallback() {
        super.connectedCallback();
        // Initialize state from global store, falling back to defaults
        const savedStatus = getState('ui.shiftLifecycle.status');
        this.status = savedStatus !== undefined ? savedStatus : '';
        const savedViewDashboardState = getState('ui.shiftLifecycle.action.viewDashboard.status');
        this.viewDashboardState = savedViewDashboardState !== undefined ? savedViewDashboardState : 'idle';
        const savedViewDashboardDailyShiftId = getState('ui.shiftLifecycle.input.viewDashboard.dailyShiftId');
        this.viewDashboardDailyShiftId = savedViewDashboardDailyShiftId !== undefined ? savedViewDashboardDailyShiftId : '';
        const savedViewDashboardDate = getState('ui.shiftLifecycle.input.viewDashboard.date');
        this.viewDashboardDate = savedViewDashboardDate !== undefined ? savedViewDashboardDate : '';
        const savedViewDashboardStatus = getState('ui.shiftLifecycle.input.viewDashboard.status');
        this.viewDashboardStatus = savedViewDashboardStatus !== undefined ? savedViewDashboardStatus : '';
        const savedViewDashboardCreatedAt = getState('ui.shiftLifecycle.input.viewDashboard.createdAt');
        this.viewDashboardCreatedAt = savedViewDashboardCreatedAt !== undefined ? savedViewDashboardCreatedAt : '';
        const savedViewDashboardUpdatedAt = getState('ui.shiftLifecycle.input.viewDashboard.updatedAt');
        this.viewDashboardUpdatedAt = savedViewDashboardUpdatedAt !== undefined ? savedViewDashboardUpdatedAt : '';
        const savedViewDashboardData = getState('ui.shiftLifecycle.data.viewDashboard');
        this.viewDashboardData = savedViewDashboardData !== undefined ? savedViewDashboardData : [];
        const savedViewShiftReportState = getState('ui.shiftLifecycle.action.viewShiftReport.status');
        this.viewShiftReportState = savedViewShiftReportState !== undefined ? savedViewShiftReportState : 'idle';
        const savedViewShiftReportShiftCloseReportId = getState('ui.shiftLifecycle.input.viewShiftReport.shiftCloseReportId');
        this.viewShiftReportShiftCloseReportId = savedViewShiftReportShiftCloseReportId !== undefined ? savedViewShiftReportShiftCloseReportId : '';
        const savedViewShiftReportDailyShiftId = getState('ui.shiftLifecycle.input.viewShiftReport.dailyShiftId');
        this.viewShiftReportDailyShiftId = savedViewShiftReportDailyShiftId !== undefined ? savedViewShiftReportDailyShiftId : '';
        const savedViewShiftReportCreatedAt = getState('ui.shiftLifecycle.input.viewShiftReport.createdAt');
        this.viewShiftReportCreatedAt = savedViewShiftReportCreatedAt !== undefined ? savedViewShiftReportCreatedAt : '';
        const savedViewShiftReportUpdatedAt = getState('ui.shiftLifecycle.input.viewShiftReport.updatedAt');
        this.viewShiftReportUpdatedAt = savedViewShiftReportUpdatedAt !== undefined ? savedViewShiftReportUpdatedAt : '';
        const savedViewShiftReportData = getState('ui.shiftLifecycle.data.viewShiftReport');
        this.viewShiftReportData = savedViewShiftReportData !== undefined ? savedViewShiftReportData : [];
        // Subscribe to shared states
        const keysToSubscribe = [
            'ui.shiftLifecycle.status',
            'ui.shiftLifecycle.action.viewDashboard.status',
            'ui.shiftLifecycle.data.viewDashboard',
            'ui.shiftLifecycle.action.viewShiftReport.status',
            'ui.shiftLifecycle.data.viewShiftReport',
        ];
        subscribe(keysToSubscribe, this);
        this.subscribedKeys = keysToSubscribe;
        // Run initial loads
        void this.loadViewDashboard();
        void this.loadViewShiftReport();
    }
    disconnectedCallback() {
        if (this.subscribedKeys.length > 0) {
            unsubscribe(this.subscribedKeys, this);
            this.subscribedKeys = [];
        }
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], CafeFlowShiftLifecycleBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftLifecycleBase.prototype, "viewDashboardState", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftLifecycleBase.prototype, "viewDashboardDailyShiftId", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftLifecycleBase.prototype, "viewDashboardDate", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftLifecycleBase.prototype, "viewDashboardStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftLifecycleBase.prototype, "viewDashboardCreatedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftLifecycleBase.prototype, "viewDashboardUpdatedAt", void 0);
__decorate([
    property({ type: Array })
], CafeFlowShiftLifecycleBase.prototype, "viewDashboardData", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftLifecycleBase.prototype, "viewShiftReportState", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftLifecycleBase.prototype, "viewShiftReportShiftCloseReportId", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftLifecycleBase.prototype, "viewShiftReportDailyShiftId", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftLifecycleBase.prototype, "viewShiftReportCreatedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftLifecycleBase.prototype, "viewShiftReportUpdatedAt", void 0);
__decorate([
    property({ type: Array })
], CafeFlowShiftLifecycleBase.prototype, "viewShiftReportData", void 0);
