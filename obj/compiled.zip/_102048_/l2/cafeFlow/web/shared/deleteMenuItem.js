/// <mls fileReference="_102048_/l2/cafeFlow/web/shared/deleteMenuItem.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "deleteMenuItem.section.title": "Remover Item de Cardápio",
    "deleteMenuItem.organism.title": "Remover Item de Cardápio",
    "deleteMenuItem.intent.command.title": "Command Form",
    "deleteMenuItem.field.menuItemId": "Menu Item Id",
    "deleteMenuItem.field.name": "Name",
    "deleteMenuItem.field.category": "Category",
    "deleteMenuItem.field.price": "Price",
    "deleteMenuItem.field.stockItemId": "Stock Item Id",
    "deleteMenuItem.field.status": "Status",
    "deleteMenuItem.action.submit": "Delete Menu Item"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowDeleteMenuItemBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = "";
        this.deleteMenuItemState = "idle";
        this.deleteMenuItemMenuItemId = "";
        this.deleteMenuItemName = "";
        this.deleteMenuItemCategory = "";
        this.deleteMenuItemPrice = "";
        this.deleteMenuItemStockItemId = "";
        this.deleteMenuItemStatus = "";
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState("ui.deleteMenuItem.status") ?? "";
        this.deleteMenuItemState = getState("ui.deleteMenuItem.action.deleteMenuItem.status") ?? "idle";
        this.deleteMenuItemMenuItemId = getState("ui.deleteMenuItem.input.deleteMenuItem.menuItemId") ?? "";
        this.deleteMenuItemName = getState("ui.deleteMenuItem.input.deleteMenuItem.name") ?? "";
        this.deleteMenuItemCategory = getState("ui.deleteMenuItem.input.deleteMenuItem.category") ?? "";
        this.deleteMenuItemPrice = getState("ui.deleteMenuItem.input.deleteMenuItem.price") ?? "";
        this.deleteMenuItemStockItemId = getState("ui.deleteMenuItem.input.deleteMenuItem.stockItemId") ?? "";
        this.deleteMenuItemStatus = getState("ui.deleteMenuItem.input.deleteMenuItem.status") ?? "";
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    // --- StateSetter actions ---
    setDeleteMenuItemMenuItemId(value) {
        this.deleteMenuItemMenuItemId = value;
        setState("ui.deleteMenuItem.input.deleteMenuItem.menuItemId", value);
        this.requestUpdate();
    }
    handleDeleteMenuItemMenuItemIdChange(e) {
        const target = e.target;
        this.setDeleteMenuItemMenuItemId(target.value);
    }
    setDeleteMenuItemName(value) {
        this.deleteMenuItemName = value;
        setState("ui.deleteMenuItem.input.deleteMenuItem.name", value);
        this.requestUpdate();
    }
    handleDeleteMenuItemNameChange(e) {
        const target = e.target;
        this.setDeleteMenuItemName(target.value);
    }
    setDeleteMenuItemCategory(value) {
        this.deleteMenuItemCategory = value;
        setState("ui.deleteMenuItem.input.deleteMenuItem.category", value);
        this.requestUpdate();
    }
    handleDeleteMenuItemCategoryChange(e) {
        const target = e.target;
        this.setDeleteMenuItemCategory(target.value);
    }
    setDeleteMenuItemPrice(value) {
        this.deleteMenuItemPrice = value;
        setState("ui.deleteMenuItem.input.deleteMenuItem.price", value);
        this.requestUpdate();
    }
    handleDeleteMenuItemPriceChange(e) {
        const target = e.target;
        this.setDeleteMenuItemPrice(target.value);
    }
    setDeleteMenuItemStockItemId(value) {
        this.deleteMenuItemStockItemId = value;
        setState("ui.deleteMenuItem.input.deleteMenuItem.stockItemId", value);
        this.requestUpdate();
    }
    handleDeleteMenuItemStockItemIdChange(e) {
        const target = e.target;
        this.setDeleteMenuItemStockItemId(target.value);
    }
    setDeleteMenuItemStatus(value) {
        this.deleteMenuItemStatus = value;
        setState("ui.deleteMenuItem.input.deleteMenuItem.status", value);
        this.requestUpdate();
    }
    handleDeleteMenuItemStatusChange(e) {
        const target = e.target;
        this.setDeleteMenuItemStatus(target.value);
    }
    // --- Command action: deleteMenuItem ---
    async deleteMenuItem() {
        this.deleteMenuItemState = "loading";
        setState("ui.deleteMenuItem.action.deleteMenuItem.status", "loading");
        this.requestUpdate();
        const params = {
            menuItemId: this.deleteMenuItemMenuItemId || undefined,
            name: this.deleteMenuItemName,
            category: this.deleteMenuItemCategory,
            price: Number(this.deleteMenuItemPrice) || 0,
            stockItemId: this.deleteMenuItemStockItemId || undefined,
            status: this.deleteMenuItemStatus || "active",
        };
        const options = { mode: "blocking" };
        try {
            const response = await execBff("cafeFlow.deleteMenuItem.deleteMenuItem", params, options);
            if (response.ok) {
                this.deleteMenuItemState = "success";
                setState("ui.deleteMenuItem.action.deleteMenuItem.status", "success");
            }
            else {
                this.deleteMenuItemState = "error";
                setState("ui.deleteMenuItem.action.deleteMenuItem.status", "error");
            }
        }
        catch {
            this.deleteMenuItemState = "error";
            setState("ui.deleteMenuItem.action.deleteMenuItem.status", "error");
        }
        this.requestUpdate();
    }
    handleDeleteMenuItemClick(e) {
        e.preventDefault();
        runBlockingUiAction(async (_signal) => {
            await this.deleteMenuItem();
        }, { mode: "blocking" });
    }
}
__decorate([
    property({ type: String })
], CafeFlowDeleteMenuItemBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowDeleteMenuItemBase.prototype, "deleteMenuItemState", void 0);
__decorate([
    property({ type: String })
], CafeFlowDeleteMenuItemBase.prototype, "deleteMenuItemMenuItemId", void 0);
__decorate([
    property({ type: String })
], CafeFlowDeleteMenuItemBase.prototype, "deleteMenuItemName", void 0);
__decorate([
    property({ type: String })
], CafeFlowDeleteMenuItemBase.prototype, "deleteMenuItemCategory", void 0);
__decorate([
    property({ type: String })
], CafeFlowDeleteMenuItemBase.prototype, "deleteMenuItemPrice", void 0);
__decorate([
    property({ type: String })
], CafeFlowDeleteMenuItemBase.prototype, "deleteMenuItemStockItemId", void 0);
__decorate([
    property({ type: String })
], CafeFlowDeleteMenuItemBase.prototype, "deleteMenuItemStatus", void 0);
