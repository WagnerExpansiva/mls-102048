/// <mls fileReference="_102048_/l2/cafeFlow/web/shared/deleteStockItem.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "deleteStockItem.page.title": "Remover Item de Estoque",
    "deleteStockItem.section.main.title": "Remover Item de Estoque",
    "deleteStockItem.organism.delete.title": "Remover Item de Estoque",
    "deleteStockItem.intent.command.title": "Confirmar remoção do item",
    "deleteStockItem.field.stockItemId.label": "Identificador do item",
    "deleteStockItem.field.name.label": "Nome do item",
    "deleteStockItem.field.unitOfMeasure.label": "Unidade de medida",
    "deleteStockItem.field.minimumStockLevel.label": "Nível mínimo em estoque",
    "deleteStockItem.field.status.label": "Status",
    "deleteStockItem.action.delete.label": "Remover item"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowDeleteStockItemBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = "";
        this.deleteStockItemState = "idle";
        this.deleteStockItemStockItemId = "";
        this.deleteStockItemName = "";
        this.deleteStockItemUnitOfMeasure = "";
        this.deleteStockItemMinimumStockLevel = "";
        this.deleteStockItemStatus = "";
        this.handleDeleteStockItemClick = (event) => {
            event.preventDefault();
            runBlockingUiAction(async (_signal) => {
                await this.deleteStockItem();
            }, { mode: "blocking", busyLabel: this.msg["deleteStockItem.action.delete.label"] });
        };
        this.handleDeleteStockItemStockItemIdChange = (event) => {
            const target = event.target;
            this.setDeleteStockItemStockItemId(target.value);
        };
        this.handleDeleteStockItemNameChange = (event) => {
            const target = event.target;
            this.setDeleteStockItemName(target.value);
        };
        this.handleDeleteStockItemUnitOfMeasureChange = (event) => {
            const target = event.target;
            this.setDeleteStockItemUnitOfMeasure(target.value);
        };
        this.handleDeleteStockItemMinimumStockLevelChange = (event) => {
            const target = event.target;
            this.setDeleteStockItemMinimumStockLevel(target.value);
        };
        this.handleDeleteStockItemStatusChange = (event) => {
            const target = event.target;
            this.setDeleteStockItemStatus(target.value);
        };
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        const savedStatus = getState("ui.deleteStockItem.status");
        if (savedStatus !== undefined) {
            this.status = savedStatus;
        }
        const savedActionStatus = getState("ui.deleteStockItem.action.deleteStockItem.status");
        if (savedActionStatus !== undefined) {
            this.deleteStockItemState = savedActionStatus;
        }
        const savedStockItemId = getState("ui.deleteStockItem.input.deleteStockItem.stockItemId");
        if (savedStockItemId !== undefined) {
            this.deleteStockItemStockItemId = savedStockItemId;
        }
        const savedName = getState("ui.deleteStockItem.input.deleteStockItem.name");
        if (savedName !== undefined) {
            this.deleteStockItemName = savedName;
        }
        const savedUnitOfMeasure = getState("ui.deleteStockItem.input.deleteStockItem.unitOfMeasure");
        if (savedUnitOfMeasure !== undefined) {
            this.deleteStockItemUnitOfMeasure = savedUnitOfMeasure;
        }
        const savedMinimumStockLevel = getState("ui.deleteStockItem.input.deleteStockItem.minimumStockLevel");
        if (savedMinimumStockLevel !== undefined) {
            this.deleteStockItemMinimumStockLevel = savedMinimumStockLevel;
        }
        const savedItemStatus = getState("ui.deleteStockItem.input.deleteStockItem.status");
        if (savedItemStatus !== undefined) {
            this.deleteStockItemStatus = savedItemStatus;
        }
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    // --- Command: deleteStockItem ---
    async deleteStockItem() {
        this.deleteStockItemState = "loading";
        setState("ui.deleteStockItem.action.deleteStockItem.status", "loading");
        this.requestUpdate();
        const params = {
            stockItemId: this.deleteStockItemStockItemId || undefined,
            name: this.deleteStockItemName,
            unitOfMeasure: this.deleteStockItemUnitOfMeasure,
            minimumStockLevel: Number(this.deleteStockItemMinimumStockLevel),
            status: this.deleteStockItemStatus,
        };
        const options = { mode: "blocking" };
        try {
            const response = await execBff("cafeFlow.deleteStockItem.deleteStockItem", params, options);
            if (response.ok) {
                this.deleteStockItemState = "success";
                setState("ui.deleteStockItem.action.deleteStockItem.status", "success");
            }
            else {
                this.deleteStockItemState = "error";
                setState("ui.deleteStockItem.action.deleteStockItem.status", "error");
            }
        }
        catch {
            this.deleteStockItemState = "error";
            setState("ui.deleteStockItem.action.deleteStockItem.status", "error");
        }
        this.requestUpdate();
    }
    // --- StateSetter: setDeleteStockItemStockItemId ---
    setDeleteStockItemStockItemId(value) {
        this.deleteStockItemStockItemId = value;
        setState("ui.deleteStockItem.input.deleteStockItem.stockItemId", value);
        this.requestUpdate();
    }
    // --- StateSetter: setDeleteStockItemName ---
    setDeleteStockItemName(value) {
        this.deleteStockItemName = value;
        setState("ui.deleteStockItem.input.deleteStockItem.name", value);
        this.requestUpdate();
    }
    // --- StateSetter: setDeleteStockItemUnitOfMeasure ---
    setDeleteStockItemUnitOfMeasure(value) {
        this.deleteStockItemUnitOfMeasure = value;
        setState("ui.deleteStockItem.input.deleteStockItem.unitOfMeasure", value);
        this.requestUpdate();
    }
    // --- StateSetter: setDeleteStockItemMinimumStockLevel ---
    setDeleteStockItemMinimumStockLevel(value) {
        this.deleteStockItemMinimumStockLevel = value;
        setState("ui.deleteStockItem.input.deleteStockItem.minimumStockLevel", value);
        this.requestUpdate();
    }
    // --- StateSetter: setDeleteStockItemStatus ---
    setDeleteStockItemStatus(value) {
        this.deleteStockItemStatus = value;
        setState("ui.deleteStockItem.input.deleteStockItem.status", value);
        this.requestUpdate();
    }
}
__decorate([
    property({ type: String })
], CafeFlowDeleteStockItemBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowDeleteStockItemBase.prototype, "deleteStockItemState", void 0);
__decorate([
    property({ type: String })
], CafeFlowDeleteStockItemBase.prototype, "deleteStockItemStockItemId", void 0);
__decorate([
    property({ type: String })
], CafeFlowDeleteStockItemBase.prototype, "deleteStockItemName", void 0);
__decorate([
    property({ type: String })
], CafeFlowDeleteStockItemBase.prototype, "deleteStockItemUnitOfMeasure", void 0);
__decorate([
    property({ type: String })
], CafeFlowDeleteStockItemBase.prototype, "deleteStockItemMinimumStockLevel", void 0);
__decorate([
    property({ type: String })
], CafeFlowDeleteStockItemBase.prototype, "deleteStockItemStatus", void 0);
