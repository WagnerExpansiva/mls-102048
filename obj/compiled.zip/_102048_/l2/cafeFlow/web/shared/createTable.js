/// <mls fileReference="_102048_/l2/cafeFlow/web/shared/createTable.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
/// **collab_i18n_start**
const message_pt = {
    "createTable.section.title": "Cadastrar Mesa",
    "createTable.organism.title": "Cadastrar Mesa",
    "createTable.intention.form.title": "Dados da Mesa",
    "createTable.field.tableNumber": "Número/Código da Mesa",
    "createTable.field.capacity": "Capacidade",
    "createTable.field.status": "Situação",
    "createTable.field.status.active": "Ativa",
    "createTable.field.status.inactive": "Inativa",
    "createTable.action.submit": "Salvar Mesa"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowCreateTableBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.createTableState = 'idle';
        this.createTableTableNumber = '';
        this.createTableCapacity = '';
        this.createTableStatus = '';
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    /* ---- State setters ---- */
    setCreateTableTableNumber(value) {
        this.createTableTableNumber = value;
        setState('ui.createTable.input.createTable.tableNumber', value);
        this.requestUpdate();
    }
    handleCreateTableTableNumberChange(e) {
        const target = e.target;
        this.setCreateTableTableNumber(target.value);
    }
    setCreateTableCapacity(value) {
        this.createTableCapacity = value;
        setState('ui.createTable.input.createTable.capacity', value);
        this.requestUpdate();
    }
    handleCreateTableCapacityChange(e) {
        const target = e.target;
        this.setCreateTableCapacity(target.value);
    }
    setCreateTableStatus(value) {
        this.createTableStatus = value;
        setState('ui.createTable.input.createTable.status', value);
        this.requestUpdate();
    }
    handleCreateTableStatusChange(e) {
        const target = e.target;
        this.setCreateTableStatus(target.value);
    }
    /* ---- Command action ---- */
    async createTable() {
        this.createTableState = 'loading';
        setState('ui.createTable.action.createTable.status', 'loading');
        this.requestUpdate();
        const params = {
            tableNumber: this.createTableTableNumber,
            capacity: this.createTableCapacity ? Number(this.createTableCapacity) : undefined,
            status: this.createTableStatus,
        };
        const options = { mode: 'blocking' };
        const response = await execBff('cafeFlow.createTable.createTable', params, options);
        if (response.ok) {
            this.createTableState = 'success';
            setState('ui.createTable.action.createTable.status', 'success');
        }
        else {
            this.createTableState = 'error';
            setState('ui.createTable.action.createTable.status', 'error');
        }
        this.requestUpdate();
    }
    async handleCreateTableClick(_e) {
        await runBlockingUiAction(async (_signal) => {
            await this.createTable();
        }, { mode: 'blocking' });
    }
    /* ---- Lifecycle ---- */
    connectedCallback() {
        super.connectedCallback();
        const savedTableNumber = getState('ui.createTable.input.createTable.tableNumber');
        if (savedTableNumber !== undefined) {
            this.createTableTableNumber = savedTableNumber;
        }
        const savedCapacity = getState('ui.createTable.input.createTable.capacity');
        if (savedCapacity !== undefined) {
            this.createTableCapacity = savedCapacity;
        }
        const savedStatus = getState('ui.createTable.input.createTable.status');
        if (savedStatus !== undefined) {
            this.createTableStatus = savedStatus;
        }
        const savedActionStatus = getState('ui.createTable.action.createTable.status');
        if (savedActionStatus !== undefined) {
            this.createTableState = savedActionStatus;
        }
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], CafeFlowCreateTableBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowCreateTableBase.prototype, "createTableState", void 0);
__decorate([
    property({ type: String })
], CafeFlowCreateTableBase.prototype, "createTableTableNumber", void 0);
__decorate([
    property({ type: String })
], CafeFlowCreateTableBase.prototype, "createTableCapacity", void 0);
__decorate([
    property({ type: String })
], CafeFlowCreateTableBase.prototype, "createTableStatus", void 0);
