/// <mls fileReference="_102048_/l2/cafeFlow/web/shared/createMenuItem.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
/// **collab_i18n_start**
const message_pt = {
    "createMenuItem.section.title": "Cadastrar Item de Cardápio",
    "createMenuItem.organism.title": "Cadastrar Item de Cardápio",
    "createMenuItem.intent.commandForm.title": "Command Form",
    "menuItem.field.name": "Name",
    "menuItem.field.category": "Category",
    "menuItem.field.price": "Price",
    "menuItem.field.status": "Status",
    "createMenuItem.action.submit": "Create Menu Item"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowCreateMenuItemBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = "";
        this.createMenuItemState = "idle";
        this.createMenuItemName = "";
        this.createMenuItemCategory = "";
        this.createMenuItemPrice = "";
        this.createMenuItemStatus = "";
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState("ui.createMenuItem.status") ?? "";
        this.createMenuItemState = getState("ui.createMenuItem.action.createMenuItem.status") ?? "idle";
        this.createMenuItemName = getState("ui.createMenuItem.input.createMenuItem.name") ?? "";
        this.createMenuItemCategory = getState("ui.createMenuItem.input.createMenuItem.category") ?? "";
        this.createMenuItemPrice = getState("ui.createMenuItem.input.createMenuItem.price") ?? "";
        this.createMenuItemStatus = getState("ui.createMenuItem.input.createMenuItem.status") ?? "";
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    // --- StateSetter actions ---
    setCreateMenuItemName(value) {
        this.createMenuItemName = value;
        setState("ui.createMenuItem.input.createMenuItem.name", value);
        this.requestUpdate();
    }
    handleCreateMenuItemNameChange(e) {
        const target = e.target;
        this.setCreateMenuItemName(target.value);
    }
    setCreateMenuItemCategory(value) {
        this.createMenuItemCategory = value;
        setState("ui.createMenuItem.input.createMenuItem.category", value);
        this.requestUpdate();
    }
    handleCreateMenuItemCategoryChange(e) {
        const target = e.target;
        this.setCreateMenuItemCategory(target.value);
    }
    setCreateMenuItemPrice(value) {
        this.createMenuItemPrice = value;
        setState("ui.createMenuItem.input.createMenuItem.price", value);
        this.requestUpdate();
    }
    handleCreateMenuItemPriceChange(e) {
        const target = e.target;
        this.setCreateMenuItemPrice(target.value);
    }
    setCreateMenuItemStatus(value) {
        this.createMenuItemStatus = value;
        setState("ui.createMenuItem.input.createMenuItem.status", value);
        this.requestUpdate();
    }
    handleCreateMenuItemStatusChange(e) {
        const target = e.target;
        this.setCreateMenuItemStatus(target.value);
    }
    // --- Command actions ---
    async createMenuItem() {
        this.createMenuItemState = "loading";
        setState("ui.createMenuItem.action.createMenuItem.status", "loading");
        const params = {
            name: this.createMenuItemName,
            category: this.createMenuItemCategory,
            price: Number(this.createMenuItemPrice),
            status: this.createMenuItemStatus,
        };
        const options = { mode: "blocking" };
        const response = await execBff("cafeFlow.createMenuItem.createMenuItem", params, options);
        if (response.ok) {
            this.createMenuItemState = "success";
            setState("ui.createMenuItem.action.createMenuItem.status", "success");
        }
        else {
            this.createMenuItemState = "error";
            setState("ui.createMenuItem.action.createMenuItem.status", "error");
        }
    }
    handleCreateMenuItemClick(e) {
        e.preventDefault();
        runBlockingUiAction(async (_signal) => {
            await this.createMenuItem();
        }, { mode: "blocking" });
    }
}
__decorate([
    property({ type: String })
], CafeFlowCreateMenuItemBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowCreateMenuItemBase.prototype, "createMenuItemState", void 0);
__decorate([
    property({ type: String })
], CafeFlowCreateMenuItemBase.prototype, "createMenuItemName", void 0);
__decorate([
    property({ type: String })
], CafeFlowCreateMenuItemBase.prototype, "createMenuItemCategory", void 0);
__decorate([
    property({ type: String })
], CafeFlowCreateMenuItemBase.prototype, "createMenuItemPrice", void 0);
__decorate([
    property({ type: String })
], CafeFlowCreateMenuItemBase.prototype, "createMenuItemStatus", void 0);
