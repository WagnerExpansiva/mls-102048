/// <mls fileReference="_102048_/l2/cafeFlow/web/shared/updateMenuItem.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "updateMenuItem.section.title": "Editar Item de Cardápio",
    "updateMenuItem.organism.title": "Editar Item de Cardápio",
    "updateMenuItem.form.title": "Command Form",
    "updateMenuItem.field.name": "Name",
    "updateMenuItem.field.price": "Price",
    "updateMenuItem.field.stockItemId": "Stock Item Id",
    "updateMenuItem.field.status": "Status",
    "updateMenuItem.action.submit": "Update Menu Item"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowUpdateMenuItemBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = "";
        this.updateMenuItemState = "idle";
        this.updateMenuItemName = "";
        this.updateMenuItemPrice = "";
        this.updateMenuItemStockItemId = "";
        this.updateMenuItemStatus = "";
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    /* ---- State setters ---- */
    setUpdateMenuItemName(value) {
        this.updateMenuItemName = value;
        setState("ui.updateMenuItem.input.updateMenuItem.name", value);
        this.requestUpdate();
    }
    handleUpdateMenuItemNameChange(e) {
        const target = e.target;
        this.setUpdateMenuItemName(target.value);
    }
    setUpdateMenuItemPrice(value) {
        this.updateMenuItemPrice = value;
        setState("ui.updateMenuItem.input.updateMenuItem.price", value);
        this.requestUpdate();
    }
    handleUpdateMenuItemPriceChange(e) {
        const target = e.target;
        this.setUpdateMenuItemPrice(target.value);
    }
    setUpdateMenuItemStockItemId(value) {
        this.updateMenuItemStockItemId = value;
        setState("ui.updateMenuItem.input.updateMenuItem.stockItemId", value);
        this.requestUpdate();
    }
    handleUpdateMenuItemStockItemIdChange(e) {
        const target = e.target;
        this.setUpdateMenuItemStockItemId(target.value);
    }
    setUpdateMenuItemStatus(value) {
        this.updateMenuItemStatus = value;
        setState("ui.updateMenuItem.input.updateMenuItem.status", value);
        this.requestUpdate();
    }
    handleUpdateMenuItemStatusChange(e) {
        const target = e.target;
        this.setUpdateMenuItemStatus(target.value);
    }
    /* ---- Command action: updateMenuItem ---- */
    async updateMenuItem() {
        this.updateMenuItemState = "loading";
        setState("ui.updateMenuItem.action.updateMenuItem.status", "loading");
        this.requestUpdate();
        const params = {
            name: this.updateMenuItemName,
            price: Number(this.updateMenuItemPrice),
            stockItemId: this.updateMenuItemStockItemId || undefined,
            status: this.updateMenuItemStatus,
        };
        const options = { mode: "blocking" };
        const response = await execBff("cafeFlow.updateMenuItem.updateMenuItem", params, options);
        if (response.ok) {
            this.updateMenuItemState = "success";
            setState("ui.updateMenuItem.action.updateMenuItem.status", "success");
        }
        else {
            this.updateMenuItemState = "error";
            setState("ui.updateMenuItem.action.updateMenuItem.status", "error");
        }
        this.requestUpdate();
    }
    async handleUpdateMenuItemClick(e) {
        e.preventDefault();
        await runBlockingUiAction(async (signal) => {
            const options = { mode: "blocking", signal };
            this.updateMenuItemState = "loading";
            setState("ui.updateMenuItem.action.updateMenuItem.status", "loading");
            this.requestUpdate();
            const params = {
                name: this.updateMenuItemName,
                price: Number(this.updateMenuItemPrice),
                stockItemId: this.updateMenuItemStockItemId || undefined,
                status: this.updateMenuItemStatus,
            };
            const response = await execBff("cafeFlow.updateMenuItem.updateMenuItem", params, options);
            if (response.ok) {
                this.updateMenuItemState = "success";
                setState("ui.updateMenuItem.action.updateMenuItem.status", "success");
            }
            else {
                this.updateMenuItemState = "error";
                setState("ui.updateMenuItem.action.updateMenuItem.status", "error");
            }
            this.requestUpdate();
        });
    }
    /* ---- Lifecycle ---- */
    connectedCallback() {
        super.connectedCallback();
        this.status = getState("ui.updateMenuItem.status") ?? "";
        this.updateMenuItemState = getState("ui.updateMenuItem.action.updateMenuItem.status") ?? "idle";
        this.updateMenuItemName = getState("ui.updateMenuItem.input.updateMenuItem.name") ?? "";
        this.updateMenuItemPrice = getState("ui.updateMenuItem.input.updateMenuItem.price") ?? "";
        this.updateMenuItemStockItemId = getState("ui.updateMenuItem.input.updateMenuItem.stockItemId") ?? "";
        this.updateMenuItemStatus = getState("ui.updateMenuItem.input.updateMenuItem.status") ?? "";
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], CafeFlowUpdateMenuItemBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowUpdateMenuItemBase.prototype, "updateMenuItemState", void 0);
__decorate([
    property({ type: String })
], CafeFlowUpdateMenuItemBase.prototype, "updateMenuItemName", void 0);
__decorate([
    property({ type: String })
], CafeFlowUpdateMenuItemBase.prototype, "updateMenuItemPrice", void 0);
__decorate([
    property({ type: String })
], CafeFlowUpdateMenuItemBase.prototype, "updateMenuItemStockItemId", void 0);
__decorate([
    property({ type: String })
], CafeFlowUpdateMenuItemBase.prototype, "updateMenuItemStatus", void 0);
