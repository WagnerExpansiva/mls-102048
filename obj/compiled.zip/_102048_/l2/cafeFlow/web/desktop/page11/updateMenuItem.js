/// <mls fileReference="_102048_/l2/cafeFlow/web/desktop/page11/updateMenuItem.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { CafeFlowUpdateMenuItemBase } from '/_102048_/l2/cafeFlow/web/shared/updateMenuItem.js';
let CafeFlowDesktopPage11UpdateMenuItemPage = class CafeFlowDesktopPage11UpdateMenuItemPage extends CafeFlowUpdateMenuItemBase {
    render() {
        return html `
      <div class="min-h-full bg-slate-50 dark:bg-slate-950">
        <div class="max-w-6xl mx-auto px-4 py-6 space-y-6">
          <h1 class="text-2xl font-bold text-slate-900 dark:text-slate-100">
            ${this.msg['updateMenuItem.section.title']}
          </h1>

          <section class="bg-white dark:bg-slate-900 rounded-lg shadow-sm border border-slate-200 dark:border-slate-800 p-6">
            <h2 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-4">
              ${this.msg['updateMenuItem.organism.title']}
            </h2>

            <form
              @submit=${(e) => this.handleUpdateMenuItemClick(e)}
              class="space-y-4"
            >
              <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                  ${this.msg['updateMenuItem.field.name']}
                </label>
                <input
                  type="text"
                  .value=${this.updateMenuItemName}
                  @input=${(e) => this.handleUpdateMenuItemNameChange(e)}
                  class="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                  ${this.msg['updateMenuItem.field.price']}
                </label>
                <input
                  type="number"
                  step="0.01"
                  .value=${this.updateMenuItemPrice}
                  @input=${(e) => this.handleUpdateMenuItemPriceChange(e)}
                  class="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                  ${this.msg['updateMenuItem.field.stockItemId']}
                </label>
                <input
                  type="text"
                  .value=${this.updateMenuItemStockItemId}
                  @input=${(e) => this.handleUpdateMenuItemStockItemIdChange(e)}
                  class="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                  ${this.msg['updateMenuItem.field.status']}
                </label>
                <select
                  .value=${this.updateMenuItemStatus}
                  @change=${(e) => this.handleUpdateMenuItemStatusChange(e)}
                  class="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value=""></option>
                  <option value="active" ?selected=${this.updateMenuItemStatus === 'active'}>active</option>
                  <option value="inactive" ?selected=${this.updateMenuItemStatus === 'inactive'}>inactive</option>
                </select>
              </div>

              <div class="flex justify-end pt-2">
                <button
                  type="submit"
                  ?disabled=${this.updateMenuItemState === 'loading'}
                  class="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 text-white rounded-lg font-medium transition-colors"
                >
                  ${this.updateMenuItemState === 'loading' ? '...' : this.msg['updateMenuItem.action.submit']}
                </button>
              </div>
            </form>
          </section>
        </div>
      </div>
    `;
    }
};
CafeFlowDesktopPage11UpdateMenuItemPage = __decorate([
    customElement('cafe-flow--web--desktop--page11--update-menu-item-102048')
], CafeFlowDesktopPage11UpdateMenuItemPage);
export { CafeFlowDesktopPage11UpdateMenuItemPage };
