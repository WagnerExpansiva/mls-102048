/// <mls fileReference="_102048_/l2/cafeFlow/web/contracts/deleteMenuItem.test.ts" enhancement="_blank"/>
export {};
