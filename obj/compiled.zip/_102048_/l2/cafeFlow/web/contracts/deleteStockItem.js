/// <mls fileReference="_102048_/l2/cafeFlow/web/contracts/deleteStockItem.ts" enhancement="_blank"/>
export {};
