/// <mls fileReference="_102048_/l2/cafeFlow/web/contracts/queryStockItem.ts" enhancement="_blank"/>
export {};
