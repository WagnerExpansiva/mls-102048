/// <mls fileReference="_102048_/l2/cafeFlow/web/contracts/queryTable.ts" enhancement="_blank"/>
export {};
