/// <mls fileReference="_102048_/l2/cafeFlow/web/contracts/createStockItem.ts" enhancement="_blank"/>
export {};
