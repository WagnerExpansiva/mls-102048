/// <mls fileReference="_102048_/l2/cafeFlow/web/contracts/deleteMenuItem.ts" enhancement="_blank"/>
export {};
