/// <mls fileReference="_102048_/l2/cafeFlow/web/contracts/createMenuItem.ts" enhancement="_blank"/>
export {};
