/// <mls fileReference="_102048_/l2/cafeFlow/web/contracts/updateTable.test.ts" enhancement="_blank"/>
export {};
