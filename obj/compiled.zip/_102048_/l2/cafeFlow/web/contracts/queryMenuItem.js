/// <mls fileReference="_102048_/l2/cafeFlow/web/contracts/queryMenuItem.ts" enhancement="_blank"/>
export {};
