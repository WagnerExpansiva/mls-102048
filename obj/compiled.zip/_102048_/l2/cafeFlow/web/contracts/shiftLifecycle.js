/// <mls fileReference="_102048_/l2/cafeFlow/web/contracts/shiftLifecycle.ts" enhancement="_blank"/>
export {};
