/// <mls fileReference="_102048_/l2/cafeFlow/web/contracts/createStockItem.test.ts" enhancement="_blank"/>
export {};
