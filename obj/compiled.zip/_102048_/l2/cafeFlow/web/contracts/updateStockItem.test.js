/// <mls fileReference="_102048_/l2/cafeFlow/web/contracts/updateStockItem.test.ts" enhancement="_blank"/>
export {};
