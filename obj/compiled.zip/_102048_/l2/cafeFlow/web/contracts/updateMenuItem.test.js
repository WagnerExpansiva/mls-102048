/// <mls fileReference="_102048_/l2/cafeFlow/web/contracts/updateMenuItem.test.ts" enhancement="_blank"/>
export {};
