/// <mls fileReference="_102048_/l2/cafeFlow/web/contracts/queryTable.test.ts" enhancement="_blank"/>
export {};
