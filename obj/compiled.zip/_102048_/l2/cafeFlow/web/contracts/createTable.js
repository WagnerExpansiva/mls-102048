/// <mls fileReference="_102048_/l2/cafeFlow/web/contracts/createTable.ts" enhancement="_blank"/>
export {};
