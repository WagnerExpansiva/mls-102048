/// <mls fileReference="_102048_/l2/cafeFlow/web/contracts/deleteTable.test.ts" enhancement="_blank"/>
export {};
