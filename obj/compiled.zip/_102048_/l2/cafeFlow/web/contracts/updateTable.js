/// <mls fileReference="_102048_/l2/cafeFlow/web/contracts/updateTable.ts" enhancement="_blank"/>
export {};
