/// <mls fileReference="_102048_/l2/cafeFlow/web/contracts/updateMenuItem.ts" enhancement="_blank"/>
export {};
