declare module "_102048_/l1/cafeFlow/layer_1_external/aiInsightRun.defs" {
    export const aiInsightRunTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "aiInsightRun";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 54;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "aiInsightRun";
                readonly tableName: "ai_insight_run";
                readonly moduleId: "cafeFlow";
                readonly title: "Execução de Insight IA";
                readonly purpose: "Registrar execuções do assistente IA (resumo de vendas, sugestões de promoções), incluindo parâmetros, resultado, modelo e timestamps para histórico, auditoria e suporte a páginas de IA.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "AiInsightRun";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "ai_insight_run_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da execução de insight de IA";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Referência ao turno diário quando o insight está relacionado a um turno específico";
                }, {
                    readonly name: "insight_type";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Categoria do insight solicitado";
                }, {
                    readonly name: "parameters";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Parâmetros adicionais da solicitação em formato JSON ou texto livre";
                }, {
                    readonly name: "time_window_start";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Início da janela temporal dos dados analisados";
                }, {
                    readonly name: "time_window_end";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Fim da janela temporal dos dados analisados";
                }, {
                    readonly name: "language";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Idioma solicitado para o insight e do resultado gerado";
                }, {
                    readonly name: "prompt_version";
                    readonly type: "string";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Versão do prompt ou do modelo utilizado";
                }, {
                    readonly name: "prompt_text";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Texto completo do prompt enviado ao serviço de IA";
                }, {
                    readonly name: "result_text";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Resposta/resultado gerado pelo modelo de IA";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Status atual da execução do insight";
                }, {
                    readonly name: "error_message";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Detalhes do erro quando a execução falha";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly primaryKey: readonly ["ai_insight_run_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "daily_shift_id";
                    readonly targetEntity: "DailyShift";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Referência opcional a turno para insights relacionados a fechamento de turno";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_ai_insight_run_status_created";
                    readonly columns: readonly ["status", "created_at"];
                    readonly unique: false;
                    readonly reason: "Busca comum por status e data para histórico e auditoria";
                }, {
                    readonly indexName: "idx_ai_insight_run_type_window";
                    readonly columns: readonly ["insight_type", "time_window_start", "time_window_end"];
                    readonly unique: false;
                    readonly reason: "Suporte a consultas por tipo de insight e janela temporal";
                }, {
                    readonly indexName: "idx_ai_insight_run_shift";
                    readonly columns: readonly ["daily_shift_id"];
                    readonly unique: false;
                    readonly reason: "Lookup por turno diário";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                    readonly reason: "Não recomendado para esta tabela de log de eventos; campos estruturados já estão em colunas físicas";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly metricRefs: readonly [];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy", "bilingualUiViaPlatformI18n"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/aiInsightRun.defs.ts";
                readonly exportName: "aiInsightRunTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default aiInsightRunTableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/dailyShift.defs" {
    export const dailyShiftTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "dailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 52;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "dailyShift";
                readonly tableName: "daily_shift";
                readonly moduleId: "cafeFlow";
                readonly title: "Turno Diário";
                readonly purpose: "Persistir abertura/fechamento de turno, valores de caixa declarados, usuário responsável e status, servindo de âncora para pedidos e relatórios do dia/turno.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "DailyShift";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do turno diário";
                }, {
                    readonly name: "shift_date";
                    readonly type: "date";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data de referência do turno operacional";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Situação atual do turno (aberto ou fechado)";
                }, {
                    readonly name: "opened_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora da abertura do turno";
                }, {
                    readonly name: "closed_at";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Data e hora do fechamento do turno";
                }, {
                    readonly name: "opened_by";
                    readonly type: "string";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Nome do operador que abriu o turno";
                }, {
                    readonly name: "closed_by";
                    readonly type: "string";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Nome do operador que fechou o turno";
                }, {
                    readonly name: "closing_notes";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Observações gerais registradas no fechamento do turno";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly primaryKey: readonly ["daily_shift_id"];
                readonly foreignRefs: readonly [];
                readonly indexes: readonly [{
                    readonly indexName: "idx_daily_shift_date";
                    readonly columns: readonly ["shift_date"];
                    readonly unique: false;
                    readonly reason: "Busca rápida por data para dashboard e relatórios";
                }, {
                    readonly indexName: "idx_daily_shift_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Filtro por status aberto/fechado em workflows";
                }, {
                    readonly indexName: "idx_daily_shift_date_status";
                    readonly columns: readonly ["shift_date", "status"];
                    readonly unique: false;
                    readonly reason: "Consultas combinadas para métricas e POS";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "DailyShiftDetails";
                    readonly reason: "Armazenar dados internos adicionais ou snapshots como JSONB";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["shiftSummaryMetricTable"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["shiftMustBeOpenToCreateOrders", "metricsDerivedFromClosedOrders"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/dailyShift.defs.ts";
                readonly exportName: "dailyShiftTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default dailyShiftTableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/diningTable.defs" {
    export const diningTableTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "diningTable";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 51;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "diningTable";
                readonly tableName: "dining_table";
                readonly moduleId: "cafeFlow";
                readonly title: "Mesa";
                readonly purpose: "Manter cadastro operacional de mesas (ativas/inativas) para pedidos do tipo mesa e para UX do POS/KDS.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "DiningTable";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "diningTableId";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da mesa";
                }, {
                    readonly name: "tableNumber";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Número ou identificador operacional da mesa (ex: 1, A1, 10)";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Estado operacional da mesa";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly primaryKey: readonly ["diningTableId"];
                readonly foreignRefs: readonly [];
                readonly indexes: readonly [{
                    readonly indexName: "idx_dining_table_number";
                    readonly columns: readonly ["tableNumber"];
                    readonly unique: true;
                    readonly reason: "Garantir unicidade do número da mesa para operação local";
                }, {
                    readonly indexName: "idx_dining_table_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Busca rápida de mesas ativas para POS e KDS";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                    readonly reason: "Sem dados filhos ou internos para armazenar como JSON";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly metricRefs: readonly [];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["orderTypeMustBeTableOrTakeout"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/diningTable.defs.ts";
                readonly exportName: "diningTableTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default diningTableTableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/inventoryBalanceSnapshot.defs" {
    export const inventoryBalanceSnapshotTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "inventoryBalanceSnapshot";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 54;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "inventoryBalanceSnapshot";
                readonly tableName: "inventory_balance_snapshot";
                readonly moduleId: "cafeFlow";
                readonly title: "Snapshot de Saldo de Estoque";
                readonly purpose: "Persistir snapshots periódicos/por evento do saldo calculado por ingrediente para leituras rápidas (ex.: estoque baixo) e suporte a relatórios sem recalcular todo o histórico a cada consulta.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "InventoryBalanceSnapshot";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do snapshot de saldo.";
                }, {
                    readonly name: "inventory_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Referência ao item de estoque cujo saldo foi registrado.";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Referência opcional ao turno em que o snapshot foi capturado (ex.: fechamento de turno).";
                }, {
                    readonly name: "quantity_on_hand";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Quantidade em estoque no momento do snapshot.";
                }, {
                    readonly name: "unit_cost";
                    readonly type: "numeric";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Custo unitário opcional no momento do snapshot para valorização.";
                }, {
                    readonly name: "recorded_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora em que o snapshot foi registrado.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly default: "now()";
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly default: "now()";
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "inventory_item_id";
                    readonly targetEntity: "InventoryItem";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Referência a item de estoque gerenciado em MDM para snapshots de saldo.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_inventory_balance_snapshot_item_recorded";
                    readonly columns: readonly ["inventory_item_id", "recorded_at"];
                    readonly unique: false;
                    readonly reason: "Suporte a consultas rápidas por item e período para relatórios e alertas de estoque.";
                }, {
                    readonly indexName: "idx_inventory_balance_snapshot_shift";
                    readonly columns: readonly ["daily_shift_id"];
                    readonly unique: false;
                    readonly reason: "Busca rápida de snapshots por turno para fechamento e auditoria.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "InventoryBalanceSnapshotDetails";
                    readonly reason: "Armazenar dados adicionais internos ou metadados do snapshot como JSON para flexibilidade sem alterar schema.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly metricRefs: readonly [];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["inventoryDeductionHappensOnSaleEvent", "inventoryCannotGoNegativeByDefault"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/inventoryBalanceSnapshot.defs.ts";
                readonly exportName: "inventoryBalanceSnapshotTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default inventoryBalanceSnapshotTableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/inventoryTransaction.defs" {
    export const inventoryTransactionTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "inventoryTransaction";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 53;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "inventoryTransaction";
                readonly tableName: "inventory_transaction";
                readonly moduleId: "cafeFlow";
                readonly title: "Movimentação de Estoque";
                readonly purpose: "Registrar eventos de movimentação de estoque (ajuste manual e baixa automática por venda), com rastreabilidade e possibilidade de reversão.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "InventoryTransaction";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "inventoryTransactionId";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da movimentação de estoque.";
                }, {
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Referência ao ingrediente/insumo movimentado.";
                }, {
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Referência ao pedido origem em caso de baixa automática por venda.";
                }, {
                    readonly name: "transactionType";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Tipo da movimentação: entrada de estoque, baixa por venda ou ajuste manual.";
                }, {
                    readonly name: "quantityChange";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Quantidade alterada no estoque. Positivo para entrada, negativo para baixa ou ajuste de redução.";
                }, {
                    readonly name: "reason";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Motivo do ajuste manual ou observação sobre a movimentação.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Status do registro: lançado ou estornado.";
                }, {
                    readonly name: "recordedAt";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora em que a movimentação ocorreu efetivamente.";
                }, {
                    readonly name: "createdBy";
                    readonly type: "string";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Identificador do usuário responsável pelo registro.";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["inventoryTransactionId"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "inventoryItemId";
                    readonly targetEntity: "InventoryItem";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Referência ao item de inventário gerenciado em MDM para rastreabilidade de estoque.";
                }, {
                    readonly fieldName: "orderId";
                    readonly targetEntity: "Order";
                    readonly targetOwnership: "existingModuleOwned";
                    readonly reason: "Referência opcional ao pedido para baixa automática por venda.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_inventory_transaction_item_recorded";
                    readonly columns: readonly ["inventoryItemId", "recordedAt"];
                    readonly unique: false;
                    readonly reason: "Consulta frequente de histórico por ingrediente e período para relatórios e dashboards.";
                }, {
                    readonly indexName: "idx_inventory_transaction_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Filtragem por status (posted/reversed) em workflows de estorno e auditoria.";
                }, {
                    readonly indexName: "idx_inventory_transaction_order";
                    readonly columns: readonly ["orderId"];
                    readonly unique: false;
                    readonly reason: "Lookup de transações por pedido para idempotência e reversão.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "InventoryTransactionDetails";
                    readonly reason: "Armazenamento de metadados adicionais da transação (ex: snapshot de receita) como JSON para flexibilidade sem colunas extras.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["lowStockMetricTable", "shiftSummaryMetricTable"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["inventoryDeductionHappensOnSaleEvent", "inventoryCannotGoNegativeByDefault"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/inventoryTransaction.defs.ts";
                readonly exportName: "inventoryTransactionTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default inventoryTransactionTableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/lowStockMetrics.defs" {
    export const lowStockMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "lowStockMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 64;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "lowStockMetrics";
                readonly tableName: "low_stock_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Estoque Baixo";
                readonly purpose: "Monitorar saldos de ingredientes e alertar sobre itens abaixo do nível crítico";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_timestamp";
                readonly columns: readonly [{
                    readonly name: "event_timestamp";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do evento que atualiza a métrica";
                }, {
                    readonly name: "inventory_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Item de estoque (ingrediente)";
                }, {
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship inventoryTxOptionallyReferencesOrder (InventoryTransaction -> Order)";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship snapshotByShift (InventoryBalanceSnapshot -> DailyShift)";
                }, {
                    readonly name: "balance_quantity";
                    readonly type: "numeric";
                    readonly nullable: true;
                    readonly description: "Saldo atual em estoque";
                }, {
                    readonly name: "min_threshold";
                    readonly type: "numeric";
                    readonly nullable: true;
                    readonly description: "Estoque mínimo configurado";
                }, {
                    readonly name: "is_below_threshold";
                    readonly type: "integer";
                    readonly nullable: true;
                    readonly description: "Indicador de estoque abaixo do mínimo (1=sim, 0=não)";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "inventoryItemId";
                    readonly column: "inventory_item_id";
                    readonly type: "uuid";
                    readonly description: "Item de estoque (ingrediente)";
                }, {
                    readonly dimensionId: "orderId";
                    readonly column: "order_id";
                    readonly type: "uuid";
                    readonly description: "FK dimension derived from ontology relationship inventoryTxOptionallyReferencesOrder (InventoryTransaction -> Order)";
                }, {
                    readonly dimensionId: "dailyShiftId";
                    readonly column: "daily_shift_id";
                    readonly type: "uuid";
                    readonly description: "FK dimension derived from ontology relationship snapshotByShift (InventoryBalanceSnapshot -> DailyShift)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "currentBalance";
                    readonly column: "balance_quantity";
                    readonly aggregation: "last";
                    readonly unit: "unidade";
                    readonly description: "Saldo atual em estoque";
                }, {
                    readonly measureId: "minThreshold";
                    readonly column: "min_threshold";
                    readonly aggregation: "last";
                    readonly unit: "unidade";
                    readonly description: "Estoque mínimo configurado";
                }, {
                    readonly measureId: "belowThresholdFlag";
                    readonly column: "is_below_threshold";
                    readonly aggregation: "max";
                    readonly description: "Indicador de estoque abaixo do mínimo (1=sim, 0=não)";
                }];
                readonly sourceWriteEvents: readonly ["inventoryTransactionPosted", "inventoryAdjustmentPosted", "orderClosed"];
                readonly hypertable: {
                    readonly timeColumn: "event_timestamp";
                    readonly chunkTimeInterval: "1 day";
                    readonly retentionPolicy: "90 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_low_stock_metrics_time";
                        readonly columns: readonly ["event_timestamp"];
                        readonly purpose: "Hypertable time-based chunking and queries";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_low_stock_metrics_item_time";
                        readonly columns: readonly ["inventory_item_id", "event_timestamp"];
                        readonly purpose: "Query by inventory item over time";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_low_stock_metrics_shift";
                        readonly columns: readonly ["daily_shift_id"];
                        readonly purpose: "Filter by shift for daily views";
                        readonly unique: false;
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["closeOrderAndDeductInventoryCommand", "postInventoryAdjustmentCommand"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["inventoryDeductionHappensOnSaleEvent", "inventoryCannotGoNegativeByDefault", "updatedOnlyByLayer3Usecases"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/lowStockMetrics.defs.ts";
                readonly exportName: "lowStockMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default lowStockMetricsTableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 50;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "order";
                readonly tableName: "order";
                readonly moduleId: "cafeFlow";
                readonly title: "Pedido";
                readonly purpose: "Persistir o ciclo de vida do pedido (mesa/takeout), vínculo com turno e timestamps operacionais, mantendo itens e snapshots necessários para cobrança/preparo sem depender de MDM em tempo real.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "Order";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do pedido";
                }, {
                    readonly name: "order_number";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Número sequencial ou código de exibição do pedido";
                }, {
                    readonly name: "type";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Tipo do pedido: mesa ou takeout";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Status atual do pedido no fluxo de preparo e atendimento";
                }, {
                    readonly name: "dining_table_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Referência à mesa (obrigatório apenas quando tipo for 'mesa')";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Referência ao turno diário em que o pedido foi criado";
                }, {
                    readonly name: "customer_name";
                    readonly type: "string";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Nome do cliente (útil para takeout)";
                }, {
                    readonly name: "notes";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Observações gerais do pedido";
                }, {
                    readonly name: "total_amount";
                    readonly type: "money";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Valor total do pedido calculado a partir dos itens";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data/hora de criação do pedido";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data/hora da última atualização do pedido";
                }, {
                    readonly name: "sent_to_kitchen_at";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Data/hora em que o pedido foi enviado para a cozinha";
                }, {
                    readonly name: "ready_at";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Data/hora em que o pedido ficou pronto para entrega";
                }, {
                    readonly name: "delivered_at";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Data/hora da entrega do pedido ao cliente";
                }, {
                    readonly name: "closed_at";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Data/hora do fechamento/pagamento do pedido";
                }, {
                    readonly name: "cancelled_at";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Data/hora do cancelamento do pedido";
                }, {
                    readonly name: "cancellation_reason";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Motivo do cancelamento, quando aplicável";
                }];
                readonly primaryKey: readonly ["id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "daily_shift_id";
                    readonly targetEntity: "DailyShift";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Liga pedido ao turno diário aberto";
                }, {
                    readonly fieldName: "dining_table_id";
                    readonly targetEntity: "DiningTable";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Referência à mesa física para pedidos do tipo mesa";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_order_daily_shift_status";
                    readonly columns: readonly ["daily_shift_id", "status"];
                    readonly unique: false;
                    readonly reason: "Busca rápida de pedidos por turno e status para KDS e dashboard";
                }, {
                    readonly indexName: "idx_order_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly unique: false;
                    readonly reason: "Filtros por data em relatórios e métricas";
                }, {
                    readonly indexName: "idx_order_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Filtragem por status em workflows de cozinha e POS";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "OrderDetails";
                    readonly reason: "Armazena OrderItem[] e snapshots como JSONB para aggregate pattern";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["salesTodayMetricTable", "topSellingItemsMetricTable", "shiftSummaryMetricTable"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["orderTypeMustBeTableOrTakeout", "orderStatusTransitionsControlled", "shiftMustBeOpenToCreateOrders", "menuPriceIsSnapshottedOnOrderItem", "metricsDerivedFromClosedOrders"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/order.defs.ts";
                readonly exportName: "orderTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default orderTableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/shiftSummaryMetrics.defs" {
    export const shiftSummaryMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "shiftSummaryMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 65;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "shiftSummaryMetrics";
                readonly tableName: "shift_summary_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Resumo do Turno";
                readonly purpose: "Consolidar indicadores financeiros e operacionais ao final de cada turno diário";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_timestamp";
                readonly columns: readonly [{
                    readonly name: "event_timestamp";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do evento de fechamento do pedido ou turno";
                }, {
                    readonly name: "menu_item_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship orderItemReferencesMenuItem (OrderItem -> MenuItem)";
                }, {
                    readonly name: "dining_table_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship orderOptionallyReferencesDiningTable (Order -> DiningTable)";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "FK dimension derived from ontology relationship orderBelongsToShift (Order -> DailyShift)";
                }, {
                    readonly name: "order_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship orderHasItems (OrderItem -> Order)";
                }, {
                    readonly name: "revenue";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: "0";
                    readonly description: "Receita total do turno";
                }, {
                    readonly name: "order_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: "0";
                    readonly description: "Total de pedidos no turno";
                }, {
                    readonly name: "items_sold";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: "0";
                    readonly description: "Total de itens vendidos no turno";
                }, {
                    readonly name: "ticket_value";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: "0";
                    readonly description: "Ticket médio do turno";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "menuItemId";
                    readonly column: "menu_item_id";
                    readonly type: "uuid";
                    readonly description: "FK dimension derived from ontology relationship orderItemReferencesMenuItem (OrderItem -> MenuItem)";
                }, {
                    readonly dimensionId: "diningTableId";
                    readonly column: "dining_table_id";
                    readonly type: "uuid";
                    readonly description: "FK dimension derived from ontology relationship orderOptionallyReferencesDiningTable (Order -> DiningTable)";
                }, {
                    readonly dimensionId: "dailyShiftId";
                    readonly column: "daily_shift_id";
                    readonly type: "uuid";
                    readonly description: "FK dimension derived from ontology relationship orderBelongsToShift (Order -> DailyShift)";
                }, {
                    readonly dimensionId: "orderId";
                    readonly column: "order_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship orderHasItems (OrderItem -> Order)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "shiftRevenue";
                    readonly column: "revenue";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Receita total do turno";
                }, {
                    readonly measureId: "shiftOrders";
                    readonly column: "order_count";
                    readonly aggregation: "sum";
                    readonly description: "Total de pedidos no turno";
                }, {
                    readonly measureId: "shiftItemsSold";
                    readonly column: "items_sold";
                    readonly aggregation: "sum";
                    readonly description: "Total de itens vendidos no turno";
                }, {
                    readonly measureId: "shiftAverageTicket";
                    readonly column: "ticket_value";
                    readonly aggregation: "avg";
                    readonly unit: "BRL";
                    readonly description: "Ticket médio do turno";
                }];
                readonly sourceWriteEvents: readonly ["dailyShiftClosed", "orderClosed"];
                readonly hypertable: {
                    readonly timeColumn: "event_timestamp";
                    readonly chunkTimeInterval: "1 day";
                    readonly retentionPolicy: "5 years";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_shift_summary_metrics_time";
                        readonly columns: readonly ["event_timestamp"];
                        readonly purpose: "Hypertable time-based partitioning and queries";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_shift_summary_metrics_shift_item";
                        readonly columns: readonly ["daily_shift_id", "menu_item_id"];
                        readonly purpose: "Dimension index for shift and menu item breakdowns";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_shift_summary_metrics_dining_table";
                        readonly columns: readonly ["dining_table_id"];
                        readonly purpose: "Dimension index for dining table";
                        readonly unique: false;
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["closeShiftCommand", "closeOrderAndDeductInventoryCommand"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["metricsDerivedFromClosedOrders", "shiftMustBeOpenToCreateOrders", "updatedOnlyByLayer3Usecases"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/shiftSummaryMetrics.defs.ts";
                readonly exportName: "shiftSummaryMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default shiftSummaryMetricsTableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/todaySalesMetrics.defs" {
    export const todaySalesMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "todaySalesMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 62;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "todaySalesMetrics";
                readonly tableName: "today_sales_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Vendas de Hoje";
                readonly purpose: "Acompanhar receita, quantidade de pedidos e ticket médio em tempo real durante o turno";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_timestamp";
                readonly columns: readonly [{
                    readonly name: "event_timestamp";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do evento de fechamento do pedido";
                }, {
                    readonly name: "order_type";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Tipo do pedido: mesa ou takeout";
                }, {
                    readonly name: "menu_item_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Item do cardápio";
                }, {
                    readonly name: "menu_category_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Categoria do cardápio";
                }, {
                    readonly name: "dining_table_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Mesa";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "FK dimension derived from ontology relationship orderBelongsToShift (Order -> DailyShift)";
                }, {
                    readonly name: "total_revenue";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: "0";
                    readonly description: "Receita total";
                }, {
                    readonly name: "order_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: "0";
                    readonly description: "Quantidade de pedidos";
                }, {
                    readonly name: "item_quantity";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: "0";
                    readonly description: "Quantidade total de itens vendidos";
                }, {
                    readonly name: "ticket_value";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: "0";
                    readonly description: "Ticket médio";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "orderType";
                    readonly column: "order_type";
                    readonly type: "string";
                    readonly description: "Tipo do pedido: mesa ou takeout";
                }, {
                    readonly dimensionId: "menuItemId";
                    readonly column: "menu_item_id";
                    readonly type: "uuid";
                    readonly description: "Item do cardápio";
                }, {
                    readonly dimensionId: "menuCategoryId";
                    readonly column: "menu_category_id";
                    readonly type: "uuid";
                    readonly description: "Categoria do cardápio";
                }, {
                    readonly dimensionId: "diningTableId";
                    readonly column: "dining_table_id";
                    readonly type: "uuid";
                    readonly description: "Mesa";
                }, {
                    readonly dimensionId: "dailyShiftId";
                    readonly column: "daily_shift_id";
                    readonly type: "uuid";
                    readonly description: "FK dimension derived from ontology relationship orderBelongsToShift (Order -> DailyShift)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "totalRevenue";
                    readonly column: "total_revenue";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Receita total";
                }, {
                    readonly measureId: "totalOrders";
                    readonly column: "order_count";
                    readonly aggregation: "sum";
                    readonly description: "Quantidade de pedidos";
                }, {
                    readonly measureId: "totalItemsSold";
                    readonly column: "item_quantity";
                    readonly aggregation: "sum";
                    readonly description: "Quantidade total de itens vendidos";
                }, {
                    readonly measureId: "averageTicket";
                    readonly column: "ticket_value";
                    readonly aggregation: "avg";
                    readonly unit: "BRL";
                    readonly description: "Ticket médio";
                }];
                readonly sourceWriteEvents: readonly ["orderClosed"];
                readonly hypertable: {
                    readonly timeColumn: "event_timestamp";
                    readonly chunkTimeInterval: "1 day";
                    readonly retentionPolicy: "90 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_today_sales_metrics_time";
                        readonly columns: readonly ["event_timestamp"];
                        readonly purpose: "Hypertable time-based partitioning and queries";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_today_sales_metrics_shift_type";
                        readonly columns: readonly ["daily_shift_id", "order_type"];
                        readonly purpose: "Dimension index for shift and order type filtering";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_today_sales_metrics_menu_item";
                        readonly columns: readonly ["menu_item_id"];
                        readonly purpose: "Dimension index for menu item aggregation";
                        readonly unique: false;
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["closeOrderL3Handler"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["metricsDerivedFromClosedOrders", "menuPriceIsSnapshottedOnOrderItem", "shiftMustBeOpenToCreateOrders", "updatedOnlyByLayer3Usecases"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/todaySalesMetrics.defs.ts";
                readonly exportName: "todaySalesMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default todaySalesMetricsTableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.defs" {
    export const topSellingItemsMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "topSellingItemsMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 63;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "topSellingItemsMetrics";
                readonly tableName: "top_selling_items_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Itens Mais Vendidos";
                readonly purpose: "Identificar quais itens do cardápio geram mais volume e receita";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_timestamp";
                readonly columns: readonly [{
                    readonly name: "event_timestamp";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do evento de fechamento do pedido";
                }, {
                    readonly name: "menu_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Item do cardápio";
                }, {
                    readonly name: "menu_category_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Categoria do cardápio";
                }, {
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship orderItemReferencesOrder (OrderItem -> Order)";
                }, {
                    readonly name: "dining_table_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship orderOptionallyReferencesDiningTable (Order -> DiningTable)";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship orderBelongsToShift (Order -> DailyShift)";
                }, {
                    readonly name: "quantity_sold";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: "0";
                    readonly description: "Quantidade vendida do item";
                }, {
                    readonly name: "item_revenue";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: "0";
                    readonly description: "Receita gerada pelo item";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "menuItemId";
                    readonly column: "menu_item_id";
                    readonly type: "uuid";
                    readonly description: "Item do cardápio";
                }, {
                    readonly dimensionId: "menuCategoryId";
                    readonly column: "menu_category_id";
                    readonly type: "uuid";
                    readonly description: "Categoria do cardápio";
                }, {
                    readonly dimensionId: "orderId";
                    readonly column: "order_id";
                    readonly type: "uuid";
                    readonly description: "FK dimension derived from ontology relationship orderItemReferencesOrder (OrderItem -> Order)";
                }, {
                    readonly dimensionId: "diningTableId";
                    readonly column: "dining_table_id";
                    readonly type: "uuid";
                    readonly description: "FK dimension derived from ontology relationship orderOptionallyReferencesDiningTable (Order -> DiningTable)";
                }, {
                    readonly dimensionId: "dailyShiftId";
                    readonly column: "daily_shift_id";
                    readonly type: "uuid";
                    readonly description: "FK dimension derived from ontology relationship orderBelongsToShift (Order -> DailyShift)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "quantitySold";
                    readonly column: "quantity_sold";
                    readonly aggregation: "sum";
                    readonly description: "Quantidade vendida do item";
                }, {
                    readonly measureId: "itemRevenue";
                    readonly column: "item_revenue";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Receita gerada pelo item";
                }];
                readonly sourceWriteEvents: readonly ["orderClosed"];
                readonly hypertable: {
                    readonly timeColumn: "event_timestamp";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_top_selling_items_metrics_time";
                        readonly columns: readonly ["event_timestamp"];
                        readonly purpose: "Hypertable time index";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_menu_item";
                        readonly columns: readonly ["menu_item_id", "event_timestamp"];
                        readonly purpose: "Dimension index for menu item analysis";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_daily_shift";
                        readonly columns: readonly ["daily_shift_id", "event_timestamp"];
                        readonly purpose: "Dimension index for shift-based queries";
                        readonly unique: false;
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["closeOrderL3Handler"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["metricsDerivedFromClosedOrders", "menuPriceIsSnapshottedOnOrderItem", "updatedOnlyByLayer3Usecases"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/topSellingItemsMetrics.defs.ts";
                readonly exportName: "topSellingItemsMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default topSellingItemsMetricsTableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/addOrUpdateOrderItems.defs" {
    export const useCase: {
        readonly usecaseId: "addOrUpdateOrderItems";
        readonly title: "Adicionar/editar itens do pedido";
        readonly purpose: "Alterar itens e quantidades de um pedido em draft, mantendo snapshot de preço e consistência do total.";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["Order"];
        readonly outputEntities: readonly ["Order"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["menuPriceIsSnapshottedOnOrderItem", "orderStatusTransitionsControlled"];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "addOrderItem";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "menuItemId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "quantity";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "orderItemId";
                readonly type: "string";
            }, {
                readonly name: "orderId";
                readonly type: "string";
            }, {
                readonly name: "totalAmount";
                readonly type: "number";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }, {
            readonly commandId: "updateOrderItem";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "orderItemId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "quantity";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "orderId";
                readonly type: "string";
            }, {
                readonly name: "totalAmount";
                readonly type: "number";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }, {
            readonly commandId: "removeOrderItem";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "orderItemId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "orderId";
                readonly type: "string";
            }, {
                readonly name: "totalAmount";
                readonly type: "number";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
        readonly pendingQuestions: readonly ["A remoção de itens deve ser tratada neste mesmo usecase (addOrUpdateOrderItems) ou em um usecase separado?", "O preço snapshotado é calculado pelo usecase a partir do menu_item (MDM) ou pode ser enviado pelo BFF?", "O updateOrderItem deve permitir trocar o menuItem vinculado ou apenas quantidade e observações?"];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/cancelOrder.defs" {
    export const useCase: {
        readonly usecaseId: "cancelOrder";
        readonly title: "Cancelar pedido";
        readonly purpose: "Cancelar pedido não fechado, respeitando transições; se já houver movimentação de estoque associada (ex.: venda), impedir ou exigir reversão.";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["Order", "InventoryTransaction"];
        readonly outputEntities: readonly ["Order"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_transaction";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "order"];
        readonly commands: readonly [{
            readonly commandId: "cancelOrder";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "reason";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "allowInventoryReversal";
                readonly type: "boolean";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "orderId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "canceledAt";
                readonly type: "date";
            }, {
                readonly name: "inventoryMovementDetected";
                readonly type: "boolean";
            }, {
                readonly name: "inventoryReversed";
                readonly type: "boolean";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/closeDailyShiftAndGenerateReport.defs" {
    export const useCase: {
        readonly usecaseId: "closeDailyShiftAndGenerateReport";
        readonly title: "Fechar turno e gerar relatório";
        readonly purpose: "Fechar o turno, consolidar vendas do período e preparar dados para relatório e métricas do turno.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["DailyShift", "Order"];
        readonly outputEntities: readonly ["DailyShift"];
        readonly readsTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "shift_summary_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "today_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["metricsDerivedFromClosedOrders"];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "order"];
        readonly commands: readonly [{
            readonly commandId: "closeDailyShiftAndGenerateReport";
            readonly input: readonly [{
                readonly name: "shiftId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "closedBy";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "closedAt";
                readonly type: "date";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "shiftId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "startedAt";
                readonly type: "date";
            }, {
                readonly name: "closedAt";
                readonly type: "date";
            }, {
                readonly name: "closedBy";
                readonly type: "string";
            }, {
                readonly name: "totalOrders";
                readonly type: "number";
            }, {
                readonly name: "totalRevenue";
                readonly type: "number";
            }, {
                readonly name: "totalItemsSold";
                readonly type: "number";
            }, {
                readonly name: "averageTicket";
                readonly type: "number";
            }];
        }];
        readonly pendingQuestions: readonly ["O campo closedAt deve ser obrigatório no input ou pode ser inferido pelo servidor quando omitido?", "O output deve incluir a lista de itens mais vendidos (topSellingItems) ou apenas os totais agregados?", "Existe algum campo adicional de justificativa/observação no fechamento do turno que deve ser capturado?"];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/closeOrderAsSaleAndDeductInventory.defs" {
    export const useCase: {
        readonly usecaseId: "closeOrderAsSaleAndDeductInventory";
        readonly title: "Fechar pedido (registrar venda) e baixar estoque";
        readonly purpose: "Transicionar pedido delivered→closed, registrar evento de venda, efetuar baixa automática por receita e atualizar métricas derivadas.";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["Order", "DailyShift", "InventoryBalanceSnapshot"];
        readonly outputEntities: readonly ["Order", "InventoryTransaction", "InventoryBalanceSnapshot"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "recipe";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe_ingredient";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "inventory_balance_snapshot";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_transaction";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_balance_snapshot";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "today_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "shift_summary_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderStatusTransitionsControlled", "inventoryDeductionHappensOnSaleEvent", "inventoryCannotGoNegativeByDefault", "metricsDerivedFromClosedOrders"];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "closeOrderAsSaleAndDeductInventory";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "orderId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "closedAt";
                readonly type: "date";
            }, {
                readonly name: "inventoryTransactionsCount";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/createOrderDraft.defs" {
    export const useCase: {
        readonly usecaseId: "createOrderDraft";
        readonly title: "Criar pedido (rascunho)";
        readonly purpose: "Criar um pedido draft para mesa ou takeout, vinculado ao turno aberto, com itens iniciais e preços snapshot.";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["DailyShift", "DiningTable"];
        readonly outputEntities: readonly ["Order"];
        readonly readsTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "dining_table";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "menu_category";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderTypeMustBeTableOrTakeout", "shiftMustBeOpenToCreateOrders", "menuPriceIsSnapshottedOnOrderItem"];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "createOrderDraft";
            readonly input: readonly [{
                readonly name: "orderType";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "tableId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "shiftId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "items";
                readonly type: "OrderDraftItem[]";
                readonly required: false;
            }, {
                readonly name: "attendantId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "orderId";
                readonly type: "string";
            }, {
                readonly name: "orderType";
                readonly type: "string";
            }, {
                readonly name: "tableId";
                readonly type: "string";
            }, {
                readonly name: "shiftId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "totalAmount";
                readonly type: "number";
            }, {
                readonly name: "createdAt";
                readonly type: "date";
            }];
        }];
        readonly pendingQuestions: readonly ["O shiftId deve ser informado explicitamente como input ou inferido automaticamente pelo usecase a partir do turno aberto atual?", "A criação do pedido permite rascunho sem itens iniciais ou os itens são obrigatórios neste comando?", "Para pedidos do tipo 'table', a vinculação com tableId é obrigatória neste comando ou pode ser realizada em um passo posterior?"];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/getAiInsightRun.defs" {
    export const useCase: {
        readonly usecaseId: "getAiInsightRun";
        readonly title: "Consultar execução de insight de IA";
        readonly purpose: "Obter status e conteúdo de uma execução de insight de IA (requested/succeeded/failed).";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["AiInsightRun"];
        readonly outputEntities: readonly ["AiInsightRun"];
        readonly readsTables: readonly [{
            readonly tableName: "ai_insight_run";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["aiInsightRun"];
        readonly commands: readonly [{
            readonly commandId: "getAiInsightRun";
            readonly input: readonly [{
                readonly name: "runId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "runId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "content";
                readonly type: "string";
            }, {
                readonly name: "requestedAt";
                readonly type: "date";
            }, {
                readonly name: "completedAt";
                readonly type: "date";
            }, {
                readonly name: "errorMessage";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/getInventorySnapshotByItem.defs" {
    export const useCase: {
        readonly usecaseId: "getInventorySnapshotByItem";
        readonly title: "Consultar snapshot de saldo por ingrediente";
        readonly purpose: "Obter detalhes do snapshot de saldo atual para um ingrediente específico conforme allowedOperations.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["InventoryBalanceSnapshot"];
        readonly outputEntities: readonly ["InventoryBalanceSnapshot"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_balance_snapshot";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["inventoryTransaction", "menuItem"];
        readonly commands: readonly [{
            readonly commandId: "getInventorySnapshotByItem";
            readonly input: readonly [{
                readonly name: "itemId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "itemId";
                readonly type: "string";
            }, {
                readonly name: "itemName";
                readonly type: "string";
            }, {
                readonly name: "currentBalance";
                readonly type: "number";
            }, {
                readonly name: "availableQuantity";
                readonly type: "number";
            }, {
                readonly name: "reservedQuantity";
                readonly type: "number";
            }, {
                readonly name: "unitOfMeasure";
                readonly type: "string";
            }, {
                readonly name: "lastUpdatedAt";
                readonly type: "date";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/getMenuItemWithRecipe.defs" {
    export const useCase: {
        readonly usecaseId: "getMenuItemWithRecipe";
        readonly title: "Consultar item do cardápio com receita";
        readonly purpose: "Obter detalhes de um item e sua receita/ingredientes para edição e validação.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["MenuAndRecipeCatalog"];
        readonly outputEntities: readonly ["MenuAndRecipeCatalog"];
        readonly readsTables: readonly [{
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe_ingredient";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["aiInsightRun", "inventoryTransaction", "menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "getMenuItemWithRecipe";
            readonly input: readonly [{
                readonly name: "menuItemId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "menuItem";
                readonly type: "MenuItem";
            }, {
                readonly name: "recipe";
                readonly type: "Recipe";
            }, {
                readonly name: "ingredients";
                readonly type: "RecipeIngredient[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/getOrderById.defs" {
    export const useCase: {
        readonly usecaseId: "getOrderById";
        readonly title: "Consultar pedido por id";
        readonly purpose: "Obter detalhes do pedido e itens para POS/KDS/acompanhar status.";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["Order", "DiningTable"];
        readonly outputEntities: readonly ["Order", "DiningTable"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "dining_table";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "getOrderById";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "orderId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "tableId";
                readonly type: "string";
            }, {
                readonly name: "tableNumber";
                readonly type: "string";
            }, {
                readonly name: "items";
                readonly type: "OrderItem[]";
            }, {
                readonly name: "totalAmount";
                readonly type: "number";
            }, {
                readonly name: "createdAt";
                readonly type: "date";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/getShiftCloseReport.defs" {
    export const useCase: {
        readonly usecaseId: "getShiftCloseReport";
        readonly title: "Obter relatório de fechamento de turno";
        readonly purpose: "Consultar relatório consolidado do turno (vendas, itens, totais) para exibição/impressão.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["DailyShift", "Order"];
        readonly outputEntities: readonly ["DailyShift", "Order"];
        readonly readsTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "shift_summary_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "order"];
        readonly commands: readonly [{
            readonly commandId: "getShiftCloseReport";
            readonly input: readonly [{
                readonly name: "shiftId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "shiftId";
                readonly type: "string";
            }, {
                readonly name: "shiftDate";
                readonly type: "date";
            }, {
                readonly name: "openedAt";
                readonly type: "date";
            }, {
                readonly name: "closedAt";
                readonly type: "date";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "totalSales";
                readonly type: "number";
            }, {
                readonly name: "totalOrders";
                readonly type: "number";
            }, {
                readonly name: "totalItemsSold";
                readonly type: "number";
            }, {
                readonly name: "totalDiscounts";
                readonly type: "number";
            }, {
                readonly name: "netSales";
                readonly type: "number";
            }, {
                readonly name: "averageTicket";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/getTodayDashboardMetrics.defs" {
    export const useCase: {
        readonly usecaseId: "getTodayDashboardMetrics";
        readonly title: "Obter métricas do dashboard de hoje";
        readonly purpose: "Buscar métricas do dia (vendas, itens mais vendidos, alertas de estoque baixo) para o dashboard do gerente.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["DailyShift"];
        readonly outputEntities: readonly ["DailyShift"];
        readonly readsTables: readonly [{
            readonly tableName: "today_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "order"];
        readonly commands: readonly [{
            readonly commandId: "getTodayDashboardMetrics";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "todaySalesMetrics";
                readonly type: "OrderAggregate";
            }, {
                readonly name: "topSellingItemsMetrics";
                readonly type: "OrderAggregate";
            }, {
                readonly name: "lowStockAlerts";
                readonly type: "InventoryAggregate";
            }, {
                readonly name: "currentShift";
                readonly type: "ShiftAggregate";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/listAiInsightRuns.defs" {
    export const useCase: {
        readonly usecaseId: "listAiInsightRuns";
        readonly title: "Listar execuções de insights de IA";
        readonly purpose: "Listar execuções recentes para histórico e reabertura no assistente.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["AiInsightRun"];
        readonly outputEntities: readonly ["AiInsightRun"];
        readonly readsTables: readonly [{
            readonly tableName: "ai_insight_run";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["aiInsightRun"];
        readonly commands: readonly [{
            readonly commandId: "listAiInsightRuns";
            readonly input: readonly [{
                readonly name: "limit";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "statusFilter";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "fromDate";
                readonly type: "date";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "runs";
                readonly type: "AiInsightRun[]";
            }, {
                readonly name: "totalCount";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/listDiningTables.defs" {
    export const useCase: {
        readonly usecaseId: "listDiningTables";
        readonly title: "Listar mesas";
        readonly purpose: "Listar mesas ativas para seleção no POS.";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["DiningTable"];
        readonly outputEntities: readonly ["DiningTable"];
        readonly readsTables: readonly [{
            readonly tableName: "dining_table";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["order"];
        readonly commands: readonly [{
            readonly commandId: "listDiningTables";
            readonly input: readonly [{
                readonly name: "areaId";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "diningTables";
                readonly type: "DiningTable[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/listInventoryBalances.defs" {
    export const useCase: {
        readonly usecaseId: "listInventoryBalances";
        readonly title: "Listar saldos de estoque (snapshots)";
        readonly purpose: "Listar saldos atuais por ingrediente para acompanhamento.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["InventoryBalanceSnapshot"];
        readonly outputEntities: readonly ["InventoryBalanceSnapshot"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_balance_snapshot";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["inventoryTransaction", "menuItem"];
        readonly commands: readonly [{
            readonly commandId: "listInventoryBalances";
            readonly input: readonly [{
                readonly name: "ingredientId";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "items";
                readonly type: "InventoryAggregate[]";
            }, {
                readonly name: "totalCount";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/listInventoryItems.defs" {
    export const useCase: {
        readonly usecaseId: "listInventoryItems";
        readonly title: "Listar ingredientes (MDM)";
        readonly purpose: "Listar itens de estoque (ingredientes) para gestão e composição de receitas.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["MenuAndRecipeCatalog"];
        readonly outputEntities: readonly ["MenuAndRecipeCatalog"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["inventoryTransaction", "menuItem"];
        readonly commands: readonly [{
            readonly commandId: "listInventoryItems";
            readonly input: readonly [{
                readonly name: "searchQuery";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "category";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "isActive";
                readonly type: "boolean";
                readonly required: false;
            }, {
                readonly name: "page";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "pageSize";
                readonly type: "number";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "items";
                readonly type: "inventoryItem[]";
            }, {
                readonly name: "totalCount";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/listInventoryTransactions.defs" {
    export const useCase: {
        readonly usecaseId: "listInventoryTransactions";
        readonly title: "Listar movimentações de estoque";
        readonly purpose: "Consultar movimentações de estoque (ajustes e baixas) para auditoria simples.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["InventoryTransaction"];
        readonly outputEntities: readonly ["InventoryTransaction"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_transaction";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["inventoryTransaction", "menuItem"];
        readonly commands: readonly [{
            readonly commandId: "listInventoryTransactions";
            readonly input: readonly [{
                readonly name: "startDate";
                readonly type: "date";
                readonly required: false;
            }, {
                readonly name: "endDate";
                readonly type: "date";
                readonly required: false;
            }, {
                readonly name: "inventoryItemId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "transactionType";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "page";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "pageSize";
                readonly type: "number";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "totalCount";
                readonly type: "number";
            }, {
                readonly name: "transactions";
                readonly type: "InventoryTransaction";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/listKitchenQueue.defs" {
    export const useCase: {
        readonly usecaseId: "listKitchenQueue";
        readonly title: "Listar fila da cozinha (KDS)";
        readonly purpose: "Exibir fila de pedidos enviados à cozinha e em preparação/prontos.";
        readonly actor: "cook";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["Order"];
        readonly outputEntities: readonly ["Order"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "listKitchenQueue";
            readonly input: readonly [{
                readonly name: "statusFilter";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "limit";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "offset";
                readonly type: "number";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "orders";
                readonly type: "OrderAggregate[]";
            }, {
                readonly name: "totalCount";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/listMenuItems.defs" {
    export const useCase: {
        readonly usecaseId: "listMenuItems";
        readonly title: "Listar itens do cardápio";
        readonly purpose: "Listar itens do cardápio (ativos/inativos), categorias e preços para POS e gestão.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["MenuAndRecipeCatalog"];
        readonly outputEntities: readonly ["MenuAndRecipeCatalog"];
        readonly readsTables: readonly [{
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "menu_category";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["aiInsightRun", "inventoryTransaction", "menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "listMenuItems";
            readonly input: readonly [{
                readonly name: "status";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "categoryId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "searchTerm";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "page";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "pageSize";
                readonly type: "number";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "items";
                readonly type: "menuItem[]";
            }, {
                readonly name: "totalCount";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/listOrdersByStatus.defs" {
    export const useCase: {
        readonly usecaseId: "listOrdersByStatus";
        readonly title: "Listar pedidos por status";
        readonly purpose: "Listar pedidos (ex.: em aberto) filtrando por status e turno, para POS e acompanhamento.";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["Order", "DailyShift", "DiningTable"];
        readonly outputEntities: readonly ["Order", "DailyShift", "DiningTable"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "dining_table";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "order"];
        readonly commands: readonly [{
            readonly commandId: "listOrdersByStatus";
            readonly input: readonly [{
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "shiftId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "orders";
                readonly type: "OrderAggregate[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/markOrderDelivered.defs" {
    export const useCase: {
        readonly usecaseId: "markOrderDelivered";
        readonly title: "Marcar pedido como entregue/retirado";
        readonly purpose: "Transicionar pedido ready→delivered para mesa ou retirada.";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["Order"];
        readonly outputEntities: readonly ["Order"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "order"];
        readonly commands: readonly [{
            readonly commandId: "markOrderDelivered";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "operatorId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "orderId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "deliveredAt";
                readonly type: "date";
            }, {
                readonly name: "orderType";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/openDailyShift.defs" {
    export const useCase: {
        readonly usecaseId: "openDailyShift";
        readonly title: "Abrir turno diário";
        readonly purpose: "Abrir um turno (open) para permitir criação de pedidos; registrar dados iniciais (ex.: caixa inicial) se aplicável.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["DailyShift"];
        readonly outputEntities: readonly ["DailyShift"];
        readonly readsTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["shiftMustBeOpenToCreateOrders"];
        readonly entityRefs: readonly ["dailyShift", "order"];
        readonly commands: readonly [{
            readonly commandId: "openDailyShift";
            readonly input: readonly [{
                readonly name: "shiftDate";
                readonly type: "date";
                readonly required: true;
            }, {
                readonly name: "initialCash";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "openedByUserId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "shiftId";
                readonly type: "string";
            }, {
                readonly name: "shiftDate";
                readonly type: "date";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "initialCash";
                readonly type: "number";
            }, {
                readonly name: "openedAt";
                readonly type: "date";
            }, {
                readonly name: "openedByUserId";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/postInventoryAdjustment.defs" {
    export const useCase: {
        readonly usecaseId: "postInventoryAdjustment";
        readonly title: "Registrar ajuste manual de estoque";
        readonly purpose: "Registrar uma movimentação manual (entrada/saída/contagem) e atualizar snapshot de saldo e métricas de estoque baixo.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["InventoryBalanceSnapshot"];
        readonly outputEntities: readonly ["InventoryTransaction", "InventoryBalanceSnapshot"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_balance_snapshot";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "inventory_transaction";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_balance_snapshot";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["inventoryCannotGoNegativeByDefault"];
        readonly entityRefs: readonly ["inventoryTransaction", "menuItem"];
        readonly commands: readonly [{
            readonly commandId: "postAdjustment";
            readonly input: readonly [{
                readonly name: "itemId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "movementType";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "quantity";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "costPerUnit";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "reasonCode";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "transactionId";
                readonly type: "string";
            }, {
                readonly name: "itemId";
                readonly type: "string";
            }, {
                readonly name: "previousBalance";
                readonly type: "number";
            }, {
                readonly name: "newBalance";
                readonly type: "number";
            }, {
                readonly name: "lowStockAlert";
                readonly type: "boolean";
            }, {
                readonly name: "recordedAt";
                readonly type: "date";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/requestAiPromoSuggestions.defs" {
    export const useCase: {
        readonly usecaseId: "requestAiPromoSuggestions";
        readonly title: "Gerar sugestões de promoção (7 dias) (IA)";
        readonly purpose: "Solicitar ao proxy LLM sugestões de itens para promover com base em histórico agregado (ex.: top itens) e registrar execução.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["AiInsightsAggregate"];
        readonly outputEntities: readonly ["AiInsightRun"];
        readonly readsTables: readonly [{
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "ai_insight_run";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy"];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "requestAiPromoSuggestions";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "insightId";
                readonly type: "string";
            }, {
                readonly name: "runId";
                readonly type: "string";
            }, {
                readonly name: "suggestions";
                readonly type: "string";
            }, {
                readonly name: "createdAt";
                readonly type: "date";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/requestAiSalesSummary.defs" {
    export const useCase: {
        readonly usecaseId: "requestAiSalesSummary";
        readonly title: "Gerar resumo de vendas do dia (IA)";
        readonly purpose: "Solicitar ao proxy LLM um resumo de vendas do dia e registrar a execução; pode usar métricas como contexto.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["DailyShift"];
        readonly outputEntities: readonly ["AiInsightRun"];
        readonly readsTables: readonly [{
            readonly tableName: "today_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "ai_insight_run";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy"];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "requestAiSalesSummary";
            readonly input: readonly [{
                readonly name: "targetDate";
                readonly type: "date";
                readonly required: false;
            }, {
                readonly name: "includeMetricsContext";
                readonly type: "boolean";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "runId";
                readonly type: "string";
            }, {
                readonly name: "summary";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/sendOrderToKitchen.defs" {
    export const useCase: {
        readonly usecaseId: "sendOrderToKitchen";
        readonly title: "Enviar pedido para cozinha";
        readonly purpose: "Transicionar pedido de draft para sentToKitchen e disponibilizar na fila do KDS.";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["Order", "DailyShift"];
        readonly outputEntities: readonly ["Order"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderStatusTransitionsControlled", "shiftMustBeOpenToCreateOrders"];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "order"];
        readonly commands: readonly [{
            readonly commandId: "sendOrderToKitchen";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "orderId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "sentAt";
                readonly type: "date";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/updateKitchenOrderStatus.defs" {
    export const useCase: {
        readonly usecaseId: "updateKitchenOrderStatus";
        readonly title: "Atualizar status do pedido (cozinha)";
        readonly purpose: "Cozinha atualiza status do pedido (sentToKitchen→inPreparation→ready) de forma controlada.";
        readonly actor: "cook";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["Order"];
        readonly outputEntities: readonly ["Order"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "order"];
        readonly commands: readonly [{
            readonly commandId: "updateKitchenOrderStatus";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "targetStatus";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "cookId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "orderId";
                readonly type: "string";
            }, {
                readonly name: "previousStatus";
                readonly type: "string";
            }, {
                readonly name: "currentStatus";
                readonly type: "string";
            }, {
                readonly name: "updatedAt";
                readonly type: "date";
            }];
        }];
        readonly pendingQuestions: readonly ["O identificador do cozinheiro (cookId) deve ser recebido explicitamente no comando ou obtido do contexto de autenticação/autorização?", "O comando deve receber o status de destino (targetStatus) ou apenas avançar automaticamente para o próximo status válido na sequência (sentToKitchen → inPreparation → ready)?", "O retorno deve incluir o aggregate completo do pedido (OrderAggregate) ou apenas os campos essenciais de status atualizados?"];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/upsertInventoryItem.defs" {
    export const useCase: {
        readonly usecaseId: "upsertInventoryItem";
        readonly title: "Criar/editar/desativar ingrediente (MDM)";
        readonly purpose: "Manter cadastro de itens de estoque (ingredientes/insumos) via MDM.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["MenuAndRecipeCatalog"];
        readonly outputEntities: readonly ["MenuAndRecipeCatalog"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["inventoryTransaction", "menuItem"];
        readonly commands: readonly [{
            readonly commandId: "upsertInventoryItem";
            readonly input: readonly [{
                readonly name: "inventoryItemId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "name";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "unitOfMeasure";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "sku";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "categoryId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "costReference";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "isActive";
                readonly type: "boolean";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "inventoryItemId";
                readonly type: "string";
            }, {
                readonly name: "name";
                readonly type: "string";
            }, {
                readonly name: "unitOfMeasure";
                readonly type: "string";
            }, {
                readonly name: "sku";
                readonly type: "string";
            }, {
                readonly name: "categoryId";
                readonly type: "string";
            }, {
                readonly name: "costReference";
                readonly type: "number";
            }, {
                readonly name: "isActive";
                readonly type: "boolean";
            }, {
                readonly name: "updatedAt";
                readonly type: "date";
            }];
        }, {
            readonly commandId: "deactivateInventoryItem";
            readonly input: readonly [{
                readonly name: "inventoryItemId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "inventoryItemId";
                readonly type: "string";
            }, {
                readonly name: "isActive";
                readonly type: "boolean";
            }, {
                readonly name: "deactivatedAt";
                readonly type: "date";
            }];
        }];
        readonly pendingQuestions: readonly ["A desativação do ingrediente é lógica (soft delete via flag isActive) ou física (remoção do registro)?", "Há campos obrigatórios adicionais na tabela inventory_item que devem constar no input (ex: tenantId, restaurantId, externalMdmId, barcode, conversionFactor)?", "O comando upsert deve permitir reativação (isActive=true) ou apenas a criação/edição de dados cadastrais, ficando a desativação/reativação exclusiva para o comando deactivate?"];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/upsertMenuItemAndRecipe.defs" {
    export const useCase: {
        readonly usecaseId: "upsertMenuItemAndRecipe";
        readonly title: "Criar/editar/desativar item do cardápio e receita";
        readonly purpose: "Manter item do cardápio e sua receita/ingredientes (consumo) via MDM, garantindo consistência para baixa automática.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["MenuAndRecipeCatalog"];
        readonly outputEntities: readonly ["MenuAndRecipeCatalog"];
        readonly readsTables: readonly [{
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe_ingredient";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "menu_category";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe_ingredient";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["aiInsightRun", "inventoryTransaction", "menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "upsertMenuItemAndRecipe";
            readonly input: readonly [{
                readonly name: "menuItemId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "name";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "description";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "price";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "categoryId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "isActive";
                readonly type: "boolean";
                readonly required: false;
            }, {
                readonly name: "recipeInstructions";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "recipeYield";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "ingredients";
                readonly type: "RecipeIngredientInput[]";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "menuItemId";
                readonly type: "string";
            }, {
                readonly name: "recipeId";
                readonly type: "string";
            }, {
                readonly name: "name";
                readonly type: "string";
            }, {
                readonly name: "price";
                readonly type: "number";
            }, {
                readonly name: "categoryId";
                readonly type: "string";
            }, {
                readonly name: "isActive";
                readonly type: "boolean";
            }, {
                readonly name: "updatedAt";
                readonly type: "date";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_4_entities/aiInsightRun.defs" {
    export const entity: {
        readonly entityId: "aiInsightRun";
        readonly title: "Execuções de Insights de IA";
        readonly purpose: "Registrar e consultar execuções de insights de IA (às solicitações, sucesso/falha) e armazenar resultados para exibição no assistente.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "aiInsightRunId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da execução de insight de IA";
        }, {
            readonly fieldId: "dailyShiftId";
            readonly type: "uuid";
            readonly required: false;
            readonly description: "Referência ao turno diário quando o insight está relacionado a um turno específico";
        }, {
            readonly fieldId: "insightType";
            readonly type: "string";
            readonly required: true;
            readonly description: "Categoria do insight solicitado";
            readonly enum: readonly ["dailySummary", "salesTrend", "inventoryAlert", "menuSuggestion", "shiftClosing"];
        }, {
            readonly fieldId: "parameters";
            readonly type: "text";
            readonly required: false;
            readonly description: "Parâmetros adicionais da solicitação em formato JSON ou texto livre";
        }, {
            readonly fieldId: "timeWindowStart";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Início da janela temporal dos dados analisados";
        }, {
            readonly fieldId: "timeWindowEnd";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Fim da janela temporal dos dados analisados";
        }, {
            readonly fieldId: "language";
            readonly type: "string";
            readonly required: true;
            readonly description: "Idioma solicitado para o insight e do resultado gerado";
            readonly enum: readonly ["pt-BR", "en"];
        }, {
            readonly fieldId: "promptVersion";
            readonly type: "string";
            readonly required: false;
            readonly description: "Versão do prompt ou do modelo utilizado";
        }, {
            readonly fieldId: "promptText";
            readonly type: "text";
            readonly required: false;
            readonly description: "Texto completo do prompt enviado ao serviço de IA";
        }, {
            readonly fieldId: "resultText";
            readonly type: "text";
            readonly required: false;
            readonly description: "Resposta/resultado gerado pelo modelo de IA";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Status atual da execução do insight";
            readonly enum: readonly ["requested", "succeeded", "failed"];
        }, {
            readonly fieldId: "errorMessage";
            readonly type: "text";
            readonly required: false;
            readonly description: "Detalhes do erro quando a execução falha";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro";
        }];
        readonly statusEnum: readonly ["requested", "succeeded", "failed"];
        readonly lifecycleStates: readonly ["requested", "succeeded", "failed"];
        readonly ontologyEntities: readonly ["AiInsightRun", "Order", "MenuItem"];
        readonly sourceTables: readonly [{
            readonly tableName: "ai_insight_run";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "today_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "aiInsightRun";
            readonly tableName: "ai_insight_run";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/aiInsightRun.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "order";
            readonly tableName: "order";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/order.defs.ts";
        }, {
            readonly kind: "unknown";
            readonly tableName: "order_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "todaySalesMetrics";
            readonly tableName: "today_sales_metrics";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/todaySalesMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "topSellingItemsMetrics";
            readonly tableName: "top_selling_items_metrics";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.defs.ts";
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "MenuItem";
            readonly domainId: "menuItem";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Cada item deve pertencer a uma categoria ativa", "Status permitido: active ou inactive", "Preço deve ser maior ou igual a zero", "Nome do item deve ser único por categoria dentro do tenant", "Alterações de preço não afetam pedidos já fechados (snapshot no OrderItem)"];
        }];
        readonly allowedOperations: readonly ["requestSalesSummary", "requestPromoSuggestions", "getAiInsightRun", "listAiInsightRuns", "markAiRunSucceeded", "markAiRunFailed"];
        readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy", "metricsDerivedFromClosedOrders"];
        readonly usecaseRefs: readonly ["createOrderDraft", "addOrUpdateOrderItems", "sendOrderToKitchen", "updateKitchenOrderStatus", "markOrderDelivered", "closeOrderAsSaleAndDeductInventory", "cancelOrder", "getOrderById", "listOrdersByStatus", "listKitchenQueue", "closeDailyShiftAndGenerateReport", "getShiftCloseReport", "getTodayDashboardMetrics", "upsertMenuItemAndRecipe", "listMenuItems", "getMenuItemWithRecipe", "requestAiSalesSummary", "requestAiPromoSuggestions", "getAiInsightRun", "listAiInsightRuns"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/AiInsightRunEntity.ts";
            readonly className: "AiInsightRunEntity";
            readonly contractName: "IAiInsightRunEntity";
        };
    };
    export default entity;
}
declare module "_102048_/l1/cafeFlow/layer_4_entities/dailyShift.defs" {
    export const entity: {
        readonly entityId: "dailyShift";
        readonly title: "Agregado de Turno Diário";
        readonly purpose: "Abrir/fechar turno diário, consolidar vendas e gerar dados para relatório e métricas do turno.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "dailyShiftId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do turno diário";
        }, {
            readonly fieldId: "shiftDate";
            readonly type: "date";
            readonly required: true;
            readonly description: "Data de referência do turno operacional";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly enum: readonly ["open", "closed"];
            readonly description: "Situação atual do turno (aberto ou fechado)";
        }, {
            readonly fieldId: "openedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da abertura do turno";
        }, {
            readonly fieldId: "closedAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora do fechamento do turno";
        }, {
            readonly fieldId: "openedBy";
            readonly type: "string";
            readonly required: false;
            readonly description: "Nome do operador que abriu o turno";
        }, {
            readonly fieldId: "closedBy";
            readonly type: "string";
            readonly required: false;
            readonly description: "Nome do operador que fechou o turno";
        }, {
            readonly fieldId: "closingNotes";
            readonly type: "text";
            readonly required: false;
            readonly description: "Observações gerais registradas no fechamento do turno";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro";
        }];
        readonly statusEnum: readonly ["open", "closed"];
        readonly lifecycleStates: readonly ["open", "closed"];
        readonly ontologyEntities: readonly ["DailyShift", "Order"];
        readonly sourceTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "shift_summary_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "today_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "dailyShift";
            readonly tableName: "daily_shift";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/dailyShift.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "order";
            readonly tableName: "order";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/order.defs.ts";
        }, {
            readonly kind: "unknown";
            readonly tableName: "order_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "shiftSummaryMetrics";
            readonly tableName: "shift_summary_metrics";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/shiftSummaryMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "todaySalesMetrics";
            readonly tableName: "today_sales_metrics";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/todaySalesMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "topSellingItemsMetrics";
            readonly tableName: "top_selling_items_metrics";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.defs.ts";
        }];
        readonly allowedOperations: readonly ["openShift", "closeShift", "getShiftById", "getOpenShift", "listShifts", "getShiftCloseReport"];
        readonly rulesApplied: readonly ["shiftMustBeOpenToCreateOrders", "metricsDerivedFromClosedOrders"];
        readonly usecaseRefs: readonly ["createOrderDraft", "addOrUpdateOrderItems", "sendOrderToKitchen", "updateKitchenOrderStatus", "markOrderDelivered", "closeOrderAsSaleAndDeductInventory", "cancelOrder", "getOrderById", "listOrdersByStatus", "listKitchenQueue", "openDailyShift", "closeDailyShiftAndGenerateReport", "getShiftCloseReport", "getTodayDashboardMetrics", "requestAiSalesSummary", "requestAiPromoSuggestions"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/DailyShiftEntity.ts";
            readonly className: "DailyShiftEntity";
            readonly contractName: "IDailyShiftEntity";
        };
    };
    export default entity;
}
declare module "_102048_/l1/cafeFlow/layer_4_entities/inventoryTransaction.defs" {
    export const entity: {
        readonly entityId: "inventoryTransaction";
        readonly title: "Agregado de Estoque (Movimentação e Saldos)";
        readonly purpose: "Registrar ajustes manuais e baixas automáticas por venda, manter snapshots de saldo e atualizar métricas de estoque baixo.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "inventoryTransactionId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da movimentação de estoque.";
        }, {
            readonly fieldId: "inventoryItemId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao ingrediente/insumo movimentado.";
        }, {
            readonly fieldId: "orderId";
            readonly type: "uuid";
            readonly required: false;
            readonly description: "Referência ao pedido origem em caso de baixa automática por venda.";
        }, {
            readonly fieldId: "transactionType";
            readonly type: "string";
            readonly required: true;
            readonly description: "Tipo da movimentação: entrada de estoque, baixa por venda ou ajuste manual.";
            readonly enum: readonly ["entrada", "baixaVenda", "ajuste"];
        }, {
            readonly fieldId: "quantityChange";
            readonly type: "number";
            readonly required: true;
            readonly description: "Quantidade alterada no estoque. Positivo para entrada, negativo para baixa ou ajuste de redução.";
        }, {
            readonly fieldId: "reason";
            readonly type: "text";
            readonly required: false;
            readonly description: "Motivo do ajuste manual ou observação sobre a movimentação.";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Status do registro: lançado ou estornado.";
            readonly enum: readonly ["posted", "reversed"];
        }, {
            readonly fieldId: "recordedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora em que a movimentação ocorreu efetivamente.";
        }, {
            readonly fieldId: "createdBy";
            readonly type: "string";
            readonly required: false;
            readonly description: "Identificador do usuário responsável pelo registro.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro.";
        }];
        readonly statusEnum: readonly ["posted", "reversed"];
        readonly ontologyEntities: readonly ["InventoryTransaction", "InventoryBalanceSnapshot", "Order", "InventoryItem", "Recipe", "RecipeIngredient", "MenuItem"];
        readonly sourceTables: readonly [{
            readonly tableName: "inventory_transaction";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_balance_snapshot";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe_ingredient";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "inventoryTransaction";
            readonly tableName: "inventory_transaction";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/inventoryTransaction.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "inventoryBalanceSnapshot";
            readonly tableName: "inventory_balance_snapshot";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/inventoryBalanceSnapshot.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "lowStockMetrics";
            readonly tableName: "low_stock_metrics";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/lowStockMetrics.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "order";
            readonly tableName: "order";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/order.defs.ts";
        }, {
            readonly kind: "unknown";
            readonly tableName: "order_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "InventoryItem";
            readonly domainId: "inventoryItem";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Unidade de medida obrigatória e padronizada", "Limiar de estoque baixo deve ser maior ou igual a zero", "Status permitido: active ou inactive", "Nome do ingrediente deve ser único dentro do tenant", "Saldo atual é derivado das movimentações e não deve ser editado diretamente"];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "Recipe";
            readonly domainId: "recipe";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Apenas uma receita ativa por item do cardápio", "Ingredientes da receita devem referenciar itens de estoque ativos", "Quantidades consumidas devem ser maiores que zero", "Status permitido: draft, active ou archived", "Alterações na receita afetam apenas baixas futuras; pedidos fechados preservam histórico via OrderItem"];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "RecipeIngredient";
            readonly domainId: "recipe";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Apenas uma receita ativa por item do cardápio", "Ingredientes da receita devem referenciar itens de estoque ativos", "Quantidades consumidas devem ser maiores que zero", "Status permitido: draft, active ou archived", "Alterações na receita afetam apenas baixas futuras; pedidos fechados preservam histórico via OrderItem"];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "MenuItem";
            readonly domainId: "menuItem";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Cada item deve pertencer a uma categoria ativa", "Status permitido: active ou inactive", "Preço deve ser maior ou igual a zero", "Nome do item deve ser único por categoria dentro do tenant", "Alterações de preço não afetam pedidos já fechados (snapshot no OrderItem)"];
        }];
        readonly allowedOperations: readonly ["postInventoryAdjustment", "deductInventoryFromClosedOrder", "reverseInventoryTransaction", "getInventorySnapshotByItem", "listInventorySnapshots", "listInventoryTransactions", "getLowStockList"];
        readonly rulesApplied: readonly ["inventoryDeductionHappensOnSaleEvent", "inventoryCannotGoNegativeByDefault", "metricsDerivedFromClosedOrders"];
        readonly usecaseRefs: readonly ["createOrderDraft", "addOrUpdateOrderItems", "sendOrderToKitchen", "updateKitchenOrderStatus", "markOrderDelivered", "closeOrderAsSaleAndDeductInventory", "cancelOrder", "getOrderById", "listOrdersByStatus", "listKitchenQueue", "closeDailyShiftAndGenerateReport", "getShiftCloseReport", "getTodayDashboardMetrics", "upsertMenuItemAndRecipe", "listMenuItems", "getMenuItemWithRecipe", "upsertInventoryItem", "listInventoryItems", "postInventoryAdjustment", "listInventoryTransactions", "listInventoryBalances", "getInventorySnapshotByItem", "requestAiSalesSummary", "requestAiPromoSuggestions"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/InventoryTransactionEntity.ts";
            readonly className: "InventoryTransactionEntity";
            readonly contractName: "IInventoryTransactionEntity";
        };
    };
    export default entity;
}
declare module "_102048_/l1/cafeFlow/layer_4_entities/menuItem.defs" {
    export const entity: {
        readonly entityId: "menuItem";
        readonly title: "Catálogo de Cardápio e Receitas (MDM)";
        readonly purpose: "Manter itens do cardápio, categorias e receitas/consumo por item via MDM; suportar consulta para POS e configuração de baixa de estoque.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "menuItemId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do item do cardápio";
        }, {
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nome do produto para exibição no POS e no KDS";
        }, {
            readonly fieldId: "description";
            readonly type: "text";
            readonly required: false;
            readonly description: "Descrição opcional do produto para o cardápio digital";
        }, {
            readonly fieldId: "price";
            readonly type: "money";
            readonly required: true;
            readonly description: "Preço de venda praticado no caixa";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly enum: readonly ["active", "inactive"];
            readonly description: "Situação do item no cardápio (ativo ou inativo)";
        }, {
            readonly fieldId: "menuCategoryId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência à categoria do cardápio à qual o item pertence";
        }, {
            readonly fieldId: "sku";
            readonly type: "string";
            readonly required: false;
            readonly description: "Código interno de controle (SKU) do produto";
        }, {
            readonly fieldId: "imageUrl";
            readonly type: "string";
            readonly required: false;
            readonly description: "URL da imagem do produto para exibição no POS";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro";
        }];
        readonly statusEnum: readonly ["active", "inactive"];
        readonly ontologyEntities: readonly ["MenuItem", "MenuCategory", "Recipe", "RecipeIngredient", "InventoryItem"];
        readonly sourceTables: readonly [{
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "menu_category";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe_ingredient";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "MenuItem";
            readonly domainId: "menuItem";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Cada item deve pertencer a uma categoria ativa", "Status permitido: active ou inactive", "Preço deve ser maior ou igual a zero", "Nome do item deve ser único por categoria dentro do tenant", "Alterações de preço não afetam pedidos já fechados (snapshot no OrderItem)"];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "MenuCategory";
            readonly domainId: "menuItem";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Cada item deve pertencer a uma categoria ativa", "Status permitido: active ou inactive", "Preço deve ser maior ou igual a zero", "Nome do item deve ser único por categoria dentro do tenant", "Alterações de preço não afetam pedidos já fechados (snapshot no OrderItem)"];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "Recipe";
            readonly domainId: "recipe";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Apenas uma receita ativa por item do cardápio", "Ingredientes da receita devem referenciar itens de estoque ativos", "Quantidades consumidas devem ser maiores que zero", "Status permitido: draft, active ou archived", "Alterações na receita afetam apenas baixas futuras; pedidos fechados preservam histórico via OrderItem"];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "RecipeIngredient";
            readonly domainId: "recipe";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Apenas uma receita ativa por item do cardápio", "Ingredientes da receita devem referenciar itens de estoque ativos", "Quantidades consumidas devem ser maiores que zero", "Status permitido: draft, active ou archived", "Alterações na receita afetam apenas baixas futuras; pedidos fechados preservam histórico via OrderItem"];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "InventoryItem";
            readonly domainId: "inventoryItem";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Unidade de medida obrigatória e padronizada", "Limiar de estoque baixo deve ser maior ou igual a zero", "Status permitido: active ou inactive", "Nome do ingrediente deve ser único dentro do tenant", "Saldo atual é derivado das movimentações e não deve ser editado diretamente"];
        }];
        readonly allowedOperations: readonly ["createMenuItem", "updateMenuItem", "deactivateMenuItem", "listMenuItems", "getMenuItem", "listMenuCategories", "upsertRecipeForMenuItem", "getRecipeByMenuItem", "listRecipes"];
        readonly rulesApplied: readonly ["bilingualUiViaPlatformI18n"];
        readonly usecaseRefs: readonly ["createOrderDraft", "addOrUpdateOrderItems", "closeOrderAsSaleAndDeductInventory", "getOrderById", "listKitchenQueue", "upsertMenuItemAndRecipe", "listMenuItems", "getMenuItemWithRecipe", "upsertInventoryItem", "listInventoryItems", "postInventoryAdjustment", "listInventoryTransactions", "listInventoryBalances", "getInventorySnapshotByItem", "requestAiSalesSummary", "requestAiPromoSuggestions"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/MenuItemEntity.ts";
            readonly className: "MenuItemEntity";
            readonly contractName: "IMenuItemEntity";
        };
    };
    export default entity;
}
declare module "_102048_/l1/cafeFlow/layer_4_entities/order.defs" {
    export const entity: {
        readonly entityId: "order";
        readonly title: "Agregado de Pedido";
        readonly purpose: "Manter o ciclo de vida do pedido (draft→…→closed/cancelled), itens, preços snapshot, vínculo com mesa/takeout e turno; base para POS, KDS e relatórios.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "id";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do pedido";
        }, {
            readonly fieldId: "orderNumber";
            readonly type: "string";
            readonly required: true;
            readonly description: "Número sequencial ou código de exibição do pedido";
        }, {
            readonly fieldId: "type";
            readonly type: "string";
            readonly required: true;
            readonly enum: readonly ["mesa", "takeout"];
            readonly description: "Tipo do pedido: mesa (com clientes sentados) ou takeout (para viagem)";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly enum: readonly ["draft", "sentToKitchen", "inPreparation", "ready", "delivered", "closed", "cancelled"];
            readonly description: "Status atual do pedido no fluxo de preparo e atendimento";
        }, {
            readonly fieldId: "diningTableId";
            readonly type: "uuid";
            readonly required: false;
            readonly description: "Referência à mesa (obrigatório apenas quando tipo for 'mesa')";
        }, {
            readonly fieldId: "dailyShiftId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao turno diário em que o pedido foi criado";
        }, {
            readonly fieldId: "customerName";
            readonly type: "string";
            readonly required: false;
            readonly description: "Nome do cliente (útil para takeout)";
        }, {
            readonly fieldId: "notes";
            readonly type: "text";
            readonly required: false;
            readonly description: "Observações gerais do pedido";
        }, {
            readonly fieldId: "totalAmount";
            readonly type: "money";
            readonly required: true;
            readonly description: "Valor total do pedido calculado a partir dos itens";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data/hora de criação do pedido";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data/hora da última atualização do pedido";
        }, {
            readonly fieldId: "sentToKitchenAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data/hora em que o pedido foi enviado para a cozinha";
        }, {
            readonly fieldId: "readyAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data/hora em que o pedido ficou pronto para entrega";
        }, {
            readonly fieldId: "deliveredAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data/hora da entrega do pedido ao cliente";
        }, {
            readonly fieldId: "closedAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data/hora do fechamento/pagamento do pedido";
        }, {
            readonly fieldId: "cancelledAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data/hora do cancelamento do pedido";
        }, {
            readonly fieldId: "cancellationReason";
            readonly type: "text";
            readonly required: false;
            readonly description: "Motivo do cancelamento, quando aplicável";
        }];
        readonly statusEnum: readonly ["draft", "sentToKitchen", "inPreparation", "ready", "delivered", "closed", "cancelled"];
        readonly lifecycleStates: readonly ["draft", "sentToKitchen", "inPreparation", "ready", "delivered", "closed", "cancelled"];
        readonly ontologyEntities: readonly ["Order", "DailyShift", "DiningTable", "MenuItem", "MenuCategory"];
        readonly sourceTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "dining_table";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "today_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "shift_summary_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "menu_category";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "order";
            readonly tableName: "order";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/order.defs.ts";
        }, {
            readonly kind: "unknown";
            readonly tableName: "order_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "dailyShift";
            readonly tableName: "daily_shift";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/dailyShift.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "diningTable";
            readonly tableName: "dining_table";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/diningTable.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "todaySalesMetrics";
            readonly tableName: "today_sales_metrics";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/todaySalesMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "topSellingItemsMetrics";
            readonly tableName: "top_selling_items_metrics";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "shiftSummaryMetrics";
            readonly tableName: "shift_summary_metrics";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/shiftSummaryMetrics.defs.ts";
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "MenuItem";
            readonly domainId: "menuItem";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Cada item deve pertencer a uma categoria ativa", "Status permitido: active ou inactive", "Preço deve ser maior ou igual a zero", "Nome do item deve ser único por categoria dentro do tenant", "Alterações de preço não afetam pedidos já fechados (snapshot no OrderItem)"];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "MenuCategory";
            readonly domainId: "menuItem";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Cada item deve pertencer a uma categoria ativa", "Status permitido: active ou inactive", "Preço deve ser maior ou igual a zero", "Nome do item deve ser único por categoria dentro do tenant", "Alterações de preço não afetam pedidos já fechados (snapshot no OrderItem)"];
        }];
        readonly allowedOperations: readonly ["createDraftOrderWithItems", "updateOrderItems", "sendToKitchen", "transitionKitchenStatus", "markDelivered", "closeAsSale", "cancelOrder", "getOrderById", "listOrdersByStatus", "listKitchenQueue", "listOrdersForShift", "listDiningTables", "getShiftOpenIfAny"];
        readonly rulesApplied: readonly ["orderTypeMustBeTableOrTakeout", "orderStatusTransitionsControlled", "shiftMustBeOpenToCreateOrders", "menuPriceIsSnapshottedOnOrderItem", "metricsDerivedFromClosedOrders"];
        readonly usecaseRefs: readonly ["createOrderDraft", "addOrUpdateOrderItems", "sendOrderToKitchen", "updateKitchenOrderStatus", "markOrderDelivered", "closeOrderAsSaleAndDeductInventory", "cancelOrder", "getOrderById", "listOrdersByStatus", "listKitchenQueue", "listDiningTables", "openDailyShift", "closeDailyShiftAndGenerateReport", "getShiftCloseReport", "getTodayDashboardMetrics", "upsertMenuItemAndRecipe", "listMenuItems", "getMenuItemWithRecipe", "requestAiSalesSummary", "requestAiPromoSuggestions"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/OrderEntity.ts";
            readonly className: "OrderEntity";
            readonly contractName: "IOrderEntity";
        };
    };
    export default entity;
}
declare module "_102048_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102048_/l2/cafeFlow/module.defs" {
    export const initial: {
        readonly moduleName: "cafeFlow";
        readonly requestKind: "module_solution";
        readonly userLanguage: "pt-BR";
        readonly userPrompt: "Gere um app profissional chamado CafeFlow para cafeterias e lanchonetes pequenas.\nEntidades principais: Item do Cardápio (categoria, preço, ingredientes em estoque), Pedido (mesa ou takeout, itens, status), Turno Diário, Item de Estoque.\nTelas chave: Dashboard (vendas de hoje, itens mais vendidos, estoque baixo), Interface rápida de POS (lançamento de pedido + status cozinha), Gerenciamento de cardápio e estoque, Relatório de fechamento de turno.\nFuncionalidade LLM: Assistente IA que gera \"resumo de vendas do dia\" ou sugere \"quais itens promover com base nos últimos 7 dias\".\nFoco: Atendimento rápido de pedidos, coordenação de cozinha e controle simples de estoque para food service.\nlinguagem: en, pt-br";
        readonly createdAt: "2026-06-25T12:13:48.693Z";
    };
}
