declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/adjustStockLevel.defs" {
    export const adjustStockLevelController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "adjustStockLevel";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "adjustStockLevel";
            readonly controllerName: "AdjustStockLevelController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowAdjustStockLevelHandler";
                readonly command: "adjustStockLevel";
                readonly usecaseRef: "adjustStockLevel";
                readonly inputTypeName: "AdjustStockLevelInput";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.adjustStockLevel.adjustStockLevel";
                readonly handlerName: "cafeFlowAdjustStockLevelHandler";
            }];
        };
    };
    export default adjustStockLevelController;
    export const pipeline: readonly [{
        readonly id: "adjustStockLevel__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/adjustStockLevel.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/adjustStockLevel.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/usecases/adjustStockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_3_domain/entities/stockLevel" {
    export type StockLevelStatus = 'sufficient' | 'low' | 'depleted';
    export interface StockLevel {
        stockLevelId: string;
        stockItemId: string;
        currentQuantity: number;
        minQuantity: number;
        status: StockLevelStatus;
        createdAt: string;
        updatedAt: string;
    }
    /**
     * Derives the operational status from the current and minimum quantities.
     *
     * - currentQuantity === 0 → 'depleted'
     * - currentQuantity > 0 && currentQuantity < minQuantity → 'low'
     * - currentQuantity >= minQuantity → 'sufficient'
     */
    export function deriveStockLevelStatus(currentQuantity: number, minQuantity: number): StockLevelStatus;
    /** currentQuantity must be >= 0 */
    export function stockLevelCurrentQuantityIsValid(stockLevel: Pick<StockLevel, 'currentQuantity'>): boolean;
    /** minQuantity must be >= 0 */
    export function stockLevelMinQuantityIsValid(stockLevel: Pick<StockLevel, 'minQuantity'>): boolean;
    /** stockItemId must not be null */
    export function stockLevelHasStockItem(stockLevel: Pick<StockLevel, 'stockItemId'>): boolean;
    /** Status must be consistent with the quantity rules. */
    export function stockLevelStatusIsConsistent(stockLevel: Pick<StockLevel, 'currentQuantity' | 'minQuantity' | 'status'>): boolean;
    /** Evaluates all invariants and returns true only when every rule holds. */
    export function stockLevelInvariantsHold(stockLevel: StockLevel): boolean;
}
declare module "_102048_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository" {
    import type { StockLevel, StockLevelStatus } from "_102048_/l1/cafeFlow/layer_3_domain/entities/stockLevel";
    export type StockLevelId = string;
    export type ProductId = string;
    export type Quantity = number;
    export interface StockLevelFilter {
        stockItemId?: string;
        status?: StockLevelStatus;
    }
    export interface IStockLevelRepository {
        getById(id: StockLevelId): Promise<StockLevel | null>;
        list(filter: StockLevelFilter): Promise<StockLevel[]>;
        save(aggregate: StockLevel): Promise<void>;
        findByProductId(productId: ProductId): Promise<StockLevel | null>;
        listLowStock(threshold: Quantity): Promise<StockLevel[]>;
    }
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/adjustStockLevel" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { StockLevelStatus } from "_102048_/l1/cafeFlow/layer_3_domain/entities/stockLevel";
    export interface AdjustStockLevelInput {
        stockLevelId: string;
        currentQuantity: number;
        minQuantity?: number;
    }
    export interface AdjustStockLevelOutput {
        stockLevelId: string;
        stockItemId: string;
        currentQuantity: number;
        minQuantity: number;
        status: StockLevelStatus;
        updatedAt: string;
    }
    export function adjustStockLevel(ctx: RequestContext, input: AdjustStockLevelInput): Promise<AdjustStockLevelOutput>;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/adjustStockLevel" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowAdjustStockLevelHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createMenuItem.defs" {
    export const createMenuItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createMenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createMenuItem";
            readonly controllerName: "CreateMenuItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateMenuItemHandler";
                readonly command: "createMenuItem";
                readonly usecaseRef: "createMenuItem";
                readonly inputTypeName: "CreateMenuItemInput";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.createMenuItem.createMenuItem";
                readonly handlerName: "cafeFlowCreateMenuItemHandler";
            }];
        };
    };
    export default createMenuItemController;
    export const pipeline: readonly [{
        readonly id: "createMenuItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createMenuItem.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createMenuItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/usecases/createMenuItem.d.ts", "_102048_/l2/cafeFlow/web/contracts/createMenuItem.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/createMenuItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateMenuItemInput {
        name: string;
        category: string;
        price: number;
        stockItemId?: string;
        status: string;
    }
    export interface CreateMenuItemOutput {
        menuItemId: string;
        status: string;
    }
    export function createMenuItem(ctx: RequestContext, input: CreateMenuItemInput): Promise<CreateMenuItemOutput>;
}
declare module "_102048_/l2/cafeFlow/web/contracts/createMenuItem" {
    export interface CafeFlowCreateMenuItemInput {
        name: string;
        category: string;
        price: number;
        status: "active" | "inactive";
    }
    export interface CafeFlowCreateMenuItemOutput {
        menuItemId: string;
    }
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createMenuItem" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowCreateMenuItemHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockItem.defs" {
    export const createStockItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createStockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createStockItem";
            readonly controllerName: "CreateStockItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateStockItemHandler";
                readonly command: "createStockItem";
                readonly usecaseRef: "createStockItem";
                readonly inputTypeName: "CreateStockItemInput";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.createStockItem.createStockItem";
                readonly handlerName: "cafeFlowCreateStockItemHandler";
            }];
        };
    };
    export default createStockItemController;
    export const pipeline: readonly [{
        readonly id: "createStockItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockItem.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/usecases/createStockItem.d.ts", "_102048_/l2/cafeFlow/web/contracts/createStockItem.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/createStockItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateStockItemInput {
        name: string;
        unitOfMeasure: string;
        minimumStockLevel: number;
        status: string;
    }
    export interface CreateStockItemOutput {
        stockItemId: string;
        status: string;
    }
    export function createStockItem(ctx: RequestContext, input: CreateStockItemInput): Promise<CreateStockItemOutput>;
}
declare module "_102048_/l2/cafeFlow/web/contracts/createStockItem" {
    export interface CafeFlowCreateStockItemInput {
        name: string;
        unitOfMeasure: string;
        minimumStockLevel: number;
        status: "active" | "inactive";
    }
    export interface CafeFlowCreateStockItemOutput {
        stockItemId: string;
    }
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockItem" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowCreateStockItemHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createTable.defs" {
    export const createTableController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createTable";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createTable";
            readonly controllerName: "CreateTableController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateTableHandler";
                readonly command: "createTable";
                readonly usecaseRef: "createTable";
                readonly inputTypeName: "CreateTableInput";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.createTable.createTable";
                readonly handlerName: "cafeFlowCreateTableHandler";
            }];
        };
    };
    export default createTableController;
    export const pipeline: readonly [{
        readonly id: "createTable__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createTable.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createTable.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/usecases/createTable.d.ts", "_102048_/l2/cafeFlow/web/contracts/createTable.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/createTable" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateTableInput {
        tableNumber: string;
        capacity?: number;
        status: string;
    }
    export interface CreateTableOutput {
        tableId: string;
        status: string;
    }
    export function createTable(ctx: RequestContext, input: CreateTableInput): Promise<CreateTableOutput>;
}
declare module "_102048_/l2/cafeFlow/web/contracts/createTable" {
    export interface CafeFlowCreateTableInput {
        tableNumber: string;
        capacity?: number;
        status: "active" | "inactive";
    }
    export interface CafeFlowCreateTableOutput {
        tableId: string;
    }
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createTable" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowCreateTableHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteMenuItem.defs" {
    export const deleteMenuItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "deleteMenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "deleteMenuItem";
            readonly controllerName: "DeleteMenuItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowDeleteMenuItemHandler";
                readonly command: "deleteMenuItem";
                readonly usecaseRef: "deleteMenuItem";
                readonly inputTypeName: "DeleteMenuItemInput";
                readonly kind: "delete";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.deleteMenuItem.deleteMenuItem";
                readonly handlerName: "cafeFlowDeleteMenuItemHandler";
            }];
        };
    };
    export default deleteMenuItemController;
    export const pipeline: readonly [{
        readonly id: "deleteMenuItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteMenuItem.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteMenuItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/usecases/deleteMenuItem.d.ts", "_102048_/l2/cafeFlow/web/contracts/deleteMenuItem.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_3_domain/entities/orderItem" {
    export interface OrderItem {
        orderItemId: string;
        orderId: string;
        menuItemId: string;
        quantity: number;
        unitPrice: number;
        observations: string | null;
        createdAt: string;
        updatedAt: string;
    }
    /** Invariant: quantity must be > 0 */
    export function orderItemQuantityIsValid(quantity: number): boolean;
    /** Invariant: unitPrice must be >= 0 */
    export function orderItemUnitPriceIsValid(unitPrice: number): boolean;
    /** Invariant: orderId and menuItemId must not be null */
    export function orderItemReferencesAreValid(item: Pick<OrderItem, 'orderId' | 'menuItemId'>): boolean;
    /** Combined invariant check for an order item. */
    export function orderItemIsValid(item: Pick<OrderItem, 'orderId' | 'menuItemId' | 'quantity' | 'unitPrice'>): boolean;
    /** Computed total price for an order item (quantity × unitPrice). */
    export function orderItemTotalPrice(item: Pick<OrderItem, 'quantity' | 'unitPrice'>): number;
}
declare module "_102048_/l1/cafeFlow/layer_2_application/ports/orderItemRepository" {
    import type { OrderItem } from "_102048_/l1/cafeFlow/layer_3_domain/entities/orderItem";
    export type OrderItemId = string;
    export type OrderId = string;
    export type ProductId = string;
    export interface OrderItemFilter {
        orderId?: string;
        menuItemId?: string;
    }
    export interface IOrderItemRepository {
        getById(id: OrderItemId): Promise<OrderItem | null>;
        list(filter: OrderItemFilter): Promise<OrderItem[]>;
        save(aggregate: OrderItem): Promise<void>;
        listByOrderId(orderId: OrderId): Promise<OrderItem[]>;
        listByProductId(productId: ProductId): Promise<OrderItem[]>;
    }
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/deleteMenuItem" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface DeleteMenuItemInput {
        menuItemId: string;
    }
    export interface DeleteMenuItemOutput {
        menuItemId: string;
        status: string;
        reason?: string;
    }
    export function deleteMenuItem(ctx: RequestContext, input: DeleteMenuItemInput): Promise<DeleteMenuItemOutput>;
}
declare module "_102048_/l2/cafeFlow/web/contracts/deleteMenuItem" {
    export interface CafeFlowDeleteMenuItemInput {
        menuItemId?: string;
        name: string;
        category: string;
        price: number;
        stockItemId?: string;
        status: "active" | "inactive";
    }
    export interface CafeFlowDeleteMenuItemOutput {
        menuItemId: string;
    }
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteMenuItem" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowDeleteMenuItemHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteStockItem.defs" {
    export const deleteStockItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "deleteStockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "deleteStockItem";
            readonly controllerName: "DeleteStockItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowDeleteStockItemHandler";
                readonly command: "deleteStockItem";
                readonly usecaseRef: "deleteStockItem";
                readonly inputTypeName: "DeleteStockItemInput";
                readonly kind: "delete";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.deleteStockItem.deleteStockItem";
                readonly handlerName: "cafeFlowDeleteStockItemHandler";
            }];
        };
    };
    export default deleteStockItemController;
    export const pipeline: readonly [{
        readonly id: "deleteStockItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteStockItem.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteStockItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/usecases/deleteStockItem.d.ts", "_102048_/l2/cafeFlow/web/contracts/deleteStockItem.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/deleteStockItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface DeleteStockItemInput {
        stockItemId: string;
    }
    export interface DeleteStockItemOutput {
        stockItemId: string;
        status: string;
    }
    export function deleteStockItem(ctx: RequestContext, input: DeleteStockItemInput): Promise<DeleteStockItemOutput>;
}
declare module "_102048_/l2/cafeFlow/web/contracts/deleteStockItem" {
    export interface CafeFlowDeleteStockItemInput {
        stockItemId?: string;
        name: string;
        unitOfMeasure: string;
        minimumStockLevel: number;
        status: "active" | "inactive";
    }
    export interface CafeFlowDeleteStockItemOutput {
        stockItemId: string;
    }
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteStockItem" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowDeleteStockItemHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteTable.defs" {
    export const deleteTableController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "deleteTable";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "deleteTable";
            readonly controllerName: "DeleteTableController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowDeleteTableHandler";
                readonly command: "deleteTable";
                readonly usecaseRef: "deleteTable";
                readonly inputTypeName: "DeleteTableInput";
                readonly kind: "delete";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.deleteTable.deleteTable";
                readonly handlerName: "cafeFlowDeleteTableHandler";
            }];
        };
    };
    export default deleteTableController;
    export const pipeline: readonly [{
        readonly id: "deleteTable__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteTable.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteTable.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/usecases/deleteTable.d.ts", "_102048_/l2/cafeFlow/web/contracts/deleteTable.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/deleteTable" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface DeleteTableInput {
        tableId: string;
    }
    export interface DeleteTableOutput {
        tableId: string;
        deleted: boolean;
    }
    export function deleteTable(ctx: RequestContext, input: DeleteTableInput): Promise<DeleteTableOutput>;
}
declare module "_102048_/l2/cafeFlow/web/contracts/deleteTable" {
    export interface CafeFlowDeleteTableInput {
        tableId?: string;
        tableNumber: string;
        capacity?: number;
        status: "active" | "inactive";
    }
    export interface CafeFlowDeleteTableOutput {
        tableId: string;
    }
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteTable" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowDeleteTableHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/launchOrder.defs" {
    export const launchOrderController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "launchOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "LaunchOrderController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowLaunchOrderHandler";
                readonly command: "launchOrder";
                readonly usecaseRef: "launchOrder";
                readonly inputTypeName: "LaunchOrderInput";
                readonly kind: "create";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.launchOrder";
                readonly handlerName: "cafeFlowLaunchOrderHandler";
            }];
        };
    };
    export default launchOrderController;
    export const pipeline: readonly [{
        readonly id: "launchOrder__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/launchOrder.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/launchOrder.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/usecases/launchOrder.d.ts", "_102048_/l2/cafeFlow/web/contracts/orderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_3_domain/entities/order" {
    export type OrderType = 'dineIn' | 'takeout';
    export type OrderStatus = 'pending' | 'sent_to_kitchen' | 'preparing' | 'ready' | 'delivered' | 'paid' | 'cancelled';
    export interface Order {
        orderId: string;
        type: OrderType;
        status: OrderStatus;
        total: number;
        tableId: string | null;
        dailyShiftId: string;
        createdAt: string;
        updatedAt: string;
    }
    export const ORDER_STATUS_TRANSITIONS: Record<OrderStatus, OrderStatus[]>;
    export function canTransitionOrder(from: OrderStatus, to: OrderStatus): boolean;
    export function orderTotalIsNonNegative(order: Pick<Order, 'total'>): boolean;
    export function orderTableConsistency(order: Pick<Order, 'type' | 'tableId'>): boolean;
    export function orderHasDailyShift(order: Pick<Order, 'dailyShiftId'>): boolean;
    export function validateOrderInvariants(order: Pick<Order, 'total' | 'type' | 'tableId' | 'dailyShiftId'>): string[];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/ports/orderRepository" {
    import type { Order, OrderStatus, OrderType } from "_102048_/l1/cafeFlow/layer_3_domain/entities/order";
    export type OrderId = string;
    export type CustomerId = string;
    export type Instant = string;
    export interface OrderFilter {
        dailyShiftId?: string;
        status?: OrderStatus;
        type?: OrderType;
        tableId?: string | null;
        customerId?: CustomerId;
    }
    export interface IOrderRepository {
        getById(id: OrderId): Promise<Order | null>;
        list(filter: OrderFilter): Promise<Order[]>;
        save(aggregate: Order): Promise<void>;
        listByStatus(status: OrderStatus): Promise<Order[]>;
        listByCustomerId(customerId: CustomerId): Promise<Order[]>;
        listByPeriod(start: Instant, end: Instant): Promise<Order[]>;
    }
}
declare module "_102048_/l1/cafeFlow/layer_3_domain/entities/dailyShift" {
    export type DailyShiftStatus = 'open' | 'closed';
    export interface DailyShift {
        dailyShiftId: string;
        date: string;
        openTime: string;
        closeTime: string | null;
        status: DailyShiftStatus;
        totalSales: number;
        createdAt: string;
        updatedAt: string;
    }
    export const DAILY_SHIFT_STATUS_TRANSITIONS: Record<DailyShiftStatus, DailyShiftStatus[]>;
    export function canTransitionDailyShift(from: DailyShiftStatus, to: DailyShiftStatus): boolean;
    export function dailyShiftTotalSalesIsValid(totalSales: number): boolean;
    export function dailyShiftOpenTimeIsValid(openTime: string, nowIso: string): boolean;
    export function dailyShiftStatusConsistent(status: DailyShiftStatus, openTime: string, closeTime: string | null): boolean;
    export function dailyShiftInvariantsHold(shift: Pick<DailyShift, 'totalSales' | 'status' | 'openTime' | 'closeTime'>, nowIso: string): boolean;
}
declare module "_102048_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository" {
    import type { DailyShift, DailyShiftStatus } from "_102048_/l1/cafeFlow/layer_3_domain/entities/dailyShift";
    export type DailyShiftId = string;
    export type LocalDate = string;
    export interface DailyShiftFilter {
        date?: LocalDate;
        status?: DailyShiftStatus;
    }
    export interface IDailyShiftRepository {
        getById(id: DailyShiftId): Promise<DailyShift | null>;
        list(filter: DailyShiftFilter): Promise<DailyShift[]>;
        save(aggregate: DailyShift): Promise<void>;
        findByDate(date: LocalDate): Promise<DailyShift | null>;
        listByDateRange(start: LocalDate, end: LocalDate): Promise<DailyShift[]>;
    }
}
declare module "_102048_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent" {
    export type OrderStatus = 'pending' | 'sent_to_kitchen' | 'preparing' | 'ready' | 'delivered' | 'paid' | 'cancelled';
    export interface OrderStatusEvent {
        orderStatusEventId: string;
        orderId: string;
        previousStatus: OrderStatus | null;
        status: OrderStatus;
        createdAt: string;
        updatedAt: string;
    }
}
declare module "_102048_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository" {
    import type { OrderStatusEvent } from "_102048_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent";
    /**
     * Append-only event port for OrderStatusEvent.
     * Events are immutable once recorded — no save/update/delete.
     */
    export interface IOrderStatusEventRepository {
        /** Record a new status-change event. The event is immutable after append. */
        append(record: OrderStatusEvent): Promise<void>;
        /** List all status events for a given order. */
        listByOwnerId(ownerId: string): Promise<OrderStatusEvent[]>;
        /** List status events within a time range (ISO-8601 instants). */
        listByPeriod(start: string, end: string): Promise<OrderStatusEvent[]>;
    }
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/launchOrder" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface LaunchOrderItemInput {
        menuItemId: string;
        quantity: number;
        observations?: string;
    }
    export interface LaunchOrderInput {
        type: string;
        tableId?: string;
        dailyShiftId: string;
        items: LaunchOrderItemInput[];
    }
    export interface LaunchOrderOutput {
        orderId: string;
        status: string;
        total: number;
    }
    export function launchOrder(ctx: RequestContext, input: LaunchOrderInput): Promise<LaunchOrderOutput>;
}
declare module "_102048_/l2/cafeFlow/web/contracts/orderLifecycle" {
    export interface CafeFlowLaunchOrderInput {
        type: "dineIn" | "takeout";
        status: "pending" | "sent_to_kitchen" | "preparing" | "ready" | "delivered" | "paid" | "cancelled";
        total: number;
    }
    export interface CafeFlowLaunchOrderOutput {
        orderId: string;
    }
    export interface CafeFlowUpdateOrderStatusInput {
        orderStatusEventId?: string;
        orderId?: string;
        previousStatus?: string;
        status: string;
    }
    export interface CafeFlowUpdateOrderStatusOutput {
        orderStatusEventId: string;
    }
    export interface CafeFlowProcessPaymentInput {
        status: "pending" | "sent_to_kitchen" | "preparing" | "ready" | "delivered" | "paid" | "cancelled";
    }
    export interface CafeFlowProcessPaymentOutput {
        orderId: string;
    }
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/launchOrder" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowLaunchOrderHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/processPayment.defs" {
    export const processPaymentController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "processPayment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "ProcessPaymentController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowProcessPaymentHandler";
                readonly command: "processPayment";
                readonly usecaseRef: "processPayment";
                readonly inputTypeName: "ProcessPaymentInput";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.processPayment";
                readonly handlerName: "cafeFlowProcessPaymentHandler";
            }];
        };
    };
    export default processPaymentController;
    export const pipeline: readonly [{
        readonly id: "processPayment__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/processPayment.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/processPayment.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/usecases/processPayment.d.ts", "_102048_/l2/cafeFlow/web/contracts/orderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/processPayment" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ProcessPaymentInput {
        orderId: string;
        amountPaid: number;
        paymentMethod?: string;
    }
    export interface ProcessPaymentOutput {
        orderId: string;
        status: string;
        total: number;
    }
    export function processPayment(ctx: RequestContext, input: ProcessPaymentInput): Promise<ProcessPaymentOutput>;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/processPayment" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowProcessPaymentHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryMenuItem.defs" {
    export const queryMenuItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "queryMenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "queryMenuItem";
            readonly controllerName: "QueryMenuItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowQueryMenuItemHandler";
                readonly command: "queryMenuItem";
                readonly usecaseRef: "queryMenuItem";
                readonly inputTypeName: "QueryMenuItemInput";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.queryMenuItem.queryMenuItem";
                readonly handlerName: "cafeFlowQueryMenuItemHandler";
            }];
        };
    };
    export default queryMenuItemController;
    export const pipeline: readonly [{
        readonly id: "queryMenuItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryMenuItem.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryMenuItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/usecases/queryMenuItem.d.ts", "_102048_/l2/cafeFlow/web/contracts/queryMenuItem.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/queryMenuItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface QueryMenuItemInput {
        menuItemId: string;
        includeStockDetails?: boolean;
    }
    export interface QueryMenuItemOutput {
        menuItemId: string;
        name: string;
        category: string;
        price: number;
        stockItemId?: string;
        status: string;
        createdAt: string;
        updatedAt: string;
        stockItemName?: string;
        stockItemUnitOfMeasure?: string;
        stockItemMinimumStockLevel?: number;
        stockItemStatus?: string;
    }
    export function queryMenuItem(ctx: RequestContext, input: QueryMenuItemInput): Promise<QueryMenuItemOutput>;
}
declare module "_102048_/l2/cafeFlow/web/contracts/queryMenuItem" {
    export interface CafeFlowQueryMenuItemInput {
        menuItemId?: string;
        name?: string;
        category?: string;
        stockItemId?: string;
        status?: "active" | "inactive";
        createdAt?: string;
    }
    export interface CafeFlowQueryMenuItemOutputItem {
        menuItemId: string;
        name: string;
        category: string;
        price: number;
        stockItemId: string;
        status: "active" | "inactive";
        createdAt: string;
        updatedAt: string;
    }
    export type CafeFlowQueryMenuItemOutput = CafeFlowQueryMenuItemOutputItem[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryMenuItem" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowQueryMenuItemHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryStockItem.defs" {
    export const queryStockItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "queryStockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "queryStockItem";
            readonly controllerName: "QueryStockItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowQueryStockItemHandler";
                readonly command: "queryStockItem";
                readonly usecaseRef: "queryStockItem";
                readonly inputTypeName: "QueryStockItemInput";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.queryStockItem.queryStockItem";
                readonly handlerName: "cafeFlowQueryStockItemHandler";
            }];
        };
    };
    export default queryStockItemController;
    export const pipeline: readonly [{
        readonly id: "queryStockItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryStockItem.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryStockItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/usecases/queryStockItem.d.ts", "_102048_/l2/cafeFlow/web/contracts/queryStockItem.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/queryStockItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface QueryStockItemInput {
        stockItemId?: string;
        name?: string;
        status?: string;
    }
    export interface QueryStockItemOutput {
        stockItemId: string;
        name: string;
        unitOfMeasure: string;
        minimumStockLevel: number;
        status: string;
        createdAt: string;
        updatedAt: string;
        lowStockAlert: boolean;
    }
    export function queryStockItem(ctx: RequestContext, input: QueryStockItemInput): Promise<QueryStockItemOutput[]>;
}
declare module "_102048_/l2/cafeFlow/web/contracts/queryStockItem" {
    export interface CafeFlowQueryStockItemInput {
        stockItemId?: string;
        name?: string;
        status?: "active" | "inactive";
        createdAt?: string;
        updatedAt?: string;
    }
    export interface CafeFlowQueryStockItemOutputItem {
        stockItemId: string;
        name: string;
        unitOfMeasure: string;
        minimumStockLevel: number;
        status: "active" | "inactive";
        createdAt: string;
        updatedAt: string;
    }
    export type CafeFlowQueryStockItemOutput = CafeFlowQueryStockItemOutputItem[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryStockItem" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowQueryStockItemHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryTable.defs" {
    export const queryTableController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "queryTable";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "queryTable";
            readonly controllerName: "QueryTableController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowQueryTableByIdHandler";
                readonly command: "queryTableById";
                readonly usecaseRef: "queryTableById";
                readonly inputTypeName: "QueryTableByIdInput";
                readonly kind: "query";
            }, {
                readonly handlerName: "cafeFlowQueryTablesHandler";
                readonly command: "queryTables";
                readonly usecaseRef: "queryTables";
                readonly inputTypeName: "QueryTablesInput";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.queryTable.queryTableById";
                readonly handlerName: "cafeFlowQueryTableByIdHandler";
            }, {
                readonly key: "cafeFlow.queryTable.queryTables";
                readonly handlerName: "cafeFlowQueryTablesHandler";
            }];
        };
    };
    export default queryTableController;
    export const pipeline: readonly [{
        readonly id: "queryTable__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryTable.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryTable.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/usecases/queryTable.d.ts", "_102048_/l2/cafeFlow/web/contracts/queryTable.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/queryTable" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface QueryTableByIdInput {
        tableId: string;
    }
    export interface TableView {
        tableId: string;
        tableNumber: string;
        capacity?: number;
        status: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface QueryTablesInput {
        tableNumber?: string;
        status?: string;
    }
    export interface TableViewList {
        items: TableView[];
        total: number;
    }
    /**
     * Retrieve a single Table by its MDM id.
     * Returns `null` when the record does not exist (no AppError — the caller
     * decides whether a missing table is an error).
     */
    export function queryTableById(ctx: RequestContext, input: QueryTableByIdInput): Promise<TableView | null>;
    /**
     * List Table master-data records with optional filters.
     * Tables are MDM entities with subtype `AssetGeneric`; we resolve them
     * through the shared MDM entity index, then fetch the full documents.
     */
    export function queryTables(ctx: RequestContext, input: QueryTablesInput): Promise<TableViewList>;
}
declare module "_102048_/l2/cafeFlow/web/contracts/queryTable" {
    export interface CafeFlowQueryTableInput {
        tableId?: string;
        status?: "active" | "inactive";
        createdAt?: string;
        updatedAt?: string;
    }
    export interface CafeFlowQueryTableOutputItem {
        tableId: string;
        tableNumber: string;
        capacity: number;
        status: "active" | "inactive";
        createdAt: string;
        updatedAt: string;
    }
    export type CafeFlowQueryTableOutput = CafeFlowQueryTableOutputItem[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryTable" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowQueryTableByIdHandler: BffHandler;
    export const cafeFlowQueryTablesHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateMenuItem.defs" {
    export const updateMenuItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateMenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateMenuItem";
            readonly controllerName: "UpdateMenuItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateMenuItemHandler";
                readonly command: "updateMenuItem";
                readonly usecaseRef: "updateMenuItem";
                readonly inputTypeName: "UpdateMenuItemInput";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.updateMenuItem.updateMenuItem";
                readonly handlerName: "cafeFlowUpdateMenuItemHandler";
            }];
        };
    };
    export default updateMenuItemController;
    export const pipeline: readonly [{
        readonly id: "updateMenuItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateMenuItem.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateMenuItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/usecases/updateMenuItem.d.ts", "_102048_/l2/cafeFlow/web/contracts/updateMenuItem.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/updateMenuItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateMenuItemInput {
        menuItemId: string;
        name?: string;
        category?: string;
        price?: number;
        stockItemId?: string | null;
        status?: string;
    }
    export interface UpdateMenuItemOutput {
        menuItemId: string;
        name: string;
        category: string;
        price: number;
        stockItemId?: string;
        status: string;
        updatedAt: string;
    }
    export function updateMenuItem(ctx: RequestContext, input: UpdateMenuItemInput): Promise<UpdateMenuItemOutput>;
}
declare module "_102048_/l2/cafeFlow/web/contracts/updateMenuItem" {
    export interface CafeFlowUpdateMenuItemInput {
        name: string;
        price: number;
        stockItemId?: string;
        status: "active" | "inactive";
    }
    export interface CafeFlowUpdateMenuItemOutput {
        menuItemId: string;
    }
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateMenuItem" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowUpdateMenuItemHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.defs" {
    export const updateOrderStatusController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateOrderStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "UpdateOrderStatusController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateOrderStatusHandler";
                readonly command: "updateOrderStatus";
                readonly usecaseRef: "updateOrderStatus";
                readonly inputTypeName: "UpdateOrderStatusInput";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.updateOrderStatus";
                readonly handlerName: "cafeFlowUpdateOrderStatusHandler";
            }];
        };
    };
    export default updateOrderStatusController;
    export const pipeline: readonly [{
        readonly id: "updateOrderStatus__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.d.ts", "_102048_/l2/cafeFlow/web/contracts/orderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateOrderStatusInput {
        orderId: string;
        status: string;
    }
    export interface UpdateOrderStatusOutput {
        orderId: string;
        previousStatus?: string;
        status: string;
        orderStatusEventId: string;
        updatedAt: string;
    }
    export function updateOrderStatus(ctx: RequestContext, input: UpdateOrderStatusInput): Promise<UpdateOrderStatusOutput>;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowUpdateOrderStatusHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateStockItem.defs" {
    export const updateStockItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateStockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateStockItem";
            readonly controllerName: "UpdateStockItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateStockItemHandler";
                readonly command: "updateStockItem";
                readonly usecaseRef: "updateStockItem";
                readonly inputTypeName: "UpdateStockItemInput";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.updateStockItem.updateStockItem";
                readonly handlerName: "cafeFlowUpdateStockItemHandler";
            }];
        };
    };
    export default updateStockItemController;
    export const pipeline: readonly [{
        readonly id: "updateStockItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateStockItem.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateStockItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/usecases/updateStockItem.d.ts", "_102048_/l2/cafeFlow/web/contracts/updateStockItem.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/updateStockItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateStockItemInput {
        stockItemId: string;
        name: string;
        unitOfMeasure: string;
        minimumStockLevel: number;
        status: string;
    }
    export interface UpdateStockItemOutput {
        stockItemId: string;
        name: string;
        unitOfMeasure: string;
        minimumStockLevel: number;
        status: string;
        updatedAt: string;
    }
    export function updateStockItem(ctx: RequestContext, input: UpdateStockItemInput): Promise<UpdateStockItemOutput>;
}
declare module "_102048_/l2/cafeFlow/web/contracts/updateStockItem" {
    export interface CafeFlowUpdateStockItemInput {
        name: string;
        unitOfMeasure: string;
        minimumStockLevel: number;
        status: "active" | "inactive";
    }
    export interface CafeFlowUpdateStockItemOutput {
        stockItemId: string;
    }
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateStockItem" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowUpdateStockItemHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateTable.defs" {
    export const updateTableController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateTable";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateTable";
            readonly controllerName: "UpdateTableController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateTableHandler";
                readonly command: "updateTable";
                readonly usecaseRef: "updateTable";
                readonly inputTypeName: "UpdateTableInput";
                readonly kind: "update";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.updateTable.updateTable";
                readonly handlerName: "cafeFlowUpdateTableHandler";
            }];
        };
    };
    export default updateTableController;
    export const pipeline: readonly [{
        readonly id: "updateTable__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateTable.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateTable.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/usecases/updateTable.d.ts", "_102048_/l2/cafeFlow/web/contracts/updateTable.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/updateTable" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateTableInput {
        tableId: string;
        tableNumber: string;
        capacity?: number;
        status: string;
    }
    export interface UpdateTableOutput {
        tableId: string;
        status: string;
        updatedAt: string;
    }
    export function updateTable(ctx: RequestContext, input: UpdateTableInput): Promise<UpdateTableOutput>;
}
declare module "_102048_/l2/cafeFlow/web/contracts/updateTable" {
    export interface CafeFlowUpdateTableInput {
        tableNumber: string;
        capacity?: number;
        status: "active" | "inactive";
    }
    export interface CafeFlowUpdateTableOutput {
        tableId: string;
    }
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateTable" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowUpdateTableHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewDashboard.defs" {
    export const viewDashboardController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "shiftLifecycle";
            readonly controllerName: "ViewDashboardController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowViewDashboardHandler";
                readonly command: "viewDashboard";
                readonly usecaseRef: "viewDashboard";
                readonly inputTypeName: "ViewDashboardInput";
                readonly kind: "query";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.shiftLifecycle.viewDashboard";
                readonly handlerName: "cafeFlowViewDashboardHandler";
            }];
        };
    };
    export default viewDashboardController;
    export const pipeline: readonly [{
        readonly id: "viewDashboard__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewDashboard.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/usecases/viewDashboard.d.ts", "_102048_/l2/cafeFlow/web/contracts/shiftLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/viewDashboard" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ViewDashboardInput {
        dailyShiftId: string;
    }
    export interface ViewDashboardOutput {
        dailyShiftId: string;
        date: string;
        status: string;
        openTime: string;
        closeTime?: string;
        totalSales: number;
        orderCount: number;
        pendingOrders: number;
        preparingOrders: number;
        readyOrders: number;
        deliveredOrders: number;
        paidOrders: number;
        cancelledOrders: number;
        dineInOrders: number;
        takeoutOrders: number;
        totalOrderItems: number;
        orders?: string;
    }
    export function viewDashboard(ctx: RequestContext, input: ViewDashboardInput): Promise<ViewDashboardOutput>;
}
declare module "_102048_/l2/cafeFlow/web/contracts/shiftLifecycle" {
    export interface CafeFlowViewDashboardInput {
        dailyShiftId?: string;
        date?: string;
        status?: "open" | "closed";
        createdAt?: string;
        updatedAt?: string;
    }
    export interface CafeFlowViewDashboardOutputItem {
        dailyShiftId: string;
        date: string;
        openTime: string;
        closeTime: string;
        status: "open" | "closed";
        totalSales: number;
        createdAt: string;
        updatedAt: string;
    }
    export type CafeFlowViewDashboardOutput = CafeFlowViewDashboardOutputItem[];
    export interface CafeFlowViewShiftReportInput {
        shiftCloseReportId?: string;
        dailyShiftId?: string;
        createdAt?: string;
        updatedAt?: string;
    }
    export interface CafeFlowViewShiftReportOutputItem {
        shiftCloseReportId: string;
        dailyShiftId: string;
        totalSales: number;
        totalOrders: number;
        bestSellingItems: string;
        stockConsumptionSummary: string;
        operationalMetrics: string;
        createdAt: string;
    }
    export type CafeFlowViewShiftReportOutput = CafeFlowViewShiftReportOutputItem[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewDashboard" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowViewDashboardHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewShiftReport.defs" {
    export const viewShiftReportController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewShiftReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "shiftLifecycle";
            readonly controllerName: "ViewShiftReportController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowViewShiftReportByIdHandler";
                readonly command: "viewShiftReportById";
                readonly usecaseRef: "viewShiftReportById";
                readonly inputTypeName: "ViewShiftReportByIdInput";
                readonly kind: "view";
            }, {
                readonly handlerName: "cafeFlowViewShiftReportByDailyShiftIdHandler";
                readonly command: "viewShiftReportByDailyShiftId";
                readonly usecaseRef: "viewShiftReportByDailyShiftId";
                readonly inputTypeName: "ViewShiftReportByDailyShiftIdInput";
                readonly kind: "view";
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.shiftLifecycle.viewShiftReportById";
                readonly handlerName: "cafeFlowViewShiftReportByIdHandler";
            }, {
                readonly key: "cafeFlow.shiftLifecycle.viewShiftReportByDailyShiftId";
                readonly handlerName: "cafeFlowViewShiftReportByDailyShiftIdHandler";
            }];
        };
    };
    export default viewShiftReportController;
    export const pipeline: readonly [{
        readonly id: "viewShiftReport__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewShiftReport.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewShiftReport.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/usecases/viewShiftReport.d.ts", "_102048_/l2/cafeFlow/web/contracts/shiftLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_3_domain/entities/shiftCloseReport" {
    export interface ShiftCloseReport {
        shiftCloseReportId: string;
        dailyShiftId: string;
        totalSales: number;
        totalOrders: number;
        bestSellingItems: string;
        stockConsumptionSummary: string;
        operationalMetrics: string;
        createdAt: string;
        updatedAt: string;
    }
    export function shiftCloseReportTotalSalesIsValid(report: Pick<ShiftCloseReport, 'totalSales'>): boolean;
    export function shiftCloseReportTotalOrdersIsValid(report: Pick<ShiftCloseReport, 'totalOrders'>): boolean;
    export function shiftCloseReportDailyShiftIdIsValid(report: Pick<ShiftCloseReport, 'dailyShiftId'>): boolean;
    export function canCreateShiftCloseReport(dailyShiftStatus: string): boolean;
    export function validateShiftCloseReport(report: ShiftCloseReport): string[];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/ports/shiftCloseReportRepository" {
    import type { ShiftCloseReport } from "_102048_/l1/cafeFlow/layer_3_domain/entities/shiftCloseReport";
    export type ShiftCloseReportId = string;
    export type DailyShiftId = string;
    export type LocalDate = string;
    export interface ShiftCloseReportFilter {
        shiftCloseReportId?: ShiftCloseReportId;
        dailyShiftId?: DailyShiftId;
    }
    export interface IShiftCloseReportRepository {
        getById(id: ShiftCloseReportId): Promise<ShiftCloseReport | null>;
        list(filter: ShiftCloseReportFilter): Promise<ShiftCloseReport[]>;
        save(aggregate: ShiftCloseReport): Promise<void>;
        findByShiftId(shiftId: DailyShiftId): Promise<ShiftCloseReport | null>;
        listByPeriod(start: LocalDate, end: LocalDate): Promise<ShiftCloseReport[]>;
    }
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/viewShiftReport" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ViewShiftReportByIdInput {
        shiftCloseReportId: string;
    }
    export interface ViewShiftReportByDailyShiftIdInput {
        dailyShiftId: string;
    }
    export interface ShiftReportView {
        shiftCloseReportId: string;
        dailyShiftId: string;
        totalSales: number;
        totalOrders: number;
        bestSellingItems: string;
        stockConsumptionSummary: string;
        operationalMetrics: string;
        createdAt: string;
        updatedAt: string;
        dailyShiftDate: string;
        dailyShiftOpenTime: string;
        dailyShiftCloseTime?: string;
        dailyShiftStatus: string;
        dailyShiftTotalSales: number;
    }
    export function viewShiftReportById(ctx: RequestContext, input: ViewShiftReportByIdInput): Promise<ShiftReportView>;
    export function viewShiftReportByDailyShiftId(ctx: RequestContext, input: ViewShiftReportByDailyShiftIdInput): Promise<ShiftReportView>;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewShiftReport" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowViewShiftReportByIdHandler: BffHandler;
    export const cafeFlowViewShiftReportByDailyShiftIdHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.defs" {
    export const dailyShiftTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "DailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "DailyShift";
            readonly tableName: "daily_shift";
            readonly columns: readonly [{
                readonly name: "daily_shift_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
                readonly description: "date, open_time, close_time, total_sales, updated_at";
            }];
            readonly primaryKey: readonly ["daily_shift_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_daily_shift_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_daily_shift_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default dailyShiftTableDefinition;
    export const pipeline: readonly [{
        readonly id: "dailyShift__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const dailyShiftTableDef: TableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.defs" {
    export const dailyShiftRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "DailyShiftRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "DailyShiftRepositoryAdapter";
            readonly entityId: "DailyShift";
            readonly portRef: "IDailyShiftRepository";
            readonly tableRef: "daily_shifts";
            readonly mdmReads: readonly [];
            readonly notes: readonly [];
        };
    };
    export default dailyShiftRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "dailyShiftRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShift.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/dailyShiftRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IDailyShiftRepository } from "_102048_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository";
    export function createDailyShiftRepositoryAdapter(ctx: RequestContext): IDailyShiftRepository;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Order";
            readonly tableName: "order";
            readonly columns: readonly [{
                readonly name: "order_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "type";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "table_id";
                readonly type: "uuid";
                readonly nullable: true;
                readonly description: "pk/fk";
            }, {
                readonly name: "daily_shift_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
                readonly description: "total, updated_at";
            }];
            readonly primaryKey: readonly ["order_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_order_type";
                readonly columns: readonly ["type"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_table_id";
                readonly columns: readonly ["table_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_daily_shift_id";
                readonly columns: readonly ["daily_shift_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default orderTableDefinition;
    export const pipeline: readonly [{
        readonly id: "order__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/order.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/order.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/order" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const orderTableDef: TableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderItem.defs" {
    export const orderItemTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "OrderItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "OrderItem";
            readonly tableName: "order_item";
            readonly columns: readonly [{
                readonly name: "order_item_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "order_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "menu_item_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
                readonly description: "quantity, unit_price, observations, updated_at";
            }];
            readonly primaryKey: readonly ["order_item_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_order_item_order_id";
                readonly columns: readonly ["order_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_item_menu_item_id";
                readonly columns: readonly ["menu_item_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_item_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default orderItemTableDefinition;
    export const pipeline: readonly [{
        readonly id: "orderItem__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderItem.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_3_domain/entities/orderItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderItem" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const orderItemTableDef: TableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderItemRepositoryAdapter.defs" {
    export const orderItemRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "OrderItemRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "OrderItemRepositoryAdapter";
            readonly entityId: "OrderItem";
            readonly portRef: "IOrderItemRepository";
            readonly tableRef: "order_items";
            readonly mdmReads: readonly ["MenuItem"];
            readonly notes: readonly [];
        };
    };
    export default orderItemRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "orderItemRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderItemRepositoryAdapter.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderItemRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/ports/orderItemRepository.d.ts", "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderItem.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/orderItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderItemRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IOrderItemRepository } from "_102048_/l1/cafeFlow/layer_2_application/ports/orderItemRepository";
    export function createOrderItemRepositoryAdapter(ctx: RequestContext): IOrderItemRepository;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs" {
    export const orderRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "OrderRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "OrderRepositoryAdapter";
            readonly entityId: "Order";
            readonly portRef: "IOrderRepository";
            readonly tableRef: "orders";
            readonly mdmReads: readonly ["Table"];
            readonly notes: readonly [];
        };
    };
    export default orderRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "orderRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/order.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IOrderRepository } from "_102048_/l1/cafeFlow/layer_2_application/ports/orderRepository";
    export function createOrderRepositoryAdapter(ctx: RequestContext): IOrderRepository;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderStatusEvent.defs" {
    export const orderStatusEventTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "OrderStatusEvent";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "OrderStatusEvent";
            readonly tableName: "order_status_event";
            readonly columns: readonly [{
                readonly name: "order_status_event_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "order_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
                readonly description: "previous_status, updated_at";
            }];
            readonly primaryKey: readonly ["order_status_event_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_order_status_event_order_id";
                readonly columns: readonly ["order_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_status_event_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_status_event_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
            readonly appendOnly: true;
            readonly purpose: "controle";
            readonly retentionDays: 90;
        };
    };
    export default orderStatusEventTableDefinition;
    export const pipeline: readonly [{
        readonly id: "orderStatusEvent__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderStatusEvent.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderStatusEvent.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderStatusEvent" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const orderStatusEventTableDef: TableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderStatusEventRepositoryAdapter.defs" {
    export const orderStatusEventRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "OrderStatusEventRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "OrderStatusEventRepositoryAdapter";
            readonly entityId: "OrderStatusEvent";
            readonly portRef: "IOrderStatusEventRepository";
            readonly tableRef: "order_status_events";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["append-only event adapter: insert row only, no update/delete"];
        };
    };
    export default orderStatusEventRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "orderStatusEventRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderStatusEventRepositoryAdapter.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderStatusEventRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository.d.ts", "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderStatusEvent.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/orderStatusEventRepositoryAdapter" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IOrderStatusEventRepository } from "_102048_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository";
    export function createOrderStatusEventRepositoryAdapter(ctx: RequestContext): IOrderStatusEventRepository;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftCloseReport.defs" {
    export const shiftCloseReportTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "ShiftCloseReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "ShiftCloseReport";
            readonly tableName: "shift_close_report";
            readonly columns: readonly [{
                readonly name: "shift_close_report_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "daily_shift_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
                readonly description: "total_sales, total_orders, best_selling_items, stock_consumption_summary, operational_metrics, updated_at";
            }];
            readonly primaryKey: readonly ["shift_close_report_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_shift_close_report_daily_shift_id";
                readonly columns: readonly ["daily_shift_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_shift_close_report_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default shiftCloseReportTableDefinition;
    export const pipeline: readonly [{
        readonly id: "shiftCloseReport__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftCloseReport.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftCloseReport.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_3_domain/entities/shiftCloseReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftCloseReport" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const shiftCloseReportTableDef: TableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftCloseReportRepositoryAdapter.defs" {
    export const shiftCloseReportRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ShiftCloseReportRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "ShiftCloseReportRepositoryAdapter";
            readonly entityId: "ShiftCloseReport";
            readonly portRef: "IShiftCloseReportRepository";
            readonly tableRef: "shift_close_reports";
            readonly mdmReads: readonly [];
            readonly notes: readonly [];
        };
    };
    export default shiftCloseReportRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "shiftCloseReportRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftCloseReportRepositoryAdapter.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftCloseReportRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/ports/shiftCloseReportRepository.d.ts", "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftCloseReport.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/shiftCloseReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftCloseReportRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IShiftCloseReportRepository } from "_102048_/l1/cafeFlow/layer_2_application/ports/shiftCloseReportRepository";
    export function createShiftCloseReportRepositoryAdapter(ctx: RequestContext): IShiftCloseReportRepository;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel.defs" {
    export const stockLevelTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "StockLevel";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "StockLevel";
            readonly tableName: "stock_level";
            readonly columns: readonly [{
                readonly name: "stock_level_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "stock_item_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
                readonly description: "current_quantity, min_quantity, updated_at";
            }];
            readonly primaryKey: readonly ["stock_level_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_stock_level_stock_item_id";
                readonly columns: readonly ["stock_item_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_stock_level_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_stock_level_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default stockLevelTableDefinition;
    export const pipeline: readonly [{
        readonly id: "stockLevel__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const stockLevelTableDef: TableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevelRepositoryAdapter.defs" {
    export const stockLevelRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "StockLevelRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "StockLevelRepositoryAdapter";
            readonly entityId: "StockLevel";
            readonly portRef: "IStockLevelRepository";
            readonly tableRef: "stock_levels";
            readonly mdmReads: readonly ["StockItem"];
            readonly notes: readonly [];
        };
    };
    export default stockLevelRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "stockLevelRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevelRepositoryAdapter.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevelRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevelRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IStockLevelRepository } from "_102048_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository";
    export function createStockLevelRepositoryAdapter(ctx: RequestContext): IStockLevelRepository;
}
declare module "_102048_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.defs" {
    export const dailyShiftRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "DailyShiftRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "DailyShift";
            readonly interfaceName: "IDailyShiftRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "DailyShift | null";
                readonly params: readonly ["id: DailyShiftId"];
            }, {
                readonly name: "list";
                readonly returns: "DailyShift[]";
                readonly params: readonly ["filter: DailyShiftFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["aggregate: DailyShift"];
            }, {
                readonly name: "findByDate";
                readonly returns: "DailyShift | null";
                readonly params: readonly ["date: LocalDate"];
            }, {
                readonly name: "listByDateRange";
                readonly returns: "DailyShift[]";
                readonly params: readonly ["start: LocalDate", "end: LocalDate"];
            }];
        };
    };
    export default dailyShiftRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "dailyShiftRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/ports/orderItemRepository.defs" {
    export const orderItemRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "OrderItemRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "OrderItem";
            readonly interfaceName: "IOrderItemRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "OrderItem | null";
                readonly params: readonly ["id: OrderItemId"];
            }, {
                readonly name: "list";
                readonly returns: "OrderItem[]";
                readonly params: readonly ["filter: OrderItemFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["aggregate: OrderItem"];
            }, {
                readonly name: "listByOrderId";
                readonly returns: "OrderItem[]";
                readonly params: readonly ["orderId: OrderId"];
            }, {
                readonly name: "listByProductId";
                readonly returns: "OrderItem[]";
                readonly params: readonly ["productId: ProductId"];
            }];
        };
    };
    export default orderItemRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "orderItemRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/ports/orderItemRepository.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/ports/orderItemRepository.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_3_domain/entities/orderItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/ports/orderRepository.defs" {
    export const orderRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "OrderRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly interfaceName: "IOrderRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "Order | null";
                readonly params: readonly ["id: OrderId"];
            }, {
                readonly name: "list";
                readonly returns: "Order[]";
                readonly params: readonly ["filter: OrderFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["aggregate: Order"];
            }, {
                readonly name: "listByStatus";
                readonly returns: "Order[]";
                readonly params: readonly ["status: OrderStatus"];
            }, {
                readonly name: "listByCustomerId";
                readonly returns: "Order[]";
                readonly params: readonly ["customerId: CustomerId"];
            }, {
                readonly name: "listByPeriod";
                readonly returns: "Order[]";
                readonly params: readonly ["start: Instant", "end: Instant"];
            }];
        };
    };
    export default orderRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "orderRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/ports/orderRepository.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/ports/orderRepository.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository.defs" {
    export const orderStatusEventRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "OrderStatusEventRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "OrderStatusEvent";
            readonly interfaceName: "IOrderStatusEventRepository";
            readonly methods: readonly [{
                readonly name: "append";
                readonly returns: "void";
                readonly params: readonly ["record: OrderStatusEvent"];
            }, {
                readonly name: "listByOwnerId";
                readonly returns: "OrderStatusEvent[]";
                readonly params: readonly ["ownerId: OrderId"];
            }, {
                readonly name: "listByPeriod";
                readonly returns: "OrderStatusEvent[]";
                readonly params: readonly ["start: Instant", "end: Instant"];
            }];
        };
    };
    export default orderStatusEventRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "orderStatusEventRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/ports/shiftCloseReportRepository.defs" {
    export const shiftCloseReportRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ShiftCloseReportRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "ShiftCloseReport";
            readonly interfaceName: "IShiftCloseReportRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "ShiftCloseReport | null";
                readonly params: readonly ["id: ShiftCloseReportId"];
            }, {
                readonly name: "list";
                readonly returns: "ShiftCloseReport[]";
                readonly params: readonly ["filter: ShiftCloseReportFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["aggregate: ShiftCloseReport"];
            }, {
                readonly name: "findByShiftId";
                readonly returns: "ShiftCloseReport | null";
                readonly params: readonly ["shiftId: DailyShiftId"];
            }, {
                readonly name: "listByPeriod";
                readonly returns: "ShiftCloseReport[]";
                readonly params: readonly ["start: LocalDate", "end: LocalDate"];
            }];
        };
    };
    export default shiftCloseReportRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "shiftCloseReportRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/ports/shiftCloseReportRepository.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/ports/shiftCloseReportRepository.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_3_domain/entities/shiftCloseReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.defs" {
    export const stockLevelRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "StockLevelRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockLevel";
            readonly interfaceName: "IStockLevelRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "StockLevel | null";
                readonly params: readonly ["id: StockLevelId"];
            }, {
                readonly name: "list";
                readonly returns: "StockLevel[]";
                readonly params: readonly ["filter: StockLevelFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["aggregate: StockLevel"];
            }, {
                readonly name: "findByProductId";
                readonly returns: "StockLevel | null";
                readonly params: readonly ["productId: ProductId"];
            }, {
                readonly name: "listLowStock";
                readonly returns: "StockLevel[]";
                readonly params: readonly ["threshold: Quantity"];
            }];
        };
    };
    export default stockLevelRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "stockLevelRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/adjustStockLevel.defs" {
    export const adjustStockLevelUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "adjustStockLevel";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "adjustStockLevel";
            readonly ports: readonly ["StockLevel"];
            readonly functions: readonly [{
                readonly functionName: "adjustStockLevel";
                readonly inputTypeName: "AdjustStockLevelInput";
                readonly outputTypeName: "AdjustStockLevelOutput";
                readonly input: readonly [{
                    readonly name: "stockLevelId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockLevel";
                    readonly description: "Identifier of the stock level record to adjust";
                }, {
                    readonly name: "currentQuantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockLevel";
                    readonly description: "New current quantity after adjustment";
                }, {
                    readonly name: "minQuantity";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "StockLevel";
                    readonly description: "Optional new minimum threshold; if omitted the existing value is kept";
                }];
                readonly output: readonly [{
                    readonly name: "stockLevelId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockLevel";
                    readonly description: "Identifier of the adjusted stock level";
                }, {
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockLevel";
                    readonly description: "Associated stock item id";
                }, {
                    readonly name: "currentQuantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockLevel";
                    readonly description: "Updated current quantity";
                }, {
                    readonly name: "minQuantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockLevel";
                    readonly description: "Effective minimum threshold after update";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockLevel";
                    readonly description: "Recomputed status: sufficient | low | depleted";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockLevel";
                    readonly description: "Timestamp of the update";
                }];
                readonly ports: readonly ["StockLevel"];
                readonly rulesApplied: readonly ["lowStockAlertRule"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the StockLevel aggregate by stockLevelId via the StockLevel port; throw not-found if absent.", "2. Read the referenced StockItem master-data via ctx.data.mdmDocument.get({ mdmId: stockLevel.stockItemId }) to verify the item exists and is active; throw validation error if inactive or missing.", "3. Determine the effective minQuantity: use the input minQuantity when provided, otherwise keep the persisted value.", "4. Apply lowStockAlertRule: set status to 'depleted' when currentQuantity <= 0, 'low' when currentQuantity < minQuantity, otherwise 'sufficient'.", "5. Mutate the StockLevel aggregate with the new currentQuantity, effective minQuantity, computed status, and updatedAt = now.", "6. Save the StockLevel aggregate through the StockLevel port inside the transaction.", "7. Return stockLevelId, stockItemId, currentQuantity, minQuantity, status, and updatedAt."];
            }];
            readonly mdmRefs: readonly ["StockItem"];
        };
    };
    export default adjustStockLevelUsecase;
    export const pipeline: readonly [{
        readonly id: "adjustStockLevel__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/adjustStockLevel.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/adjustStockLevel.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/createMenuItem.defs" {
    export const createMenuItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createMenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createMenuItem";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "createMenuItem";
                readonly inputTypeName: "CreateMenuItemInput";
                readonly outputTypeName: "CreateMenuItemOutput";
                readonly input: readonly [{
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Display name of the menu item";
                }, {
                    readonly name: "category";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Category the menu item belongs to";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Selling price of the menu item";
                }, {
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "StockItem";
                    readonly description: "Reference to the StockItem (MDM) linked for stock consumption tracking";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Initial status of the menu item (active or inactive)";
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Generated unique identifier of the created menu item";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status of the created menu item";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["stockConsumptionRule"];
                readonly transactional: true;
                readonly steps: readonly ["1. Validate required input fields: name, category, price, status.", "2. Validate status is one of the allowed enum values (active, inactive).", "3. If stockItemId is provided, read the StockItem from MDM via ctx.data.mdmDocument.get({ mdmId: stockItemId }) and verify it exists and has status 'active' (stockConsumptionRule).", "4. Generate menuItemId (uuid), createdAt and updatedAt timestamps (server-generated).", "5. Build the MenuItem aggregate root with all provided fields plus generated id and timestamps.", "6. Persist the MenuItem through the MenuItem port inside a transaction.", "7. Return menuItemId and status."];
            }];
            readonly mdmRefs: readonly ["MenuItem", "StockItem"];
        };
    };
    export default createMenuItemUsecase;
    export const pipeline: readonly [{
        readonly id: "createMenuItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/createMenuItem.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/createMenuItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/createStockItem.defs" {
    export const createStockItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createStockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createStockItem";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "createStockItem";
                readonly inputTypeName: "CreateStockItemInput";
                readonly outputTypeName: "CreateStockItemOutput";
                readonly input: readonly [{
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Name of the stock item";
                }, {
                    readonly name: "unitOfMeasure";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Unit of measure for the stock item (e.g. pieces, kg, liters)";
                }, {
                    readonly name: "minimumStockLevel";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Minimum stock level threshold; when current stock falls below this value an alert is raised";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Initial status of the stock item; must be 'active' or 'inactive'";
                }];
                readonly output: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Generated unique identifier of the newly created stock item";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Confirmed status of the created stock item";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["lowStockAlertRule"];
                readonly transactional: true;
                readonly steps: readonly ["1. Validate that name is non-empty, unitOfMeasure is non-empty, minimumStockLevel is a non-negative number, and status is one of 'active' or 'inactive'.", "2. Apply lowStockAlertRule: if minimumStockLevel is greater than zero, mark the stock item as eligible for low-stock alerts so that future inventory movements below this threshold trigger notifications.", "3. Generate a new stockItemId (uuid) and set createdAt and updatedAt to the current server timestamp.", "4. Persist the new StockItem master-data document through ctx.data.mdmDocument (shared 102034 store) inside a single transaction wrapper.", "5. Return the generated stockItemId and the confirmed status."];
            }];
            readonly mdmRefs: readonly ["StockItem"];
        };
    };
    export default createStockItemUsecase;
    export const pipeline: readonly [{
        readonly id: "createStockItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/createStockItem.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/createStockItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/createTable.defs" {
    export const createTableUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createTable";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createTable";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "createTable";
                readonly inputTypeName: "CreateTableInput";
                readonly outputTypeName: "CreateTableOutput";
                readonly input: readonly [{
                    readonly name: "tableNumber";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Human-readable table number/label";
                    readonly ofEntity: "Table";
                }, {
                    readonly name: "capacity";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Seating capacity of the table";
                    readonly ofEntity: "Table";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Initial lifecycle status (active | inactive)";
                    readonly ofEntity: "Table";
                }];
                readonly output: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Generated unique identifier for the new table";
                    readonly ofEntity: "Table";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Confirmed status after creation";
                    readonly ofEntity: "Table";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["Table is master data (mdmRef) — no repository port; created via ctx.data.mdmDocument in a single transaction wrapper", "Server-generated fields (tableId, createdAt, updatedAt) are assigned by the store, not by the caller", "status must be one of [active, inactive]"];
                readonly transactional: true;
                readonly steps: readonly ["Validate input: tableNumber is non-empty, status is 'active' or 'inactive', capacity (if provided) is a positive number", "Generate tableId (uuid), set createdAt and updatedAt to current timestamp", "Persist the Table master-data document via ctx.data.mdmDocument within a single transaction wrapper", "Return tableId and confirmed status"];
            }];
            readonly mdmRefs: readonly ["Table"];
        };
    };
    export default createTableUsecase;
    export const pipeline: readonly [{
        readonly id: "createTable__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/createTable.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/createTable.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/deleteMenuItem.defs" {
    export const deleteMenuItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "deleteMenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "deleteMenuItem";
            readonly ports: readonly ["OrderItem"];
            readonly functions: readonly [{
                readonly functionName: "deleteMenuItem";
                readonly inputTypeName: "DeleteMenuItemInput";
                readonly outputTypeName: "DeleteMenuItemOutput";
                readonly input: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "ID of the MenuItem to delete";
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "ID of the deleted MenuItem";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Result status: 'deleted' or 'blocked'";
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Reason if deletion was blocked";
                }];
                readonly ports: readonly ["OrderItem"];
                readonly rulesApplied: readonly ["stockConsumptionRule"];
                readonly transactional: true;
                readonly steps: readonly ["1. Read the MenuItem from the MDM store via ctx.data.mdmDocument.get({ mdmId: menuItemId }) to confirm it exists", "2. If MenuItem not found, return status 'not_found'", "3. Query the OrderItem port for any OrderItems whose menuItemId matches the target MenuItem (e.g. findOrderItemsByMenuItemId)", "4. Apply stockConsumptionRule: if there are OrderItems referencing this MenuItem that are in a non-terminal state (e.g. pending or in-progress orders), block deletion and return status 'blocked' with reason describing the conflicting OrderItems", "5. If no blocking OrderItems exist, delete the MenuItem from the MDM store via ctx.data.mdmDocument.delete({ mdmId: menuItemId })", "6. Return menuItemId and status 'deleted'"];
            }];
            readonly mdmRefs: readonly ["MenuItem"];
        };
    };
    export default deleteMenuItemUsecase;
    export const pipeline: readonly [{
        readonly id: "deleteMenuItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/deleteMenuItem.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/deleteMenuItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/ports/orderItemRepository.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/orderItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/deleteStockItem.defs" {
    export const deleteStockItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "deleteStockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "deleteStockItem";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "deleteStockItem";
                readonly inputTypeName: "DeleteStockItemInput";
                readonly outputTypeName: "DeleteStockItemOutput";
                readonly input: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Unique identifier of the StockItem to delete";
                }];
                readonly output: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Identifier of the deleted StockItem";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Result status of the delete operation";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["lowStockAlertRule"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the StockItem aggregate by stockItemId via StockItemPort.findById(stockItemId).", "2. Validate that the StockItem exists; throw a not-found error if it does not.", "3. Apply lowStockAlertRule: evaluate the StockItem's minimumStockLevel — if the item was configured with a minimumStockLevel greater than zero, emit a low-stock alert signal so downstream consumers can react to the removal of a monitored stock item.", "4. Delete the StockItem aggregate via StockItemPort.delete(stockItemId) inside the transaction.", "5. Return { stockItemId, status: 'deleted' }."];
            }];
            readonly mdmRefs: readonly ["StockItem"];
        };
    };
    export default deleteStockItemUsecase;
    export const pipeline: readonly [{
        readonly id: "deleteStockItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/deleteStockItem.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/deleteStockItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/deleteTable.defs" {
    export const deleteTableUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "deleteTable";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "deleteTable";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "deleteTable";
                readonly inputTypeName: "DeleteTableInput";
                readonly outputTypeName: "DeleteTableOutput";
                readonly input: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Unique identifier of the Table to delete";
                }];
                readonly output: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly ofEntity: "Table";
                    readonly description: "Identifier of the deleted Table";
                }, {
                    readonly name: "deleted";
                    readonly type: "boolean";
                    readonly description: "Whether the Table was successfully deleted";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Validate tableId is provided and non-empty", "Load Table aggregate from Table port by tableId", "Verify Table exists; throw not-found if absent", "Verify Table status is not already deleted (guard against double-delete)", "Delete Table aggregate via Table port", "Return tableId and deleted=true confirmation", "If any mdmRef (Table master data) is referenced, read it by id via ctx.data.mdmDocument.get({ mdmId: tableId }) for validation before deletion"];
            }];
            readonly mdmRefs: readonly ["Table"];
        };
    };
    export default deleteTableUsecase;
    export const pipeline: readonly [{
        readonly id: "deleteTable__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/deleteTable.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/deleteTable.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/launchOrder.defs" {
    export const launchOrderUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "launchOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "launchOrder";
            readonly ports: readonly ["Order", "DailyShift", "StockLevel", "OrderItem", "OrderStatusEvent"];
            readonly functions: readonly [{
                readonly functionName: "launchOrder";
                readonly inputTypeName: "LaunchOrderInput";
                readonly outputTypeName: "LaunchOrderOutput";
                readonly input: readonly [{
                    readonly name: "type";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Order type: 'dineIn' or 'takeout'";
                }, {
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Table";
                    readonly description: "Table reference — required when type is 'dineIn'";
                }, {
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Active daily shift this order belongs to";
                }, {
                    readonly name: "items";
                    readonly type: "array";
                    readonly required: true;
                    readonly ofEntity: "OrderItem";
                    readonly description: "Array of order items: { menuItemId: string (MenuItem ref), quantity: number, observations?: string }";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Created order identifier";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Initial order status — 'pending'";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Calculated order total from all items";
                }];
                readonly ports: readonly ["Order", "DailyShift", "StockLevel", "OrderItem", "OrderStatusEvent"];
                readonly rulesApplied: readonly ["stockConsumptionRule"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load DailyShift by dailyShiftId via DailyShift port; validate status === 'open' (reject if closed or not found).", "2. If type === 'dineIn', validate tableId is provided; read Table mdmRef via ctx.data.mdmDocument.get({ mdmId: tableId }); validate table.status === 'active'.", "3. For each item in items: read MenuItem mdmRef via ctx.data.mdmDocument.get({ mdmId: item.menuItemId }); validate menuItem.status === 'active'; capture menuItem.price as unitPrice and menuItem.stockItemId (if present).", "4. Apply stockConsumptionRule: for each item whose MenuItem has a stockItemId, load StockLevel by stockItemId via StockLevel port; validate currentQuantity >= item.quantity (reject if insufficient); decrement currentQuantity by item.quantity; recompute StockLevel.status (sufficient/low/depleted) based on currentQuantity vs minQuantity.", "5. Calculate order total = sum(unitPrice * quantity) across all items.", "6. Create Order aggregate root: generate orderId, set status='pending', type, tableId (if dineIn), dailyShiftId, total, createdAt=now, updatedAt=now.", "7. Create OrderItem children embedded in Order: for each item generate orderItemId, set orderId, menuItemId, quantity, unitPrice (from MenuItem), observations, createdAt=now, updatedAt=now.", "8. Create OrderStatusEvent: generate orderStatusEventId, set orderId, previousStatus=null, status='pending', createdAt=now, updatedAt=now; append via OrderStatusEvent port inside the same transaction.", "9. Save Order (with embedded OrderItems) via Order port.", "10. Save each updated StockLevel via StockLevel port.", "11. Return { orderId, status, total }."];
            }];
            readonly mdmRefs: readonly ["MenuItem", "Table", "StockItem"];
        };
    };
    export default launchOrderUsecase;
    export const pipeline: readonly [{
        readonly id: "launchOrder__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/launchOrder.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/launchOrder.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102048_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102048_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102048_/l1/cafeFlow/layer_2_application/ports/orderItemRepository.d.ts", "_102048_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/orderItem.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/processPayment.defs" {
    export const processPaymentUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "processPayment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "processPayment";
            readonly ports: readonly ["Order", "OrderStatusEvent"];
            readonly functions: readonly [{
                readonly functionName: "processPayment";
                readonly inputTypeName: "ProcessPaymentInput";
                readonly outputTypeName: "ProcessPaymentOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Identifier of the order to process payment for";
                }, {
                    readonly name: "amountPaid";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Amount paid by the customer, must match order total";
                }, {
                    readonly name: "paymentMethod";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Method of payment (e.g. cash, card, pix)";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Identifier of the paid order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "New order status after payment processing";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Order total amount that was paid";
                }];
                readonly ports: readonly ["Order", "OrderStatusEvent"];
                readonly rulesApplied: readonly ["ORDER_MUST_EXIST", "ORDER_STATUS_MUST_ALLOW_PAYMENT", "AMOUNT_PAID_MUST_MATCH_TOTAL", "ORDER_STATUS_EVENT_MUST_BE_APPENDED"];
                readonly transactional: true;
                readonly steps: readonly ["Load the Order aggregate by orderId through the Order port", "Validate the order exists (throw if not found)", "Validate the current status is 'delivered' or 'ready' — only orders in these states can be paid", "Validate that amountPaid equals the order total (throw on mismatch)", "Transition the order status to 'paid'", "Update the order updatedAt timestamp to current time", "Save the Order aggregate through the Order port", "Build an OrderStatusEvent record with orderId, previousStatus, newStatus 'paid', and timestamp", "Append the OrderStatusEvent through the OrderStatusEvent port inside the same transaction", "Return orderId, status, and total"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default processPaymentUsecase;
    export const pipeline: readonly [{
        readonly id: "processPayment__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/processPayment.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/processPayment.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102048_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/queryMenuItem.defs" {
    export const queryMenuItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "queryMenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "queryMenuItem";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "queryMenuItem";
                readonly inputTypeName: "QueryMenuItemInput";
                readonly outputTypeName: "QueryMenuItemOutput";
                readonly input: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Unique identifier of the menu item to query";
                }, {
                    readonly name: "includeStockDetails";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly description: "When true, enrich the result with the linked StockItem master data";
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Unique identifier of the menu item";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Display name of the menu item";
                }, {
                    readonly name: "category";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Category the menu item belongs to";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Selling price of the menu item";
                }, {
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "StockItem";
                    readonly description: "Reference to the linked stock item, if any";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Menu item status (active or inactive)";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Creation timestamp";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Last update timestamp";
                }, {
                    readonly name: "stockItemName";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "StockItem";
                    readonly description: "Name of the linked stock item (when includeStockDetails is true and stockItemId is present)";
                }, {
                    readonly name: "stockItemUnitOfMeasure";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "StockItem";
                    readonly description: "Unit of measure of the linked stock item";
                }, {
                    readonly name: "stockItemMinimumStockLevel";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "StockItem";
                    readonly description: "Minimum stock level of the linked stock item";
                }, {
                    readonly name: "stockItemStatus";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "StockItem";
                    readonly description: "Status of the linked stock item (active or inactive)";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["stockConsumptionRule"];
                readonly transactional: false;
                readonly steps: readonly ["Read MenuItem master data by menuItemId via ctx.data.mdmDocument.get({ mdmId: menuItemId })", "Validate that the MenuItem exists; throw not-found if absent", "If includeStockDetails is true and MenuItem.stockItemId is present, read StockItem master data via ctx.data.mdmDocument.get({ mdmId: stockItemId })", "Apply stockConsumptionRule: verify the linked StockItem is active when MenuItem is active; include stock availability context in the result", "Project MenuItem fields and, when enriched, append StockItem fields (stockItemName, stockItemUnitOfMeasure, stockItemMinimumStockLevel, stockItemStatus)", "Return the enriched MenuItem projection"];
            }];
            readonly rulesApplied: readonly ["stockConsumptionRule"];
            readonly mdmRefs: readonly ["MenuItem", "StockItem"];
        };
    };
    export default queryMenuItemUsecase;
    export const pipeline: readonly [{
        readonly id: "queryMenuItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/queryMenuItem.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/queryMenuItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["stockConsumptionRule"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/queryStockItem.defs" {
    export const queryStockItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "queryStockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "queryStockItem";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "queryStockItem";
                readonly inputTypeName: "QueryStockItemInput";
                readonly outputTypeName: "QueryStockItemOutput";
                readonly input: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "StockItem";
                    readonly description: "Optional filter by stock item id for single-item lookup";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "StockItem";
                    readonly description: "Optional filter by stock item name (partial match)";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "StockItem";
                    readonly description: "Optional filter by status: active | inactive";
                }];
                readonly output: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                }, {
                    readonly name: "unitOfMeasure";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                }, {
                    readonly name: "minimumStockLevel";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                }, {
                    readonly name: "lowStockAlert";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly description: "Computed flag from lowStockAlertRule indicating the item is at or below its minimum stock level";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["lowStockAlertRule"];
                readonly transactional: false;
                readonly steps: readonly ["Read StockItem master data by id via ctx.data.mdmDocument.get({ mdmId: stockItemId }) when stockItemId is provided; otherwise query matching items by name and/or status filters", "For each returned StockItem, apply lowStockAlertRule to compute lowStockAlert flag based on minimumStockLevel", "Project the result fields including the computed lowStockAlert flag", "Return the projected StockItem(s) to the caller"];
            }];
            readonly mdmRefs: readonly ["StockItem"];
        };
    };
    export default queryStockItemUsecase;
    export const pipeline: readonly [{
        readonly id: "queryStockItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/queryStockItem.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/queryStockItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/queryTable.defs" {
    export const queryTableUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "queryTable";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "queryTable";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "queryTableById";
                readonly inputTypeName: "QueryTableByIdInput";
                readonly outputTypeName: "TableView";
                readonly input: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Unique identifier of the table to retrieve";
                }];
                readonly output: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Unique identifier of the table";
                }, {
                    readonly name: "tableNumber";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Human-readable table number";
                }, {
                    readonly name: "capacity";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "Table";
                    readonly description: "Seating capacity of the table";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Table status: active or inactive";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Creation timestamp";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Last update timestamp";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Receive tableId from caller", "Read the Table master-data document via ctx.data.mdmDocument.get({ mdmId: tableId })", "If not found, return null/empty result", "Project the Table fields (tableId, tableNumber, capacity, status, createdAt, updatedAt) as the output view", "Return the projected TableView"];
            }, {
                readonly functionName: "queryTables";
                readonly inputTypeName: "QueryTablesInput";
                readonly outputTypeName: "TableViewList";
                readonly input: readonly [{
                    readonly name: "tableNumber";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Table";
                    readonly description: "Optional filter by table number (exact or partial match)";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Table";
                    readonly description: "Optional filter by status: active or inactive";
                }];
                readonly output: readonly [{
                    readonly name: "items";
                    readonly type: "Table[]";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "List of tables matching the filter criteria";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Total number of matching tables";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Receive optional filter criteria (tableNumber, status) from caller", "Query Table master-data documents via ctx.data.mdmDocument.search with the provided filters", "If no filters provided, return all Table documents", "Project each Table document to its view fields (tableId, tableNumber, capacity, status, createdAt, updatedAt)", "Return the projected list as items along with the total count"];
            }];
            readonly mdmRefs: readonly ["Table"];
        };
    };
    export default queryTableUsecase;
    export const pipeline: readonly [{
        readonly id: "queryTable__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/queryTable.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/queryTable.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/updateMenuItem.defs" {
    export const updateMenuItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateMenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateMenuItem";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "updateMenuItem";
                readonly inputTypeName: "UpdateMenuItemInput";
                readonly outputTypeName: "UpdateMenuItemOutput";
                readonly input: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Identifier of the menu item to update";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Updated display name of the menu item";
                }, {
                    readonly name: "category";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Updated category classification";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Updated selling price";
                }, {
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "StockItem";
                    readonly description: "Reference to the linked stock item (master data id)";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Updated lifecycle status: active or inactive";
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Identifier of the updated menu item";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Updated name of the menu item";
                }, {
                    readonly name: "category";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Updated category";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Updated price";
                }, {
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "StockItem";
                    readonly description: "Linked stock item id if any";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Current status of the menu item";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Timestamp of the last update";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["stockConsumptionRule"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the existing MenuItem aggregate by menuItemId through menuItemPort; throw NotFound if it does not exist.", "2. If stockItemId is provided in the input, resolve the StockItem master-data document via ctx.data.mdmDocument.get({ mdmId: stockItemId }); throw ValidationError if the StockItem does not exist or its status is not 'active' (stockConsumptionRule).", "3. If stockItemId is cleared (set to null) on update, allow unlinking without mdm lookup.", "4. Apply the provided field changes (name, category, price, stockItemId, status) onto the loaded MenuItem aggregate, preserving menuItemId and createdAt.", "5. Set updatedAt to the current server datetime.", "6. Validate that status is one of 'active' or 'inactive'; throw ValidationError otherwise.", "7. Save the updated MenuItem aggregate through menuItemPort inside the transaction.", "8. Return the updated menuItemId, name, category, price, stockItemId, status, and updatedAt."];
            }];
            readonly mdmRefs: readonly ["MenuItem", "StockItem"];
        };
    };
    export default updateMenuItemUsecase;
    export const pipeline: readonly [{
        readonly id: "updateMenuItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/updateMenuItem.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/updateMenuItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.defs" {
    export const updateOrderStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateOrderStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateOrderStatus";
            readonly ports: readonly ["Order", "OrderStatusEvent"];
            readonly functions: readonly [{
                readonly functionName: "updateOrderStatus";
                readonly inputTypeName: "UpdateOrderStatusInput";
                readonly outputTypeName: "UpdateOrderStatusOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "The order whose status is being updated";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "The new status to transition the order to (pending, sent_to_kitchen, preparing, ready, delivered, paid, cancelled)";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "The updated order id";
                }, {
                    readonly name: "previousStatus";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "OrderStatusEvent";
                    readonly description: "The status the order had before the transition";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "The new status applied to the order";
                }, {
                    readonly name: "orderStatusEventId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "OrderStatusEvent";
                    readonly description: "The id of the created audit event recording the status transition";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Timestamp of the order update";
                }];
                readonly ports: readonly ["Order", "OrderStatusEvent"];
                readonly rulesApplied: readonly ["Order status must be a valid enum value (pending, sent_to_kitchen, preparing, ready, delivered, paid, cancelled)", "OrderStatusEvent must capture previousStatus before applying the new status", "OrderStatusEvent is append-only audit record persisted in the same transaction as the Order update"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the Order by orderId through the Order port", "2. Validate that the requested status is a valid Order status enum value", "3. Capture the Order's current status as previousStatus", "4. Update the Order's status field to the new status and set updatedAt to current datetime", "5. Create a new OrderStatusEvent with orderId, previousStatus, status (new), createdAt and updatedAt set to current datetime, and a generated orderStatusEventId", "6. Save the updated Order through the Order port", "7. Append the OrderStatusEvent through the OrderStatusEvent port (audit, persisted) inside the same transaction", "8. Return orderId, previousStatus, status, orderStatusEventId, and updatedAt"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default updateOrderStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateOrderStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102048_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/updateStockItem.defs" {
    export const updateStockItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateStockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateStockItem";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "updateStockItem";
                readonly inputTypeName: "UpdateStockItemInput";
                readonly outputTypeName: "UpdateStockItemOutput";
                readonly input: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Identifier of the stock item to update";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Updated name of the stock item";
                }, {
                    readonly name: "unitOfMeasure";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Updated unit of measure (e.g. pieces, kg, liters)";
                }, {
                    readonly name: "minimumStockLevel";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Updated minimum stock level threshold for low-stock alert";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Updated status of the stock item (active or inactive)";
                }];
                readonly output: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Identifier of the updated stock item";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Updated name";
                }, {
                    readonly name: "unitOfMeasure";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Updated unit of measure";
                }, {
                    readonly name: "minimumStockLevel";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Updated minimum stock level";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Updated status";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Timestamp of the update";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["lowStockAlertRule"];
                readonly transactional: true;
                readonly steps: readonly ["Load StockItem aggregate by stockItemId via StockItemPort", "Validate that the StockItem exists; throw not-found if missing", "Apply updated fields (name, unitOfMeasure, minimumStockLevel, status) to the StockItem", "Evaluate lowStockAlertRule: if minimumStockLevel is greater than zero and current quantity on hand is at or below the threshold, flag a low-stock condition", "Set updatedAt to the current server timestamp", "Save the StockItem aggregate via StockItemPort within the transaction", "Return the updated stockItemId, name, unitOfMeasure, minimumStockLevel, status, and updatedAt"];
            }];
            readonly rulesApplied: readonly ["lowStockAlertRule"];
            readonly mdmRefs: readonly ["StockItem"];
        };
    };
    export default updateStockItemUsecase;
    export const pipeline: readonly [{
        readonly id: "updateStockItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/updateStockItem.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/updateStockItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["lowStockAlertRule"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/updateTable.defs" {
    export const updateTableUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateTable";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateTable";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "updateTable";
                readonly inputTypeName: "UpdateTableInput";
                readonly outputTypeName: "UpdateTableOutput";
                readonly input: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Identifier of the Table master-data document to update";
                }, {
                    readonly name: "tableNumber";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Human-readable table number";
                }, {
                    readonly name: "capacity";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "Table";
                    readonly description: "Seating capacity of the table";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Table lifecycle status — must be 'active' or 'inactive'";
                }];
                readonly output: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Identifier of the updated Table";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Confirmed status after update";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Timestamp of the update";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["Table is master data (mdmRef) — read and write via ctx.data.mdmDocument by id, no repository port", "Validate status enum: must be 'active' or 'inactive'", "Validate table exists before applying changes", "updatedAt is refreshed to actualDate on every successful write"];
                readonly transactional: true;
                readonly steps: readonly ["Load the Table master-data document by tableId via ctx.data.mdmDocument.get({ mdmId: tableId })", "If the document is not found, fail with a not-found error", "Validate that status is one of 'active' or 'inactive'", "Apply the incoming field changes (tableNumber, capacity, status) onto the loaded document", "Set updatedAt to the current timestamp", "Persist the updated document back through ctx.data.mdmDocument within the same transaction", "Return tableId, status, and updatedAt of the persisted document"];
            }];
            readonly mdmRefs: readonly ["Table"];
        };
    };
    export default updateTableUsecase;
    export const pipeline: readonly [{
        readonly id: "updateTable__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/updateTable.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/updateTable.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/viewDashboard.defs" {
    export const viewDashboardUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewDashboard";
            readonly ports: readonly ["DailyShift", "Order", "OrderItem", "OrderStatusEvent"];
            readonly functions: readonly [{
                readonly functionName: "viewDashboard";
                readonly inputTypeName: "ViewDashboardInput";
                readonly outputTypeName: "ViewDashboardOutput";
                readonly input: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "The daily shift to view the dashboard for";
                }];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "The daily shift identifier";
                }, {
                    readonly name: "date";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Shift date";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Shift status: open or closed";
                }, {
                    readonly name: "openTime";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Shift opening timestamp";
                }, {
                    readonly name: "closeTime";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Shift closing timestamp, null if still open";
                }, {
                    readonly name: "totalSales";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                    readonly description: "Total sales recorded for the shift";
                }, {
                    readonly name: "orderCount";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Total number of orders in the shift";
                }, {
                    readonly name: "pendingOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Count of orders in pending status";
                }, {
                    readonly name: "preparingOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Count of orders in preparing status";
                }, {
                    readonly name: "readyOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Count of orders in ready status";
                }, {
                    readonly name: "deliveredOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Count of orders in delivered status";
                }, {
                    readonly name: "paidOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Count of orders in paid status";
                }, {
                    readonly name: "cancelledOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Count of cancelled orders";
                }, {
                    readonly name: "dineInOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Count of dine-in orders";
                }, {
                    readonly name: "takeoutOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Count of takeout orders";
                }, {
                    readonly name: "totalOrderItems";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Total quantity of items across all orders";
                }, {
                    readonly name: "orders";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "JSON array of order summaries with orderId, type, status, total, and item count";
                }];
                readonly ports: readonly ["DailyShift", "Order", "OrderItem"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Load the DailyShift by dailyShiftId via DailyShift port", "Query all Orders for the given dailyShiftId via Order port", "For each Order, query its OrderItems via OrderItem port to compute item counts and total quantity", "Aggregate order counts grouped by status (pending, sent_to_kitchen, preparing, ready, delivered, paid, cancelled)", "Aggregate order counts grouped by type (dineIn, takeout)", "Sum total quantity of all OrderItems across orders", "Build the dashboard output combining shift details, aggregated metrics, and per-order summaries", "Return the assembled dashboard view"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewDashboardUsecase;
    export const pipeline: readonly [{
        readonly id: "viewDashboard__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/viewDashboard.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/viewDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102048_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102048_/l1/cafeFlow/layer_2_application/ports/orderItemRepository.d.ts", "_102048_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/orderItem.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_2_application/usecases/viewShiftReport.defs" {
    export const viewShiftReportUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewShiftReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewShiftReport";
            readonly ports: readonly ["ShiftCloseReport", "DailyShift"];
            readonly functions: readonly [{
                readonly functionName: "viewShiftReportById";
                readonly inputTypeName: "ViewShiftReportByIdInput";
                readonly outputTypeName: "ShiftReportView";
                readonly input: readonly [{
                    readonly name: "shiftCloseReportId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftCloseReport";
                }];
                readonly output: readonly [{
                    readonly name: "shiftCloseReportId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftCloseReport";
                }, {
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftCloseReport";
                }, {
                    readonly name: "totalSales";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "ShiftCloseReport";
                }, {
                    readonly name: "totalOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "ShiftCloseReport";
                }, {
                    readonly name: "bestSellingItems";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftCloseReport";
                }, {
                    readonly name: "stockConsumptionSummary";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftCloseReport";
                }, {
                    readonly name: "operationalMetrics";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftCloseReport";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftCloseReport";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftCloseReport";
                }, {
                    readonly name: "dailyShiftDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "dailyShiftOpenTime";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "dailyShiftCloseTime";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "dailyShiftStatus";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "dailyShiftTotalSales";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }];
                readonly ports: readonly ["ShiftCloseReport", "DailyShift"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Load ShiftCloseReport by shiftCloseReportId via ShiftCloseReport port", "Extract dailyShiftId from the loaded report", "Load DailyShift by dailyShiftId via DailyShift port", "Project ShiftCloseReport fields and DailyShift fields into the combined view output"];
            }, {
                readonly functionName: "viewShiftReportByDailyShiftId";
                readonly inputTypeName: "ViewShiftReportByDailyShiftIdInput";
                readonly outputTypeName: "ShiftReportView";
                readonly input: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }];
                readonly output: readonly [{
                    readonly name: "shiftCloseReportId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftCloseReport";
                }, {
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftCloseReport";
                }, {
                    readonly name: "totalSales";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "ShiftCloseReport";
                }, {
                    readonly name: "totalOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "ShiftCloseReport";
                }, {
                    readonly name: "bestSellingItems";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftCloseReport";
                }, {
                    readonly name: "stockConsumptionSummary";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftCloseReport";
                }, {
                    readonly name: "operationalMetrics";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftCloseReport";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftCloseReport";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftCloseReport";
                }, {
                    readonly name: "dailyShiftDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "dailyShiftOpenTime";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "dailyShiftCloseTime";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "dailyShiftStatus";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }, {
                    readonly name: "dailyShiftTotalSales";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "DailyShift";
                }];
                readonly ports: readonly ["ShiftCloseReport", "DailyShift"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Load DailyShift by dailyShiftId via DailyShift port", "Load ShiftCloseReport by dailyShiftId via ShiftCloseReport port", "Project ShiftCloseReport fields and DailyShift fields into the combined view output"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewShiftReportUsecase;
    export const pipeline: readonly [{
        readonly id: "viewShiftReport__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/viewShiftReport.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_2_application/usecases/viewShiftReport.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/cafeFlow/layer_2_application/ports/shiftCloseReportRepository.d.ts", "_102048_/l1/cafeFlow/layer_2_application/ports/dailyShiftRepository.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/shiftCloseReport.d.ts", "_102048_/l1/cafeFlow/layer_3_domain/entities/dailyShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_3_domain/entities/dailyShift.defs" {
    export const dailyShiftDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "DailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "DailyShift";
            readonly fields: readonly [{
                readonly fieldId: "dailyShiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do turno diário";
            }, {
                readonly fieldId: "date";
                readonly type: "date";
                readonly required: true;
                readonly description: "Data do turno operacional";
            }, {
                readonly fieldId: "openTime";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Horário de abertura do turno";
            }, {
                readonly fieldId: "closeTime";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Horário de fechamento do turno";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Status atual do turno";
                readonly enum: readonly ["open", "closed"];
            }, {
                readonly fieldId: "totalSales";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor acumulado de vendas do turno";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["open", "closed"];
            readonly invariants: readonly ["totalSales must be >= 0", "When status is 'open', closeTime must be null", "When status is 'closed', closeTime must be set and must be after openTime", "openTime must be set and cannot be in the future"];
            readonly valueObjects: readonly [];
        };
    };
    export default dailyShiftDomainEntity;
    export const pipeline: readonly [{
        readonly id: "dailyShift__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_3_domain/entities/dailyShift.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_3_domain/entities/dailyShift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_3_domain/entities/order.defs" {
    export const orderDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly fields: readonly [{
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do pedido";
            }, {
                readonly fieldId: "type";
                readonly type: "string";
                readonly required: true;
                readonly description: "Tipo do pedido: dine-in (mesa) ou takeout";
                readonly enum: readonly ["dineIn", "takeout"];
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Status atual do pedido no fluxo operacional";
                readonly enum: readonly ["pending", "sent_to_kitchen", "preparing", "ready", "delivered", "paid", "cancelled"];
            }, {
                readonly fieldId: "total";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor total do pedido";
            }, {
                readonly fieldId: "tableId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Referência à mesa para pedidos dine-in; nulo para pedidos takeout";
            }, {
                readonly fieldId: "dailyShiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao turno diário em que o pedido foi lançado";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["pending", "sent_to_kitchen", "preparing", "ready", "delivered", "paid", "cancelled"];
            readonly invariants: readonly ["total must be >= 0", "When type is 'dineIn', tableId is required", "When type is 'takeout', tableId must be null", "Status transitions must follow: pending -> sent_to_kitchen -> preparing -> ready -> delivered -> paid; cancelled can occur from any non-paid/non-delivered status", "dailyShiftId must not be null"];
            readonly valueObjects: readonly [];
        };
    };
    export default orderDomainEntity;
    export const pipeline: readonly [{
        readonly id: "order__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_3_domain/entities/order.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_3_domain/entities/order.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_3_domain/entities/orderItem.defs" {
    export const orderItemDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "OrderItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "OrderItem";
            readonly fields: readonly [{
                readonly fieldId: "orderItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do item do pedido";
            }, {
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao pedido ao qual este item pertence";
            }, {
                readonly fieldId: "menuItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao item do cardápio solicitado";
            }, {
                readonly fieldId: "quantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade solicitada do item";
            }, {
                readonly fieldId: "unitPrice";
                readonly type: "money";
                readonly required: true;
                readonly description: "Preço unitário do item no momento do pedido";
            }, {
                readonly fieldId: "observations";
                readonly type: "text";
                readonly required: false;
                readonly description: "Observações ou instruções especiais para o item";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly invariants: readonly ["quantity must be > 0", "unitPrice must be >= 0", "orderId and menuItemId must not be null"];
            readonly valueObjects: readonly [];
        };
    };
    export default orderItemDomainEntity;
    export const pipeline: readonly [{
        readonly id: "orderItem__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_3_domain/entities/orderItem.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_3_domain/entities/orderItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.defs" {
    export const orderStatusEventDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "OrderStatusEvent";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "OrderStatusEvent";
            readonly fields: readonly [{
                readonly fieldId: "orderStatusEventId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do evento de status do pedido";
            }, {
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao pedido ao qual este evento de status pertence";
            }, {
                readonly fieldId: "previousStatus";
                readonly type: "string";
                readonly required: false;
                readonly description: "Status anterior do pedido antes da transição (nulo para o primeiro evento)";
                readonly enum: readonly ["pending", "sent_to_kitchen", "preparing", "ready", "delivered", "paid", "cancelled"];
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Novo status do pedido registrado por este evento";
                readonly enum: readonly ["pending", "sent_to_kitchen", "preparing", "ready", "delivered", "paid", "cancelled"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro do evento";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro do evento";
            }];
            readonly invariants: readonly [];
            readonly valueObjects: readonly [];
        };
    };
    export default orderStatusEventDomainEntity;
    export const pipeline: readonly [{
        readonly id: "orderStatusEvent__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_3_domain/entities/shiftCloseReport.defs" {
    export const shiftCloseReportDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "ShiftCloseReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "ShiftCloseReport";
            readonly fields: readonly [{
                readonly fieldId: "shiftCloseReportId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do relatório de fechamento de turno";
            }, {
                readonly fieldId: "dailyShiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao turno diário ao qual este relatório pertence";
            }, {
                readonly fieldId: "totalSales";
                readonly type: "money";
                readonly required: true;
                readonly description: "Total de vendas consolidado no fechamento do turno";
            }, {
                readonly fieldId: "totalOrders";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade total de pedidos processados no turno";
            }, {
                readonly fieldId: "bestSellingItems";
                readonly type: "text";
                readonly required: true;
                readonly description: "Snapshot dos itens mais vendidos durante o turno";
            }, {
                readonly fieldId: "stockConsumptionSummary";
                readonly type: "text";
                readonly required: true;
                readonly description: "Resumo consolidado do estoque consumido no turno";
            }, {
                readonly fieldId: "operationalMetrics";
                readonly type: "text";
                readonly required: true;
                readonly description: "Métricas operacionais consolidadas do turno";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do relatório";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do relatório";
            }];
            readonly invariants: readonly ["totalSales must be >= 0", "totalOrders must be >= 0", "dailyShiftId must not be null", "A ShiftCloseReport can only be created when the referenced DailyShift status is 'closed'"];
            readonly valueObjects: readonly [];
        };
    };
    export default shiftCloseReportDomainEntity;
    export const pipeline: readonly [{
        readonly id: "shiftCloseReport__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_3_domain/entities/shiftCloseReport.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_3_domain/entities/shiftCloseReport.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/cafeFlow/layer_3_domain/entities/stockLevel.defs" {
    export const stockLevelDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "StockLevel";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockLevel";
            readonly fields: readonly [{
                readonly fieldId: "stockLevelId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do estado de estoque.";
            }, {
                readonly fieldId: "stockItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao item de estoque rastreado.";
            }, {
                readonly fieldId: "currentQuantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade atual live disponível em estoque.";
            }, {
                readonly fieldId: "minQuantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade mínima configurada para disparar alerta de estoque baixo.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação operacional do estoque.";
                readonly enum: readonly ["sufficient", "low", "depleted"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro.";
            }];
            readonly statusEnum: readonly ["sufficient", "low", "depleted"];
            readonly invariants: readonly ["currentQuantity must be >= 0", "minQuantity must be >= 0", "When currentQuantity is 0, status must be 'depleted'", "When currentQuantity > 0 and currentQuantity < minQuantity, status must be 'low'", "When currentQuantity >= minQuantity, status must be 'sufficient'", "stockItemId must not be null"];
            readonly valueObjects: readonly [];
        };
    };
    export default stockLevelDomainEntity;
    export const pipeline: readonly [{
        readonly id: "stockLevel__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102048_/l1/cafeFlow/layer_3_domain/entities/stockLevel.ts";
        readonly defPath: "_102048_/l1/cafeFlow/layer_3_domain/entities/stockLevel.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102048_/l2/cafeFlow/web/contracts/adjustStockLevel.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "adjustStockLevel__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102048_/l2/cafeFlow/web/contracts/adjustStockLevel.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/contracts/adjustStockLevel.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/contracts/adjustStockLevel" {
    export interface CafeFlowAdjustStockLevelInput {
        currentQuantity: number;
        status: "sufficient" | "low" | "depleted";
    }
    export interface CafeFlowAdjustStockLevelOutput {
        stockLevelId: string;
    }
}
declare module "_102048_/l2/cafeFlow/web/contracts/adjustStockLevel.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/contracts/createMenuItem.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "createMenuItem__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102048_/l2/cafeFlow/web/contracts/createMenuItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/contracts/createMenuItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/contracts/createMenuItem.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/contracts/createStockItem.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "createStockItem__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102048_/l2/cafeFlow/web/contracts/createStockItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/contracts/createStockItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/contracts/createStockItem.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/contracts/createTable.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "createTable__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102048_/l2/cafeFlow/web/contracts/createTable.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/contracts/createTable.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/contracts/createTable.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/contracts/deleteMenuItem.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "deleteMenuItem__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102048_/l2/cafeFlow/web/contracts/deleteMenuItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/contracts/deleteMenuItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/contracts/deleteMenuItem.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/contracts/deleteStockItem.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "deleteStockItem__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102048_/l2/cafeFlow/web/contracts/deleteStockItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/contracts/deleteStockItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/contracts/deleteStockItem.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/contracts/deleteTable.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "deleteTable__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102048_/l2/cafeFlow/web/contracts/deleteTable.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/contracts/deleteTable.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/contracts/deleteTable.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/contracts/orderLifecycle.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "orderLifecycle__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102048_/l2/cafeFlow/web/contracts/orderLifecycle.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/contracts/orderLifecycle.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/contracts/orderLifecycle.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/contracts/queryMenuItem.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "queryMenuItem__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102048_/l2/cafeFlow/web/contracts/queryMenuItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/contracts/queryMenuItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/contracts/queryMenuItem.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/contracts/queryStockItem.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "queryStockItem__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102048_/l2/cafeFlow/web/contracts/queryStockItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/contracts/queryStockItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/contracts/queryStockItem.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/contracts/queryTable.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "queryTable__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102048_/l2/cafeFlow/web/contracts/queryTable.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/contracts/queryTable.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/contracts/queryTable.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/contracts/shiftLifecycle.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "shiftLifecycle__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102048_/l2/cafeFlow/web/contracts/shiftLifecycle.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/contracts/shiftLifecycle.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/contracts/shiftLifecycle.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/contracts/updateMenuItem.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "updateMenuItem__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102048_/l2/cafeFlow/web/contracts/updateMenuItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/contracts/updateMenuItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/contracts/updateMenuItem.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/contracts/updateStockItem.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "updateStockItem__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102048_/l2/cafeFlow/web/contracts/updateStockItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/contracts/updateStockItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/contracts/updateStockItem.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/contracts/updateTable.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "updateTable__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102048_/l2/cafeFlow/web/contracts/updateTable.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/contracts/updateTable.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/contracts/updateTable.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/adjustStockLevel.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "adjustStockLevel__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102048_/l2/cafeFlow/web/desktop/page11/adjustStockLevel.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/desktop/page11/adjustStockLevel.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/shared/adjustStockLevel.defs.ts", "_102048_/l2/cafeFlow/web/shared/adjustStockLevel.ts", "_102048_/l2/cafeFlow/web/contracts/adjustStockLevel.defs.ts", "_102048_/l2/cafeFlow/web/contracts/adjustStockLevel.ts"];
        readonly dependsOn: readonly ["adjustStockLevel__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Limpo e prático, otimizado para toque em tablet/computador no caixa e na cozinha; cores quentes e acolhedoras (tons de café), tipografia legível em alta velocidade.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/adjustStockLevel" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    const message_pt: {
        "adjustStockLevel.section.title": string;
        "adjustStockLevel.organism.title": string;
        "adjustStockLevel.intent.commandForm.title": string;
        "adjustStockLevel.field.currentQuantity": string;
        "adjustStockLevel.field.status": string;
        "adjustStockLevel.action.submit": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowAdjustStockLevelBase extends CollabLitElement {
        status: string;
        adjustStockLevelState: "idle" | "loading" | "success" | "error";
        adjustStockLevelCurrentQuantity: string;
        adjustStockLevelStatus: string;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setAdjustStockLevelCurrentQuantity(value: string): void;
        handleAdjustStockLevelCurrentQuantityChange(e: Event): void;
        setAdjustStockLevelStatus(value: string): void;
        handleAdjustStockLevelStatusChange(e: Event): void;
        adjustStockLevel(): Promise<void>;
        handleAdjustStockLevelClick(e: Event): Promise<void>;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/adjustStockLevel" {
    import { CafeFlowAdjustStockLevelBase } from "_102048_/l2/cafeFlow/web/shared/adjustStockLevel";
    export class CafeFlowDesktopPage11AdjustStockLevelPage extends CafeFlowAdjustStockLevelBase {
        render(): any;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/createMenuItem.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "createMenuItem__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102048_/l2/cafeFlow/web/desktop/page11/createMenuItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/desktop/page11/createMenuItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/shared/createMenuItem.defs.ts", "_102048_/l2/cafeFlow/web/shared/createMenuItem.ts", "_102048_/l2/cafeFlow/web/contracts/createMenuItem.defs.ts", "_102048_/l2/cafeFlow/web/contracts/createMenuItem.ts"];
        readonly dependsOn: readonly ["createMenuItem__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Limpo e prático, otimizado para toque em tablet/computador no caixa e na cozinha; cores quentes e acolhedoras (tons de café), tipografia legível em alta velocidade.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/createMenuItem" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    const message_pt: {
        "createMenuItem.section.title": string;
        "createMenuItem.organism.title": string;
        "createMenuItem.intent.commandForm.title": string;
        "menuItem.field.name": string;
        "menuItem.field.category": string;
        "menuItem.field.price": string;
        "menuItem.field.status": string;
        "createMenuItem.action.submit": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowCreateMenuItemBase extends CollabLitElement {
        status: string;
        createMenuItemState: "idle" | "loading" | "success" | "error";
        createMenuItemName: string;
        createMenuItemCategory: string;
        createMenuItemPrice: string;
        createMenuItemStatus: string;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setCreateMenuItemName(value: string): void;
        handleCreateMenuItemNameChange(e: Event): void;
        setCreateMenuItemCategory(value: string): void;
        handleCreateMenuItemCategoryChange(e: Event): void;
        setCreateMenuItemPrice(value: string): void;
        handleCreateMenuItemPriceChange(e: Event): void;
        setCreateMenuItemStatus(value: string): void;
        handleCreateMenuItemStatusChange(e: Event): void;
        createMenuItem(): Promise<void>;
        handleCreateMenuItemClick(e: Event): void;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/createMenuItem" {
    import { CafeFlowCreateMenuItemBase } from "_102048_/l2/cafeFlow/web/shared/createMenuItem";
    export class CafeFlowDesktopPage11CreateMenuItemPage extends CafeFlowCreateMenuItemBase {
        render(): any;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/createStockItem.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "createStockItem__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102048_/l2/cafeFlow/web/desktop/page11/createStockItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/desktop/page11/createStockItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/shared/createStockItem.defs.ts", "_102048_/l2/cafeFlow/web/shared/createStockItem.ts", "_102048_/l2/cafeFlow/web/contracts/createStockItem.defs.ts", "_102048_/l2/cafeFlow/web/contracts/createStockItem.ts"];
        readonly dependsOn: readonly ["createStockItem__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Limpo e prático, otimizado para toque em tablet/computador no caixa e na cozinha; cores quentes e acolhedoras (tons de café), tipografia legível em alta velocidade.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/createStockItem" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    const message_pt: {
        "createStockItem.section.title": string;
        "createStockItem.form.title": string;
        "createStockItem.action.submit": string;
        "stockItem.field.name": string;
        "stockItem.field.unitOfMeasure": string;
        "stockItem.field.minimumStockLevel": string;
        "stockItem.field.status": string;
        "section.createStockItem.title": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowCreateStockItemBase extends CollabLitElement {
        status: string;
        createStockItemState: "idle" | "loading" | "success" | "error";
        createStockItemName: string;
        createStockItemUnitOfMeasure: string;
        createStockItemMinimumStockLevel: string;
        createStockItemStatus: string;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setCreateStockItemName(value: string): void;
        handleCreateStockItemNameChange: (e: Event) => void;
        setCreateStockItemUnitOfMeasure(value: string): void;
        handleCreateStockItemUnitOfMeasureChange: (e: Event) => void;
        setCreateStockItemMinimumStockLevel(value: string): void;
        handleCreateStockItemMinimumStockLevelChange: (e: Event) => void;
        setCreateStockItemStatus(value: string): void;
        handleCreateStockItemStatusChange: (e: Event) => void;
        createStockItem(): Promise<void>;
        handleCreateStockItemClick: () => void;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/createStockItem" {
    import { CafeFlowCreateStockItemBase } from "_102048_/l2/cafeFlow/web/shared/createStockItem";
    export class CafeFlowDesktopPage11CreateStockItemPage extends CafeFlowCreateStockItemBase {
        render(): any;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/createTable.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "createTable__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102048_/l2/cafeFlow/web/desktop/page11/createTable.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/desktop/page11/createTable.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/shared/createTable.defs.ts", "_102048_/l2/cafeFlow/web/shared/createTable.ts", "_102048_/l2/cafeFlow/web/contracts/createTable.defs.ts", "_102048_/l2/cafeFlow/web/contracts/createTable.ts"];
        readonly dependsOn: readonly ["createTable__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Limpo e prático, otimizado para toque em tablet/computador no caixa e na cozinha; cores quentes e acolhedoras (tons de café), tipografia legível em alta velocidade.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/createTable" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    const message_pt: {
        "createTable.section.title": string;
        "createTable.organism.title": string;
        "createTable.intention.form.title": string;
        "createTable.field.tableNumber": string;
        "createTable.field.capacity": string;
        "createTable.field.status": string;
        "createTable.field.status.active": string;
        "createTable.field.status.inactive": string;
        "createTable.action.submit": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowCreateTableBase extends CollabLitElement {
        status: string;
        createTableState: "idle" | "loading" | "success" | "error";
        createTableTableNumber: string;
        createTableCapacity: string;
        createTableStatus: string;
        protected get msg(): MessageType;
        setCreateTableTableNumber(value: string): void;
        handleCreateTableTableNumberChange(e: Event): void;
        setCreateTableCapacity(value: string): void;
        handleCreateTableCapacityChange(e: Event): void;
        setCreateTableStatus(value: string): void;
        handleCreateTableStatusChange(e: Event): void;
        createTable(): Promise<void>;
        handleCreateTableClick(_e: Event): Promise<void>;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/createTable" {
    import { CafeFlowCreateTableBase } from "_102048_/l2/cafeFlow/web/shared/createTable";
    export class CafeFlowDesktopPage11CreateTablePage extends CafeFlowCreateTableBase {
        render(): any;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/deleteMenuItem.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "deleteMenuItem__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102048_/l2/cafeFlow/web/desktop/page11/deleteMenuItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/desktop/page11/deleteMenuItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/shared/deleteMenuItem.defs.ts", "_102048_/l2/cafeFlow/web/shared/deleteMenuItem.ts", "_102048_/l2/cafeFlow/web/contracts/deleteMenuItem.defs.ts", "_102048_/l2/cafeFlow/web/contracts/deleteMenuItem.ts"];
        readonly dependsOn: readonly ["deleteMenuItem__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Limpo e prático, otimizado para toque em tablet/computador no caixa e na cozinha; cores quentes e acolhedoras (tons de café), tipografia legível em alta velocidade.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/deleteMenuItem" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    const message_pt: {
        "deleteMenuItem.section.title": string;
        "deleteMenuItem.organism.title": string;
        "deleteMenuItem.intent.command.title": string;
        "deleteMenuItem.field.menuItemId": string;
        "deleteMenuItem.field.name": string;
        "deleteMenuItem.field.category": string;
        "deleteMenuItem.field.price": string;
        "deleteMenuItem.field.stockItemId": string;
        "deleteMenuItem.field.status": string;
        "deleteMenuItem.action.submit": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowDeleteMenuItemBase extends CollabLitElement {
        status: string;
        deleteMenuItemState: "idle" | "loading" | "success" | "error";
        deleteMenuItemMenuItemId: string;
        deleteMenuItemName: string;
        deleteMenuItemCategory: string;
        deleteMenuItemPrice: string;
        deleteMenuItemStockItemId: string;
        deleteMenuItemStatus: string;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setDeleteMenuItemMenuItemId(value: string): void;
        handleDeleteMenuItemMenuItemIdChange(e: Event): void;
        setDeleteMenuItemName(value: string): void;
        handleDeleteMenuItemNameChange(e: Event): void;
        setDeleteMenuItemCategory(value: string): void;
        handleDeleteMenuItemCategoryChange(e: Event): void;
        setDeleteMenuItemPrice(value: string): void;
        handleDeleteMenuItemPriceChange(e: Event): void;
        setDeleteMenuItemStockItemId(value: string): void;
        handleDeleteMenuItemStockItemIdChange(e: Event): void;
        setDeleteMenuItemStatus(value: string): void;
        handleDeleteMenuItemStatusChange(e: Event): void;
        deleteMenuItem(): Promise<void>;
        handleDeleteMenuItemClick(e: Event): void;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/deleteMenuItem" {
    import { CafeFlowDeleteMenuItemBase } from "_102048_/l2/cafeFlow/web/shared/deleteMenuItem";
    export class CafeFlowDesktopPage11DeleteMenuItemPage extends CafeFlowDeleteMenuItemBase {
        render(): any;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/deleteStockItem.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "deleteStockItem__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102048_/l2/cafeFlow/web/desktop/page11/deleteStockItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/desktop/page11/deleteStockItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/shared/deleteStockItem.defs.ts", "_102048_/l2/cafeFlow/web/shared/deleteStockItem.ts", "_102048_/l2/cafeFlow/web/contracts/deleteStockItem.defs.ts", "_102048_/l2/cafeFlow/web/contracts/deleteStockItem.ts"];
        readonly dependsOn: readonly ["deleteStockItem__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Limpo e prático, otimizado para toque em tablet/computador no caixa e na cozinha; cores quentes e acolhedoras (tons de café), tipografia legível em alta velocidade.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/deleteStockItem" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    const message_pt: {
        "deleteStockItem.page.title": string;
        "deleteStockItem.section.main.title": string;
        "deleteStockItem.organism.delete.title": string;
        "deleteStockItem.intent.command.title": string;
        "deleteStockItem.field.stockItemId.label": string;
        "deleteStockItem.field.name.label": string;
        "deleteStockItem.field.unitOfMeasure.label": string;
        "deleteStockItem.field.minimumStockLevel.label": string;
        "deleteStockItem.field.status.label": string;
        "deleteStockItem.action.delete.label": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowDeleteStockItemBase extends CollabLitElement {
        status: string;
        deleteStockItemState: "idle" | "loading" | "success" | "error";
        deleteStockItemStockItemId: string;
        deleteStockItemName: string;
        deleteStockItemUnitOfMeasure: string;
        deleteStockItemMinimumStockLevel: string | number;
        deleteStockItemStatus: string;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        deleteStockItem(): Promise<void>;
        handleDeleteStockItemClick: (event: Event) => void;
        setDeleteStockItemStockItemId(value: string): void;
        handleDeleteStockItemStockItemIdChange: (event: Event) => void;
        setDeleteStockItemName(value: string): void;
        handleDeleteStockItemNameChange: (event: Event) => void;
        setDeleteStockItemUnitOfMeasure(value: string): void;
        handleDeleteStockItemUnitOfMeasureChange: (event: Event) => void;
        setDeleteStockItemMinimumStockLevel(value: string | number): void;
        handleDeleteStockItemMinimumStockLevelChange: (event: Event) => void;
        setDeleteStockItemStatus(value: string): void;
        handleDeleteStockItemStatusChange: (event: Event) => void;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/deleteStockItem" {
    import { CafeFlowDeleteStockItemBase } from "_102048_/l2/cafeFlow/web/shared/deleteStockItem";
    export class CafeFlowDesktopPage11DeleteStockItemPage extends CafeFlowDeleteStockItemBase {
        render(): any;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/deleteTable.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "deleteTable__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102048_/l2/cafeFlow/web/desktop/page11/deleteTable.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/desktop/page11/deleteTable.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/shared/deleteTable.defs.ts", "_102048_/l2/cafeFlow/web/shared/deleteTable.ts", "_102048_/l2/cafeFlow/web/contracts/deleteTable.defs.ts", "_102048_/l2/cafeFlow/web/contracts/deleteTable.ts"];
        readonly dependsOn: readonly ["deleteTable__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Limpo e prático, otimizado para toque em tablet/computador no caixa e na cozinha; cores quentes e acolhedoras (tons de café), tipografia legível em alta velocidade.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/deleteTable" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    const message_pt: {
        "deleteTable.section.title": string;
        "deleteTable.organism.title": string;
        "deleteTable.intention.commandForm.title": string;
        "deleteTable.field.tableId": string;
        "deleteTable.field.tableNumber": string;
        "deleteTable.field.capacity": string;
        "deleteTable.field.status": string;
        "deleteTable.action.submit": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowDeleteTableBase extends CollabLitElement {
        status: string;
        deleteTableState: "idle" | "loading" | "success" | "error";
        deleteTableTableId: string;
        deleteTableTableNumber: string;
        deleteTableCapacity: string;
        deleteTableStatus: string;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setDeleteTableTableId(value: string): void;
        handleDeleteTableTableIdChange(e: Event): void;
        setDeleteTableTableNumber(value: string): void;
        handleDeleteTableTableNumberChange(e: Event): void;
        setDeleteTableCapacity(value: string): void;
        handleDeleteTableCapacityChange(e: Event): void;
        setDeleteTableStatus(value: string): void;
        handleDeleteTableStatusChange(e: Event): void;
        deleteTable(): Promise<void>;
        handleDeleteTableClick(e: Event): void;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/deleteTable" {
    import { CafeFlowDeleteTableBase } from "_102048_/l2/cafeFlow/web/shared/deleteTable";
    export class CafeFlowDesktopPage11DeleteTablePage extends CafeFlowDeleteTableBase {
        render(): ReturnType<CafeFlowDeleteTableBase['render']>;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/orderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                })[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "orderLifecycle__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102048_/l2/cafeFlow/web/desktop/page11/orderLifecycle.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/desktop/page11/orderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/shared/orderLifecycle.defs.ts", "_102048_/l2/cafeFlow/web/shared/orderLifecycle.ts", "_102048_/l2/cafeFlow/web/contracts/orderLifecycle.defs.ts", "_102048_/l2/cafeFlow/web/contracts/orderLifecycle.ts"];
        readonly dependsOn: readonly ["orderLifecycle__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Limpo e prático, otimizado para toque em tablet/computador no caixa e na cozinha; cores quentes e acolhedoras (tons de café), tipografia legível em alta velocidade.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/orderLifecycle" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    const message_pt: {
        "orderLifecycle.section.main.title": string;
        "orderLifecycle.organism.launchOrder.title": string;
        "orderLifecycle.intent.launchOrder.form.title": string;
        "orderLifecycle.field.launchOrder.type": string;
        "orderLifecycle.field.launchOrder.status": string;
        "orderLifecycle.field.launchOrder.total": string;
        "orderLifecycle.action.launchOrder.submit": string;
        "orderLifecycle.organism.updateOrderStatus.title": string;
        "orderLifecycle.intent.updateOrderStatus.form.title": string;
        "orderLifecycle.field.updateOrderStatus.orderStatusEventId": string;
        "orderLifecycle.field.updateOrderStatus.orderId": string;
        "orderLifecycle.field.updateOrderStatus.previousStatus": string;
        "orderLifecycle.field.updateOrderStatus.status": string;
        "orderLifecycle.action.updateOrderStatus.submit": string;
        "orderLifecycle.organism.processPayment.title": string;
        "orderLifecycle.intent.processPayment.form.title": string;
        "orderLifecycle.field.processPayment.status": string;
        "orderLifecycle.action.processPayment.submit": string;
        "orderLifecycle.organism.summary.title": string;
        "orderLifecycle.intent.summary.title": string;
        "orderLifecycle.field.summary.status": string;
        "orderLifecycle.field.summary.total": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowOrderLifecycleBase extends CollabLitElement {
        status: string;
        launchOrderState: "idle" | "loading" | "success" | "error";
        launchOrderType: string;
        launchOrderStatus: string;
        launchOrderTotal: string;
        updateOrderStatusState: "idle" | "loading" | "success" | "error";
        updateOrderStatusOrderStatusEventId: string;
        updateOrderStatusOrderId: string;
        updateOrderStatusPreviousStatus: string;
        updateOrderStatusStatus: string;
        processPaymentState: "idle" | "loading" | "success" | "error";
        processPaymentStatus: string;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setLaunchOrderType(value: string): void;
        handleLaunchOrderTypeChange(e: Event): void;
        setLaunchOrderStatus(value: string): void;
        handleLaunchOrderStatusChange(e: Event): void;
        setLaunchOrderTotal(value: string): void;
        handleLaunchOrderTotalChange(e: Event): void;
        setUpdateOrderStatusOrderStatusEventId(value: string): void;
        handleUpdateOrderStatusOrderStatusEventIdChange(e: Event): void;
        setUpdateOrderStatusOrderId(value: string): void;
        handleUpdateOrderStatusOrderIdChange(e: Event): void;
        setUpdateOrderStatusPreviousStatus(value: string): void;
        handleUpdateOrderStatusPreviousStatusChange(e: Event): void;
        setUpdateOrderStatusStatus(value: string): void;
        handleUpdateOrderStatusStatusChange(e: Event): void;
        setProcessPaymentStatus(value: string): void;
        handleProcessPaymentStatusChange(e: Event): void;
        launchOrder(): Promise<void>;
        handleLaunchOrderClick(e: Event): void;
        updateOrderStatus(): Promise<void>;
        handleUpdateOrderStatusClick(e: Event): void;
        processPayment(): Promise<void>;
        handleProcessPaymentClick(e: Event): void;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/orderLifecycle" {
    import { CafeFlowOrderLifecycleBase } from "_102048_/l2/cafeFlow/web/shared/orderLifecycle";
    export class CafeFlowDesktopPage11OrderLifecyclePage extends CafeFlowOrderLifecycleBase {
        render(): any;
        private renderLaunchOrderOrganism;
        private renderUpdateOrderStatusOrganism;
        private renderProcessPaymentOrganism;
        private renderSummaryOrganism;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/queryMenuItem.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "queryMenuItem__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102048_/l2/cafeFlow/web/desktop/page11/queryMenuItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/desktop/page11/queryMenuItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/shared/queryMenuItem.defs.ts", "_102048_/l2/cafeFlow/web/shared/queryMenuItem.ts", "_102048_/l2/cafeFlow/web/contracts/queryMenuItem.defs.ts", "_102048_/l2/cafeFlow/web/contracts/queryMenuItem.ts"];
        readonly dependsOn: readonly ["queryMenuItem__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Limpo e prático, otimizado para toque em tablet/computador no caixa e na cozinha; cores quentes e acolhedoras (tons de café), tipografia legível em alta velocidade.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/queryMenuItem" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowQueryMenuItemOutput } from "_102048_/l2/cafeFlow/web/contracts/queryMenuItem";
    const message_pt: {
        "section.consultarItensCardapio.title": string;
        "organism.queryMenuItem.title": string;
        "intention.queryMenuItem.list.title": string;
        "intention.queryMenuItem.list.empty": string;
        "field.menuItemId.label": string;
        "field.name.label": string;
        "field.category.label": string;
        "field.price.label": string;
        "field.stockItemId.label": string;
        "field.status.label": string;
        "field.createdAt.label": string;
        "field.updatedAt.label": string;
        "action.queryMenuItem.label": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowQueryMenuItemBase extends CollabLitElement {
        status: string;
        queryMenuItemState: "idle" | "loading" | "success" | "error";
        queryMenuItemMenuItemId: string;
        queryMenuItemName: string;
        queryMenuItemCategory: string;
        queryMenuItemStockItemId: string;
        queryMenuItemStatus: string;
        queryMenuItemCreatedAt: string;
        queryMenuItemData: CafeFlowQueryMenuItemOutput;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        loadQueryMenuItem(): Promise<void>;
        handleQueryMenuItemClick: (event: Event) => void;
        setQueryMenuItemMenuItemId(value: string): void;
        handleQueryMenuItemMenuItemIdChange: (event: Event) => void;
        setQueryMenuItemName(value: string): void;
        handleQueryMenuItemNameChange: (event: Event) => void;
        setQueryMenuItemCategory(value: string): void;
        handleQueryMenuItemCategoryChange: (event: Event) => void;
        setQueryMenuItemStockItemId(value: string): void;
        handleQueryMenuItemStockItemIdChange: (event: Event) => void;
        setQueryMenuItemStatus(value: string): void;
        handleQueryMenuItemStatusChange: (event: Event) => void;
        setQueryMenuItemCreatedAt(value: string): void;
        handleQueryMenuItemCreatedAtChange: (event: Event) => void;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/queryMenuItem" {
    import { CafeFlowQueryMenuItemBase } from "_102048_/l2/cafeFlow/web/shared/queryMenuItem";
    export class CafeFlowDesktopPage11QueryMenuItemPage extends CafeFlowQueryMenuItemBase {
        render(): any;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/queryStockItem.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "queryStockItem__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102048_/l2/cafeFlow/web/desktop/page11/queryStockItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/desktop/page11/queryStockItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/shared/queryStockItem.defs.ts", "_102048_/l2/cafeFlow/web/shared/queryStockItem.ts", "_102048_/l2/cafeFlow/web/contracts/queryStockItem.defs.ts", "_102048_/l2/cafeFlow/web/contracts/queryStockItem.ts"];
        readonly dependsOn: readonly ["queryStockItem__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Limpo e prático, otimizado para toque em tablet/computador no caixa e na cozinha; cores quentes e acolhedoras (tons de café), tipografia legível em alta velocidade.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/queryStockItem" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowQueryStockItemOutputItem } from "_102048_/l2/cafeFlow/web/contracts/queryStockItem";
    const message_pt: {
        "queryStockItem.section.main.title": string;
        "queryStockItem.organism.list.title": string;
        "queryStockItem.intention.list.title": string;
        "queryStockItem.field.stockItemId": string;
        "queryStockItem.field.name": string;
        "queryStockItem.field.unitOfMeasure": string;
        "queryStockItem.field.minimumStockLevel": string;
        "queryStockItem.field.status": string;
        "queryStockItem.field.createdAt": string;
        "queryStockItem.field.updatedAt": string;
        "queryStockItem.filter.stockItemId": string;
        "queryStockItem.filter.name": string;
        "queryStockItem.filter.status": string;
        "queryStockItem.filter.createdAt": string;
        "queryStockItem.filter.updatedAt": string;
        "queryStockItem.action.query": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowQueryStockItemBase extends CollabLitElement {
        status: string;
        queryStockItemState: "idle" | "loading" | "success" | "error";
        queryStockItemStockItemId: string;
        queryStockItemName: string;
        queryStockItemStatus: string;
        queryStockItemCreatedAt: string;
        queryStockItemUpdatedAt: string;
        queryStockItemData: CafeFlowQueryStockItemOutputItem[];
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: unknown): void;
        loadQueryStockItem(): Promise<void>;
        handleQueryStockItemClick: (_event: Event) => void;
        setQueryStockItemStockItemId(value: string): void;
        handleQueryStockItemStockItemIdChange: (event: Event) => void;
        setQueryStockItemName(value: string): void;
        handleQueryStockItemNameChange: (event: Event) => void;
        setQueryStockItemStatus(value: string): void;
        handleQueryStockItemStatusChange: (event: Event) => void;
        setQueryStockItemCreatedAt(value: string): void;
        handleQueryStockItemCreatedAtChange: (event: Event) => void;
        setQueryStockItemUpdatedAt(value: string): void;
        handleQueryStockItemUpdatedAtChange: (event: Event) => void;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/queryStockItem" {
    import { CafeFlowQueryStockItemBase } from "_102048_/l2/cafeFlow/web/shared/queryStockItem";
    export class CafeFlowDesktopPage11QueryStockItemPage extends CafeFlowQueryStockItemBase {
        render(): any;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/queryTable.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "queryTable__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102048_/l2/cafeFlow/web/desktop/page11/queryTable.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/desktop/page11/queryTable.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/shared/queryTable.defs.ts", "_102048_/l2/cafeFlow/web/shared/queryTable.ts", "_102048_/l2/cafeFlow/web/contracts/queryTable.defs.ts", "_102048_/l2/cafeFlow/web/contracts/queryTable.ts"];
        readonly dependsOn: readonly ["queryTable__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Limpo e prático, otimizado para toque em tablet/computador no caixa e na cozinha; cores quentes e acolhedoras (tons de café), tipografia legível em alta velocidade.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/queryTable" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowQueryTableOutput } from "_102048_/l2/cafeFlow/web/contracts/queryTable";
    const message_pt: {
        "queryTable.section.title": string;
        "queryTable.organism.title": string;
        "queryTable.intent.list.title": string;
        "queryTable.field.tableId": string;
        "queryTable.field.tableNumber": string;
        "queryTable.field.capacity": string;
        "queryTable.field.status": string;
        "queryTable.field.createdAt": string;
        "queryTable.field.updatedAt": string;
        "queryTable.filter.tableId": string;
        "queryTable.filter.status": string;
        "queryTable.filter.createdAt": string;
        "queryTable.filter.updatedAt": string;
        "queryTable.action.query": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowQueryTableBase extends CollabLitElement {
        status: string;
        queryTableState: 'idle' | 'loading' | 'success' | 'error';
        queryTableTableId: string;
        queryTableStatus: string;
        queryTableCreatedAt: string;
        queryTableUpdatedAt: string;
        queryTableData: CafeFlowQueryTableOutput;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        loadQueryTable(): Promise<void>;
        handleQueryTableClick(_event: Event): void;
        setQueryTableTableId(value: string): void;
        handleQueryTableTableIdChange(event: Event): void;
        setQueryTableStatus(value: string): void;
        handleQueryTableStatusChange(event: Event): void;
        setQueryTableCreatedAt(value: string): void;
        handleQueryTableCreatedAtChange(event: Event): void;
        setQueryTableUpdatedAt(value: string): void;
        handleQueryTableUpdatedAtChange(event: Event): void;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/queryTable" {
    import { type TemplateResult } from 'lit';
    import { CafeFlowQueryTableBase } from "_102048_/l2/cafeFlow/web/shared/queryTable";
    export class CafeFlowDesktopPage11QueryTablePage extends CafeFlowQueryTableBase {
        render(): TemplateResult;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/shiftLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                } | {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                    action?: undefined;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        action: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                        source?: undefined;
                        action?: undefined;
                    })[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "shiftLifecycle__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102048_/l2/cafeFlow/web/desktop/page11/shiftLifecycle.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/desktop/page11/shiftLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/shared/shiftLifecycle.defs.ts", "_102048_/l2/cafeFlow/web/shared/shiftLifecycle.ts", "_102048_/l2/cafeFlow/web/contracts/shiftLifecycle.defs.ts", "_102048_/l2/cafeFlow/web/contracts/shiftLifecycle.ts"];
        readonly dependsOn: readonly ["shiftLifecycle__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Limpo e prático, otimizado para toque em tablet/computador no caixa e na cozinha; cores quentes e acolhedoras (tons de café), tipografia legível em alta velocidade.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/shiftLifecycle" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowViewDashboardOutputItem, CafeFlowViewShiftReportOutputItem } from "_102048_/l2/cafeFlow/web/contracts/shiftLifecycle";
    const message_pt: {
        "shiftLifecycle.section.main.title": string;
        "shiftLifecycle.organism.viewDashboard.title": string;
        "shiftLifecycle.intention.viewDashboard.query.title": string;
        "shiftLifecycle.field.dailyShiftId": string;
        "shiftLifecycle.field.date": string;
        "shiftLifecycle.field.openTime": string;
        "shiftLifecycle.field.closeTime": string;
        "shiftLifecycle.field.status": string;
        "shiftLifecycle.field.totalSales": string;
        "shiftLifecycle.field.createdAt": string;
        "shiftLifecycle.field.updatedAt": string;
        "shiftLifecycle.action.viewDashboard": string;
        "shiftLifecycle.organism.viewShiftReport.title": string;
        "shiftLifecycle.intention.viewShiftReport.query.title": string;
        "shiftLifecycle.field.shiftCloseReportId": string;
        "shiftLifecycle.field.totalOrders": string;
        "shiftLifecycle.field.bestSellingItems": string;
        "shiftLifecycle.field.stockConsumptionSummary": string;
        "shiftLifecycle.field.operationalMetrics": string;
        "shiftLifecycle.action.viewShiftReport": string;
        "shiftLifecycle.intention.summary.title": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowShiftLifecycleBase extends CollabLitElement {
        status: string;
        viewDashboardState: 'idle' | 'loading' | 'success' | 'error';
        viewDashboardDailyShiftId: string;
        viewDashboardDate: string;
        viewDashboardStatus: string;
        viewDashboardCreatedAt: string;
        viewDashboardUpdatedAt: string;
        viewDashboardData: CafeFlowViewDashboardOutputItem[];
        viewShiftReportState: 'idle' | 'loading' | 'success' | 'error';
        viewShiftReportShiftCloseReportId: string;
        viewShiftReportDailyShiftId: string;
        viewShiftReportCreatedAt: string;
        viewShiftReportUpdatedAt: string;
        viewShiftReportData: CafeFlowViewShiftReportOutputItem[];
        protected get msg(): MessageType;
        private readonly stateKeyMap;
        private subscribedKeys;
        loadViewDashboard(): Promise<void>;
        handleViewDashboardClick(_e: Event): void;
        loadViewShiftReport(): Promise<void>;
        handleViewShiftReportClick(_e: Event): void;
        setViewDashboardDailyShiftId(value: string): void;
        handleViewDashboardDailyShiftIdChange(e: Event): void;
        setViewDashboardDate(value: string): void;
        handleViewDashboardDateChange(e: Event): void;
        setViewDashboardStatus(value: string): void;
        handleViewDashboardStatusChange(e: Event): void;
        setViewDashboardCreatedAt(value: string): void;
        handleViewDashboardCreatedAtChange(e: Event): void;
        setViewDashboardUpdatedAt(value: string): void;
        handleViewDashboardUpdatedAtChange(e: Event): void;
        setViewShiftReportShiftCloseReportId(value: string): void;
        handleViewShiftReportShiftCloseReportIdChange(e: Event): void;
        setViewShiftReportDailyShiftId(value: string): void;
        handleViewShiftReportDailyShiftIdChange(e: Event): void;
        setViewShiftReportCreatedAt(value: string): void;
        handleViewShiftReportCreatedAtChange(e: Event): void;
        setViewShiftReportUpdatedAt(value: string): void;
        handleViewShiftReportUpdatedAtChange(e: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/shiftLifecycle" {
    import { CafeFlowShiftLifecycleBase } from "_102048_/l2/cafeFlow/web/shared/shiftLifecycle";
    export class CafeFlowDesktopPage11ShiftLifecyclePage extends CafeFlowShiftLifecycleBase {
        render(): any;
        private renderViewDashboard;
        private renderViewShiftReport;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/updateMenuItem.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "updateMenuItem__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102048_/l2/cafeFlow/web/desktop/page11/updateMenuItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/desktop/page11/updateMenuItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/shared/updateMenuItem.defs.ts", "_102048_/l2/cafeFlow/web/shared/updateMenuItem.ts", "_102048_/l2/cafeFlow/web/contracts/updateMenuItem.defs.ts", "_102048_/l2/cafeFlow/web/contracts/updateMenuItem.ts"];
        readonly dependsOn: readonly ["updateMenuItem__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Limpo e prático, otimizado para toque em tablet/computador no caixa e na cozinha; cores quentes e acolhedoras (tons de café), tipografia legível em alta velocidade.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/updateMenuItem" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    const message_pt: {
        "updateMenuItem.section.title": string;
        "updateMenuItem.organism.title": string;
        "updateMenuItem.form.title": string;
        "updateMenuItem.field.name": string;
        "updateMenuItem.field.price": string;
        "updateMenuItem.field.stockItemId": string;
        "updateMenuItem.field.status": string;
        "updateMenuItem.action.submit": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowUpdateMenuItemBase extends CollabLitElement {
        status: string;
        updateMenuItemState: "idle" | "loading" | "success" | "error";
        updateMenuItemName: string;
        updateMenuItemPrice: string;
        updateMenuItemStockItemId: string;
        updateMenuItemStatus: string;
        protected get msg(): MessageType;
        setUpdateMenuItemName(value: string): void;
        handleUpdateMenuItemNameChange(e: Event): void;
        setUpdateMenuItemPrice(value: string): void;
        handleUpdateMenuItemPriceChange(e: Event): void;
        setUpdateMenuItemStockItemId(value: string): void;
        handleUpdateMenuItemStockItemIdChange(e: Event): void;
        setUpdateMenuItemStatus(value: string): void;
        handleUpdateMenuItemStatusChange(e: Event): void;
        updateMenuItem(): Promise<void>;
        handleUpdateMenuItemClick(e: Event): Promise<void>;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/updateMenuItem" {
    import { CafeFlowUpdateMenuItemBase } from "_102048_/l2/cafeFlow/web/shared/updateMenuItem";
    export class CafeFlowDesktopPage11UpdateMenuItemPage extends CafeFlowUpdateMenuItemBase {
        render(): any;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/updateStockItem.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "updateStockItem__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102048_/l2/cafeFlow/web/desktop/page11/updateStockItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/desktop/page11/updateStockItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/shared/updateStockItem.defs.ts", "_102048_/l2/cafeFlow/web/shared/updateStockItem.ts", "_102048_/l2/cafeFlow/web/contracts/updateStockItem.defs.ts", "_102048_/l2/cafeFlow/web/contracts/updateStockItem.ts"];
        readonly dependsOn: readonly ["updateStockItem__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Limpo e prático, otimizado para toque em tablet/computador no caixa e na cozinha; cores quentes e acolhedoras (tons de café), tipografia legível em alta velocidade.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/updateStockItem" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    const message_pt: {
        "section.editStockItem.title": string;
        "organism.updateStockItem.title": string;
        "intention.updateStockItemForm.title": string;
        "field.name.label": string;
        "field.unitOfMeasure.label": string;
        "field.minimumStockLevel.label": string;
        "field.status.label": string;
        "action.updateStockItem.label": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowUpdateStockItemBase extends CollabLitElement {
        status: string;
        updateStockItemState: "idle" | "loading" | "success" | "error";
        updateStockItemName: string;
        updateStockItemUnitOfMeasure: string;
        updateStockItemMinimumStockLevel: string;
        updateStockItemStatus: string;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setUpdateStockItemName(value: string): void;
        handleUpdateStockItemNameChange(e: Event): void;
        setUpdateStockItemUnitOfMeasure(value: string): void;
        handleUpdateStockItemUnitOfMeasureChange(e: Event): void;
        setUpdateStockItemMinimumStockLevel(value: string): void;
        handleUpdateStockItemMinimumStockLevelChange(e: Event): void;
        setUpdateStockItemStatus(value: string): void;
        handleUpdateStockItemStatusChange(e: Event): void;
        updateStockItem(): Promise<void>;
        handleUpdateStockItemClick(e: Event): void;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/updateStockItem" {
    import { CafeFlowUpdateStockItemBase } from "_102048_/l2/cafeFlow/web/shared/updateStockItem";
    export class CafeFlowDesktopPage11UpdateStockItemPage extends CafeFlowUpdateStockItemBase {
        render(): any;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/updateTable.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "updateTable__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102048_/l2/cafeFlow/web/desktop/page11/updateTable.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/desktop/page11/updateTable.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/shared/updateTable.defs.ts", "_102048_/l2/cafeFlow/web/shared/updateTable.ts", "_102048_/l2/cafeFlow/web/contracts/updateTable.defs.ts", "_102048_/l2/cafeFlow/web/contracts/updateTable.ts"];
        readonly dependsOn: readonly ["updateTable__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Limpo e prático, otimizado para toque em tablet/computador no caixa e na cozinha; cores quentes e acolhedoras (tons de café), tipografia legível em alta velocidade.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/updateTable" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    const message_pt: {
        "updateTable.section.editTable.title": string;
        "updateTable.organism.updateTableForm.title": string;
        "updateTable.intention.commandForm.title": string;
        "updateTable.field.tableNumber.label": string;
        "updateTable.field.capacity.label": string;
        "updateTable.field.status.label": string;
        "updateTable.action.updateTable.submit.label": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowUpdateTableBase extends CollabLitElement {
        status: string;
        updateTableState: "idle" | "loading" | "success" | "error";
        updateTableTableNumber: string;
        updateTableCapacity: string;
        updateTableStatus: string;
        protected get msg(): MessageType;
        setUpdateTableTableNumber(value: string): void;
        handleUpdateTableTableNumberChange: (event: Event) => void;
        setUpdateTableCapacity(value: string): void;
        handleUpdateTableCapacityChange: (event: Event) => void;
        setUpdateTableStatus(value: string): void;
        handleUpdateTableStatusChange: (event: Event) => void;
        updateTable(): Promise<void>;
        handleUpdateTableClick: () => void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102048_/l2/cafeFlow/web/desktop/page11/updateTable" {
    import { CafeFlowUpdateTableBase } from "_102048_/l2/cafeFlow/web/shared/updateTable";
    export class CafeFlowDesktopPage11UpdateTablePage extends CafeFlowUpdateTableBase {
        render(): any;
    }
}
declare module "_102048_/l2/cafeFlow/web/shared/adjustStockLevel.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "adjustStockLevel.section.title": string;
            "adjustStockLevel.organism.title": string;
            "adjustStockLevel.intent.commandForm.title": string;
            "adjustStockLevel.field.currentQuantity": string;
            "adjustStockLevel.field.status": string;
            "adjustStockLevel.action.submit": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "adjustStockLevel__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102048_/l2/cafeFlow/web/shared/adjustStockLevel.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/shared/adjustStockLevel.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/contracts/adjustStockLevel.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["adjustStockLevel__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/adjustStockLevel.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/shared/createMenuItem.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "createMenuItem.section.title": string;
            "createMenuItem.organism.title": string;
            "createMenuItem.intent.commandForm.title": string;
            "menuItem.field.name": string;
            "menuItem.field.category": string;
            "menuItem.field.price": string;
            "menuItem.field.status": string;
            "createMenuItem.action.submit": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "createMenuItem__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102048_/l2/cafeFlow/web/shared/createMenuItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/shared/createMenuItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/contracts/createMenuItem.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["createMenuItem__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/createMenuItem.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/shared/createStockItem.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "createStockItem.section.title": string;
            "createStockItem.form.title": string;
            "createStockItem.action.submit": string;
            "stockItem.field.name": string;
            "stockItem.field.unitOfMeasure": string;
            "stockItem.field.minimumStockLevel": string;
            "stockItem.field.status": string;
            "section.createStockItem.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "createStockItem__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102048_/l2/cafeFlow/web/shared/createStockItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/shared/createStockItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/contracts/createStockItem.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["createStockItem__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/createStockItem.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/shared/createTable.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "createTable.section.title": string;
            "createTable.organism.title": string;
            "createTable.intention.form.title": string;
            "createTable.field.tableNumber": string;
            "createTable.field.capacity": string;
            "createTable.field.status": string;
            "createTable.field.status.active": string;
            "createTable.field.status.inactive": string;
            "createTable.action.submit": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "createTable__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102048_/l2/cafeFlow/web/shared/createTable.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/shared/createTable.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/contracts/createTable.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["createTable__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/createTable.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/shared/deleteMenuItem.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "deleteMenuItem.section.title": string;
            "deleteMenuItem.organism.title": string;
            "deleteMenuItem.intent.command.title": string;
            "deleteMenuItem.field.menuItemId": string;
            "deleteMenuItem.field.name": string;
            "deleteMenuItem.field.category": string;
            "deleteMenuItem.field.price": string;
            "deleteMenuItem.field.stockItemId": string;
            "deleteMenuItem.field.status": string;
            "deleteMenuItem.action.submit": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "deleteMenuItem__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102048_/l2/cafeFlow/web/shared/deleteMenuItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/shared/deleteMenuItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/contracts/deleteMenuItem.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["deleteMenuItem__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/deleteMenuItem.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/shared/deleteStockItem.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "deleteStockItem.page.title": string;
            "deleteStockItem.section.main.title": string;
            "deleteStockItem.organism.delete.title": string;
            "deleteStockItem.intent.command.title": string;
            "deleteStockItem.field.stockItemId.label": string;
            "deleteStockItem.field.name.label": string;
            "deleteStockItem.field.unitOfMeasure.label": string;
            "deleteStockItem.field.minimumStockLevel.label": string;
            "deleteStockItem.field.status.label": string;
            "deleteStockItem.action.delete.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "deleteStockItem__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102048_/l2/cafeFlow/web/shared/deleteStockItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/shared/deleteStockItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/contracts/deleteStockItem.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["deleteStockItem__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/deleteStockItem.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/shared/deleteTable.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "deleteTable.section.title": string;
            "deleteTable.organism.title": string;
            "deleteTable.intention.commandForm.title": string;
            "deleteTable.field.tableId": string;
            "deleteTable.field.tableNumber": string;
            "deleteTable.field.capacity": string;
            "deleteTable.field.status": string;
            "deleteTable.action.submit": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "deleteTable__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102048_/l2/cafeFlow/web/shared/deleteTable.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/shared/deleteTable.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/contracts/deleteTable.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["deleteTable__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/deleteTable.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/shared/orderLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "orderLifecycle.section.main.title": string;
            "orderLifecycle.organism.launchOrder.title": string;
            "orderLifecycle.intent.launchOrder.form.title": string;
            "orderLifecycle.field.launchOrder.type": string;
            "orderLifecycle.field.launchOrder.status": string;
            "orderLifecycle.field.launchOrder.total": string;
            "orderLifecycle.action.launchOrder.submit": string;
            "orderLifecycle.organism.updateOrderStatus.title": string;
            "orderLifecycle.intent.updateOrderStatus.form.title": string;
            "orderLifecycle.field.updateOrderStatus.orderStatusEventId": string;
            "orderLifecycle.field.updateOrderStatus.orderId": string;
            "orderLifecycle.field.updateOrderStatus.previousStatus": string;
            "orderLifecycle.field.updateOrderStatus.status": string;
            "orderLifecycle.action.updateOrderStatus.submit": string;
            "orderLifecycle.organism.processPayment.title": string;
            "orderLifecycle.intent.processPayment.form.title": string;
            "orderLifecycle.field.processPayment.status": string;
            "orderLifecycle.action.processPayment.submit": string;
            "orderLifecycle.organism.summary.title": string;
            "orderLifecycle.intent.summary.title": string;
            "orderLifecycle.field.summary.status": string;
            "orderLifecycle.field.summary.total": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "orderLifecycle__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102048_/l2/cafeFlow/web/shared/orderLifecycle.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/shared/orderLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/contracts/orderLifecycle.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["orderLifecycle__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/orderLifecycle.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/shared/queryMenuItem.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "section.consultarItensCardapio.title": string;
            "organism.queryMenuItem.title": string;
            "intention.queryMenuItem.list.title": string;
            "intention.queryMenuItem.list.empty": string;
            "field.menuItemId.label": string;
            "field.name.label": string;
            "field.category.label": string;
            "field.price.label": string;
            "field.stockItemId.label": string;
            "field.status.label": string;
            "field.createdAt.label": string;
            "field.updatedAt.label": string;
            "action.queryMenuItem.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "queryMenuItem__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102048_/l2/cafeFlow/web/shared/queryMenuItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/shared/queryMenuItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/contracts/queryMenuItem.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["queryMenuItem__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/queryMenuItem.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/shared/queryStockItem.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "queryStockItem.section.main.title": string;
            "queryStockItem.organism.list.title": string;
            "queryStockItem.intention.list.title": string;
            "queryStockItem.field.stockItemId": string;
            "queryStockItem.field.name": string;
            "queryStockItem.field.unitOfMeasure": string;
            "queryStockItem.field.minimumStockLevel": string;
            "queryStockItem.field.status": string;
            "queryStockItem.field.createdAt": string;
            "queryStockItem.field.updatedAt": string;
            "queryStockItem.filter.stockItemId": string;
            "queryStockItem.filter.name": string;
            "queryStockItem.filter.status": string;
            "queryStockItem.filter.createdAt": string;
            "queryStockItem.filter.updatedAt": string;
            "queryStockItem.action.query": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "queryStockItem__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102048_/l2/cafeFlow/web/shared/queryStockItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/shared/queryStockItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/contracts/queryStockItem.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["queryStockItem__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/queryStockItem.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/shared/queryTable.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "queryTable.section.title": string;
            "queryTable.organism.title": string;
            "queryTable.intent.list.title": string;
            "queryTable.field.tableId": string;
            "queryTable.field.tableNumber": string;
            "queryTable.field.capacity": string;
            "queryTable.field.status": string;
            "queryTable.field.createdAt": string;
            "queryTable.field.updatedAt": string;
            "queryTable.filter.tableId": string;
            "queryTable.filter.status": string;
            "queryTable.filter.createdAt": string;
            "queryTable.filter.updatedAt": string;
            "queryTable.action.query": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "queryTable__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102048_/l2/cafeFlow/web/shared/queryTable.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/shared/queryTable.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/contracts/queryTable.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["queryTable__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/queryTable.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/shared/shiftLifecycle.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "shiftLifecycle.section.main.title": string;
            "shiftLifecycle.organism.viewDashboard.title": string;
            "shiftLifecycle.intention.viewDashboard.query.title": string;
            "shiftLifecycle.field.dailyShiftId": string;
            "shiftLifecycle.field.date": string;
            "shiftLifecycle.field.openTime": string;
            "shiftLifecycle.field.closeTime": string;
            "shiftLifecycle.field.status": string;
            "shiftLifecycle.field.totalSales": string;
            "shiftLifecycle.field.createdAt": string;
            "shiftLifecycle.field.updatedAt": string;
            "shiftLifecycle.action.viewDashboard": string;
            "shiftLifecycle.organism.viewShiftReport.title": string;
            "shiftLifecycle.intention.viewShiftReport.query.title": string;
            "shiftLifecycle.field.shiftCloseReportId": string;
            "shiftLifecycle.field.totalOrders": string;
            "shiftLifecycle.field.bestSellingItems": string;
            "shiftLifecycle.field.stockConsumptionSummary": string;
            "shiftLifecycle.field.operationalMetrics": string;
            "shiftLifecycle.action.viewShiftReport": string;
            "shiftLifecycle.intention.summary.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "shiftLifecycle__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102048_/l2/cafeFlow/web/shared/shiftLifecycle.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/shared/shiftLifecycle.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/contracts/shiftLifecycle.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["shiftLifecycle__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/shiftLifecycle.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/shared/updateMenuItem.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "updateMenuItem.section.title": string;
            "updateMenuItem.organism.title": string;
            "updateMenuItem.form.title": string;
            "updateMenuItem.field.name": string;
            "updateMenuItem.field.price": string;
            "updateMenuItem.field.stockItemId": string;
            "updateMenuItem.field.status": string;
            "updateMenuItem.action.submit": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "updateMenuItem__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102048_/l2/cafeFlow/web/shared/updateMenuItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/shared/updateMenuItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/contracts/updateMenuItem.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["updateMenuItem__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/updateMenuItem.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/shared/updateStockItem.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "section.editStockItem.title": string;
            "organism.updateStockItem.title": string;
            "intention.updateStockItemForm.title": string;
            "field.name.label": string;
            "field.unitOfMeasure.label": string;
            "field.minimumStockLevel.label": string;
            "field.status.label": string;
            "action.updateStockItem.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "updateStockItem__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102048_/l2/cafeFlow/web/shared/updateStockItem.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/shared/updateStockItem.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/contracts/updateStockItem.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["updateStockItem__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/updateStockItem.test" {
    export {};
}
declare module "_102048_/l2/cafeFlow/web/shared/updateTable.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            sourceKind: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "updateTable.section.editTable.title": string;
            "updateTable.organism.updateTableForm.title": string;
            "updateTable.intention.commandForm.title": string;
            "updateTable.field.tableNumber.label": string;
            "updateTable.field.capacity.label": string;
            "updateTable.field.status.label": string;
            "updateTable.action.updateTable.submit.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "updateTable__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102048_/l2/cafeFlow/web/shared/updateTable.ts";
        readonly defPath: "_102048_/l2/cafeFlow/web/shared/updateTable.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l2/cafeFlow/web/contracts/updateTable.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["updateTable__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102048_/l2/cafeFlow/web/shared/updateTable.test" {
    export {};
}
